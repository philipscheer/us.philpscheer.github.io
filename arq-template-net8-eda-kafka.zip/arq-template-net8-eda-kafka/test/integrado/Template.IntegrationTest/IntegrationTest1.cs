using System;
using Xunit;

namespace Template.IntegrationTest
{
    public class IntegrationTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
