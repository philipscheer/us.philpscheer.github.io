﻿using EventBus.Kafka.Events;
using EventBus.Kafka.Helpers;
using EventBus.Kafka.Infrastructure.Oracle;
using EventBus.Kafka.Models;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Polly.Retry;

namespace EventBus.Kafka.Background
{
    public class EventSubscriberService : BackgroundService
        {
            private readonly EventSubscriber<EventMessageModel> _kafkaConsumer;
            private readonly OracleEventRepository<EventMessageModel> _repository;
            private readonly ILogger<EventSubscriberService> _logger;
            private readonly AsyncRetryPolicy _kafkaRetryPolicy;
            private readonly bool _ativarLog;

            public EventSubscriberService(EventSubscriber<EventMessageModel> kafkaConsumer, 
                                          OracleEventRepository<EventMessageModel> repository, 
                                          ILogger<EventSubscriberService> logger,
                                          IOptions<DatabaseSettings> databaseSettings)
            {
                _kafkaConsumer = kafkaConsumer;
                _repository = repository;
                _logger = logger;
                _kafkaRetryPolicy = ResilienceHelper.GetKafkaRetryPolicy();
                _ativarLog = databaseSettings.Value.AtivarLog;
            }

            protected override async Task ExecuteAsync(CancellationToken stoppingToken)
            {
                _logger.LogInformation("Kafka Consumer Service iniciado.");

                while (!stoppingToken.IsCancellationRequested)
                {
                    try
                    {
                        await _kafkaRetryPolicy.ExecuteAsync(async () =>
                        {
                            _kafkaConsumer.Subscribe(async (EventMessageModel eventMessage) =>
                            {
                                _logger.LogInformation($"Mensagem recebida: {eventMessage.EventType} - {eventMessage.Payload}");

                                if (_ativarLog)
                                {
                                    var newEvent = new { Id = Guid.NewGuid(), eventMessage.EventType, eventMessage.Payload, CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow };
                                    await _repository.AddAsync("EVENT_MESSAGES", newEvent); 
                                }

                                _logger.LogInformation("Evento salvo no banco.");
                            }, stoppingToken);
                        });
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError($"Erro ao consumir mensagem do Kafka: {ex.Message}");
                    }

                    await Task.Delay(1000, stoppingToken);
                }
            }
        }
}
