﻿namespace EventBus.Kafka.Helpers
{
    public static class ValidationHelper
    {
        public static void EnsureNotNullOrEmpty(string value, string paramName, string? errorMessage = null)
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentNullException(paramName, errorMessage ?? $"{paramName} não pode ser nulo ou vazio.");
        }

        public static void ValidateTopic(string? topic)
        {
            if (string.IsNullOrWhiteSpace(topic)) 
                throw new ArgumentException("O tópico do Kafka não pode ser nulo ou vazio.", nameof(topic));
        }
    }
}
