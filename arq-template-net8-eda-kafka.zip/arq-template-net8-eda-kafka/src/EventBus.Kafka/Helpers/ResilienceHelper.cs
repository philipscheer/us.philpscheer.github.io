﻿using Polly;
using Polly.Retry;

namespace EventBus.Kafka.Helpers
{
    public static class ResilienceHelper
    {
        public static AsyncRetryPolicy GetKafkaRetryPolicy(int retryCount = 3)
        {
            return Policy
                .Handle<Exception>()
                .WaitAndRetryAsync(retryCount, retryAttempt =>
                    TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
                    (exception, timeSpan, retry, context) =>
                    {
                        Console.WriteLine($"Falha no Kafka. Tentativa {retry} em {timeSpan.TotalSeconds}s: {exception.Message}");
                    });
        }

        public static AsyncRetryPolicy GetDatabaseRetryPolicy(int retryCount = 3)
        {
            return Policy
                .Handle<Exception>()
                .WaitAndRetryAsync(retryCount, retryAttempt =>
                    TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
                    (exception, timeSpan, retry, context) =>
                    {
                        Console.WriteLine($"Falha no Banco de Dados. Tentativa {retry} em {timeSpan.TotalSeconds}s: {exception.Message}");
                    });
        }
    }
}