﻿using System.Text.Json;
using Confluent.Kafka;
using EventBus.Kafka.Helpers;
using EventBus.Kafka.Models;
using Microsoft.Extensions.Options;

namespace EventBus.Kafka.Events
{
    public class EventSubscriber<T>
    {
        private readonly IConsumer<string, string> _consumer;
        private readonly string _topic;

        public EventSubscriber(IOptions<InputParameterskafka> inputParametersKafka)
        {
            if (inputParametersKafka?.Value == null)
                throw new ArgumentNullException(nameof(inputParametersKafka), "As configurações do Kafka não podem ser nulas.");

            var topic = inputParametersKafka.Value?.Consumer?.Topic;

            ValidationHelper.ValidateTopic(topic);

            _topic = topic!;

            var config = new ConsumerConfig
            {
                BootstrapServers = inputParametersKafka.Value?.BootstrapServers,
                SaslMechanism = SaslMechanism.ScramSha512,
                SecurityProtocol = SecurityProtocol.SaslSsl,
                SslCaLocation = string.IsNullOrEmpty(inputParametersKafka.Value?.SecurityParameters?.CertifiedPath) ? @"/app/ca.crt" : inputParametersKafka.Value?.SecurityParameters.CertifiedPath,
                SaslUsername = inputParametersKafka.Value?.SecurityParameters?.SaslUsername,
                SaslPassword = inputParametersKafka.Value?.SecurityParameters?.SaslPassword,
                MessageMaxBytes = inputParametersKafka.Value?.MessageMaxBytes == null ? 1000000 : inputParametersKafka.Value?.MessageMaxBytes,
                SocketTimeoutMs = inputParametersKafka.Value?.Consumer?.ConsumerProccessMaxMS,
                AutoOffsetReset = AutoOffsetReset.Earliest,
                GroupId = inputParametersKafka.Value?.Consumer?.GroupId,
                EnableAutoCommit = false,
                HeartbeatIntervalMs = inputParametersKafka.Value?.Consumer?.HeartbeatIntervalMs == null ? 3000 : inputParametersKafka.Value.Consumer.HeartbeatIntervalMs,
                SessionTimeoutMs = inputParametersKafka.Value?.Consumer?.SessionTimeoutMs == null ? 45000 : inputParametersKafka.Value.Consumer.SessionTimeoutMs,
                MaxPollIntervalMs = inputParametersKafka.Value?.Consumer?.MaxPollIntervalMs == null ? 300000 : inputParametersKafka.Value.Consumer.MaxPollIntervalMs,
            };

            _consumer = new ConsumerBuilder<string, string>(config).Build();
            _consumer.Subscribe(_topic);
        }

        public void Subscribe(Func<T, Task> processMessage, CancellationToken cancellationToken)
        {
            if (processMessage == null)
                throw new ArgumentNullException(nameof(processMessage), "O processador de mensagens não pode ser nulo.");

            while (!cancellationToken.IsCancellationRequested)
            {
                try
                {
                    var consumeResult = _consumer.Consume(cancellationToken);

                    if (consumeResult?.Message?.Value != null)
                    {
                        var message = JsonSerializer.Deserialize<T>(consumeResult.Message.Value);
                        processMessage(message);
                        _consumer.Commit(consumeResult); // Confirma a entrega da mensagem após processamento bem-sucedido
                    }
                }
                catch (OperationCanceledException)
                {
                    break; // Encerra o consumo quando a aplicação for finalizada
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao consumir mensagem do Kafka: {ex.Message}");
                }
            }
        }

    }
}
