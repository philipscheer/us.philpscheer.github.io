﻿using System.Text.Json;
using Confluent.Kafka;
using EventBus.Kafka.Helpers;
using EventBus.Kafka.Models;
using Microsoft.Extensions.Options;

namespace EventBus.Kafka.Events
{
    public class EventPublisher
    {
        private readonly IProducer<string, string> _producer;
        private readonly string _topic;

        public EventPublisher(IOptions<InputParameterskafka> inputParametersKafka)
        {
            var topic = inputParametersKafka.Value?.Consumer?.Topic;

            ValidationHelper.ValidateTopic(topic);

            _topic = topic!;

            var config = new ProducerConfig 
            {
                BootstrapServers = inputParametersKafka.Value?.BootstrapServers,
                SaslMechanism = SaslMechanism.ScramSha512,
                SecurityProtocol = SecurityProtocol.SaslSsl,
                SslCaLocation = string.IsNullOrEmpty(inputParametersKafka.Value?.SecurityParameters?.CertifiedPath) ? @"/app/ca.crt" : inputParametersKafka.Value.SecurityParameters.CertifiedPath,
                SaslUsername = inputParametersKafka.Value?.SecurityParameters?.SaslUsername,
                SaslPassword = inputParametersKafka.Value?.SecurityParameters?.SaslPassword,
                Partitioner = Partitioner.Random,
            };

            _producer = new ProducerBuilder<string, string>(config).Build();
        }
        public async Task PublishEvent<T>(T message)
        {
            var jsonMessage = JsonSerializer.Serialize(message);
            await _producer.ProduceAsync(_topic, new Message<string, string> { Key = Guid.NewGuid().ToString(), Value = jsonMessage });
        }
    }
}
