﻿namespace EventBus.Kafka.Models
{
    public class DatabaseSettings
    {
        public string ConnectionString  { get; set; } = string.Empty;
        public bool AtivarLog { get; set; } = false;
    }
}
