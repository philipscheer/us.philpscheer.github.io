﻿namespace EventBus.Kafka.Models
{
    public class EventMessageModel : BaseEntity
    {
        public string EventType { get; set; } = string.Empty;
        public string Payload { get; set; } = string.Empty;
    }
}
