﻿using System.Data;
using Dapper;
using EventBus.Kafka.Helpers;
using EventBus.Kafka.Models;
using Microsoft.Extensions.Options;
using Oracle.ManagedDataAccess.Client;
using Polly.Retry;

namespace EventBus.Kafka.Infrastructure.Oracle
{
    public class OracleEventRepository<T> where T : class
    {
        private readonly string _connectionString;
        private readonly AsyncRetryPolicy _dbRetrypolicy;

        public OracleEventRepository(IOptions<DatabaseSettings> databaseSettings)
        {
            _connectionString = databaseSettings.Value.ConnectionString;
            _dbRetrypolicy = ResilienceHelper.GetDatabaseRetryPolicy();
        }

        private IDbConnection CreateConnection() => new OracleConnection(_connectionString);

        public async Task<IEnumerable<T>> GetAllAsync(string tableName)
        {
            return await _dbRetrypolicy.ExecuteAsync(async () => {
                using var connection = CreateConnection();
                return await connection.QueryAsync<T>($"SELECT * FROM {tableName}");
            });
        }

        public async Task<int> AddAsync(string tableName, object parameters)
        {

            return await _dbRetrypolicy.ExecuteAsync(async () => {
                ValidationHelper.EnsureNotNullOrEmpty(tableName, nameof(tableName), "O nome da tabela é obrigatório.");

                using var connection = CreateConnection();

                var properties = parameters.GetType().GetProperties().Select(p => p.Name);
                var columns = string.Join(", ", properties);
                var values = string.Join(", ", properties.Select(p => $":{p}"));

                var sql = $"INSERT INTO {tableName} ({columns}) VALUES ({values})";

                return await connection.ExecuteAsync(sql, parameters);
            });
        }

        public async Task<int> UpdateAsync(string tableName, object parameters, Guid id)
        {

            return await _dbRetrypolicy.ExecuteAsync(async () => {
                ValidationHelper.EnsureNotNullOrEmpty(tableName, nameof(tableName), "O nome da tabela é obrigatório.");

                using var connection = CreateConnection();
                var sql = $"UPDATE {tableName} SET " +
                          $"{string.Join(", ", parameters.GetType().GetProperties().Select(p => $"{p.Name} = :{p.Name}"))} " +
                          "WHERE Id = :Id";

                var parametersWithId = new DynamicParameters(parameters);
                parametersWithId.Add("Id", id);

                return await connection.ExecuteAsync(sql, parametersWithId);
            });
        }

        public async Task<int> DeleteAsync(string tableName, Guid id)
        {
            return await _dbRetrypolicy.ExecuteAsync(async () => {
                ValidationHelper.EnsureNotNullOrEmpty(tableName, nameof(tableName), "O nome da tabela é obrigatório.");

                using var connection = CreateConnection();
                return await connection.ExecuteAsync($"DELETE FROM {tableName} WHERE Id = :Id", new { Id = id });
            });
        }
    }
}
