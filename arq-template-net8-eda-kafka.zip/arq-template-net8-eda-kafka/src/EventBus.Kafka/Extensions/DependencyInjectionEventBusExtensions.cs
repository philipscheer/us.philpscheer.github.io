﻿using EventBus.Kafka.Background;
using EventBus.Kafka.Events;
using EventBus.Kafka.Infrastructure.Oracle;
using EventBus.Kafka.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace EventBus.Kafka.Extensions
{
    public static class DependencyInjectionEventBusExtensions
    {
        public static IServiceCollection AddKafkaAndDatabaseServices(this IServiceCollection services, IConfiguration configuration)
        {
            // Configuração de IOptions<T>
            services.Configure<InputParameterskafka>(configuration.GetSection("KafkaSettingsEDA"));
            services.Configure<DatabaseSettings>(configuration.GetSection("DatabaseSettingsEDA"));

            // Registro Repository
            services.AddScoped(typeof(OracleEventRepository<>));

            // Configuração do Event Publisher (Producer)
            services.AddSingleton<EventPublisher>(provider =>
            {
                var kafkaSettings = provider.GetRequiredService<IOptions<InputParameterskafka>>();
                return new EventPublisher(kafkaSettings);
            });

            // Configuração do Event Subscriber (Consumer)
            services.AddSingleton<EventSubscriber<EventMessageModel>>(provider =>
            {
                var kafkaSettings = provider.GetRequiredService<IOptions<InputParameterskafka>>();
                return new EventSubscriber<EventMessageModel>(kafkaSettings);
            });

            // Configuração do Background Service para o Event Subscriber (Consumer)
            services.AddHostedService<EventSubscriberService>();

            return services;
        }
    }
}
