﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Template.Domain.Events;
using Template.Domain.Repositorios;

namespace Template.Domain.Repositorios
{
    public class WeatherForecastCreatedHandler : IDomainEventHandler<WeatherForecastCreated>
    {
        public void Handle(WeatherForecastCreated @event)
        {
            // Handle the event (e.g., log it, update a cache, etc.)
            Console.WriteLine($"Weather forecast created: Id={@event.Id}, Date={@event.Date}, TemperatureC={@event.TemperatureC}, Summary={@event.Summary}");
        }
    }

    public class WeatherForecastUpdatedHandler : IDomainEventHandler<WeatherForecastUpdated>
    {
        public void Handle(WeatherForecastUpdated @event)
        {
            // Handle the event
            Console.WriteLine($"Weather forecast updated: Id={@event.Id}, Date={@event.Date}, TemperatureC={@event.TemperatureC}, Summary={@event.Summary}");
        }
    }

    public class WeatherForecastDeletedHandler : IDomainEventHandler<WeatherForecastDeleted>
    {
        public void Handle(WeatherForecastDeleted @event)
        {
            // Handle the event
            Console.WriteLine($"Weather forecast deleted: Id={@event.Id}");
        }
    }
    public interface IDomainEventHandler<in TEvent> where TEvent : IDomainEvent
    {
        void Handle(TEvent @event);
    }
}
