namespace Template.Domain.Repositorios
{
    public interface IWeatherRepository: IWeatherReadRepository, IWeatherWriteRepository
    {
         
    }
}