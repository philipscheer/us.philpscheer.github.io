﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Template.Domain.Events;
using Template.Domain.Repositorios; 

namespace Template.CrossCutting.InjecaoDependencia
{
    public static class DomainEventServiceCollectionExtensions
    {
        public static IServiceCollection AddDomainEventHandlers(this IServiceCollection services)
        {
            services.AddSingleton<IDomainEventPublisher, DomainEventPublisher>();

            services.AddTransient<IDomainEventHandler<WeatherForecastCreated>, WeatherForecastCreatedHandler>();
            services.AddTransient<IDomainEventHandler<WeatherForecastUpdated>, WeatherForecastUpdatedHandler>();
            services.AddTransient<IDomainEventHandler<WeatherForecastDeleted>, WeatherForecastDeletedHandler>();

            return services;
        }
    }
}
