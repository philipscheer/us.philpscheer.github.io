﻿global using System.Text.Json.Serialization;
global using EventBus.Events;
