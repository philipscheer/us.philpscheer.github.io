﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EventBus.Extensions;

public static class TypeExtensions
{
    public static string GetFormattedTypeName(this Type type)
    {
        if (type.IsGenericType)
        {
            var genericArguments = string.Join(",", type.GetGenericArguments().Select(t => t.Name));
            return $"{type.Name.Substring(0, type.Name.IndexOf('`'))}<{genericArguments}>";
        }
        return type.Name;
    }

    public static string GetFormattedTypeName(this object obj)
    {
        return obj.GetType().GetFormattedTypeName();
    }
}
