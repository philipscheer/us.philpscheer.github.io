﻿using System.Diagnostics.CodeAnalysis;
using System.Text;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Hosting;
using OpenTelemetry.Context.Propagation;
using System.Diagnostics;
using Polly;
using Polly.Retry;
using Microsoft.Extensions.DependencyInjection;
using OpenTelemetry;

namespace Template.EventBusKafka;
public sealed class KafkaEventBus(
                        LogManager.Domain.ILogger logger,
                        IServiceProvider serviceProvider,
                        IOptions<EventBusOptions> options,
                        IOptions<EventBusSubscriptionInfo> subscriptionOptions,
                        KafkaTelemetry kafkaTelemetry) : IEventBus, IDisposable, IHostedService
    {
        private readonly AsyncRetryPolicy _pipeline = CreateResiliencePipeline(options.Value.RetryCount);
        private readonly TextMapPropagator _propagator = kafkaTelemetry.Propagator;
        private readonly ActivitySource _activitySource = KafkaTelemetry.ActivitySource;
        private readonly string _topicName = options.Value.SubscriptionClientName;
        private readonly EventBusSubscriptionInfo _subscriptionInfo = subscriptionOptions.Value;
        private IProducer<Null, string> _producer;
        private IConsumer<Null, string> _consumer;

        public Task PublishAsync(IntegrationEvent @event)
        {
            var routingKey = @event.GetType().Name;

            // Removed the IsEnabled check and directly log the message
            logger.Debug("Creating Kafka producer to publish event: {EventId} ({EventName})", @event.Id, routingKey);

            var body = SerializeMessage(@event);

            var activityName = $"{routingKey} publish";

            return _pipeline.ExecuteAsync(async () =>
            {
                using var activity = _activitySource.StartActivity(activityName, ActivityKind.Client);

                ActivityContext contextToInject = default;

                if (activity != null)
                {
                    contextToInject = activity.Context;
                }
                else if (Activity.Current != null)
                {
                    contextToInject = Activity.Current.Context;
                }

                var headers = new Headers();
                _propagator.Inject(new PropagationContext(contextToInject, Baggage.Current), headers, (h, k, v) => h.Add(k, System.Text.Encoding.UTF8.GetBytes(v)));

                SetActivityContext(activity, routingKey, "publish");

                // Removed the IsEnabled check and directly log the message
                logger.Debug("Publishing event to Kafka: {EventId}", @event.Id);

                try
                {
                    _producer.Produce(_topicName, new Message<Null, string> { Value = Encoding.UTF8.GetString(body), Headers = headers }, deliveryReport =>
                    {
                        if (deliveryReport.Error.Code != ErrorCode.NoError)
                        {
                            throw new InvalidOperationException($"Failed to deliver message: {deliveryReport.Error.Reason}");
                        }
                    });

                    await Task.CompletedTask;
                }
                catch (Exception ex)
                {
                    activity.SetExceptionTags(ex);

                    throw;
                }
            });
        }

        private static void SetActivityContext(Activity activity, string routingKey, string operation)
        {
            if (activity is not null)
            {
                activity.SetTag("messaging.system", "kafka");
                activity.SetTag("messaging.destination_kind", "topic");
                activity.SetTag("messaging.operation", operation);
                activity.SetTag("messaging.destination.name", routingKey);
            }
        }

        public void Dispose()
        {
            _consumer?.Dispose();
            _producer?.Dispose();
        }

        private async Task OnMessageReceived(object sender, Message<Null, string> message, string topic)
        {
            var headers = message.Headers;
            var parentContext = _propagator.Extract(default, headers, (h, k) => h.TryGetLastBytes(k, out var value) ? new[] { System.Text.Encoding.UTF8.GetString(value) } : Array.Empty<string>());
            Baggage.Current = parentContext.Baggage;

            var activityName = $"{topic} receive";

            using var activity = _activitySource.StartActivity(activityName, ActivityKind.Client, parentContext.ActivityContext);

            SetActivityContext(activity, topic, "receive");

            var eventName = topic;
            var body = message.Value;

            try
            {
                activity?.SetTag("message", body);

                if (body.Contains("throw-fake-exception", StringComparison.InvariantCultureIgnoreCase))
                {
                    throw new InvalidOperationException($"Fake exception requested: \"{body}\"");
                }

                await ProcessEvent(eventName, body);
            }
            catch (Exception ex)
            {
                logger.Error(ex, "Error Processing message \"{Message}\"", body);

                activity.SetExceptionTags(ex);
            }
        }

        private async Task ProcessEvent(string eventName, string message)
        {
            // Removed the IsEnabled check and directly log the message
            logger.Debug("Processing Kafka event: {EventName}", eventName);

            await using var scope = serviceProvider.CreateAsyncScope();

            if (!_subscriptionInfo.EventTypes.TryGetValue(eventName, out var eventType))
            {
                logger.Error("Unable to resolve event type for event name {EventName}", eventName);
                return;
            }

            var integrationEvent = DeserializeMessage(message, eventType);

            foreach (var handler in scope.ServiceProvider.GetKeyedServices<IIntegrationEventHandler>(eventType))
            {
                await handler.Handle(integrationEvent);
            }
        }

        [UnconditionalSuppressMessage("Trimming", "IL2026:RequiresUnreferencedCode",
            Justification = "The 'JsonSerializer.IsReflectionEnabledByDefault' feature switch, which is set to false by default for trimmed .NET apps, ensures the JsonSerializer doesn't use Reflection.")]
        [UnconditionalSuppressMessage("AOT", "IL3050:RequiresDynamicCode", Justification = "See above.")]
        private IntegrationEvent DeserializeMessage(string message, Type eventType)
        {
            return JsonSerializer.Deserialize(message, eventType, _subscriptionInfo.JsonSerializerOptions) as IntegrationEvent;
        }

        [UnconditionalSuppressMessage("Trimming", "IL2026:RequiresUnreferencedCode",
            Justification = "The 'JsonSerializer.IsReflectionEnabledByDefault' feature switch, which is set to false by default for trimmed .NET apps, ensures the JsonSerializer doesn't use Reflection.")]
        [UnconditionalSuppressMessage("AOT", "IL3050:RequiresDynamicCode", Justification = "See above.")]
        private byte[] SerializeMessage(IntegrationEvent @event)
        {
            return JsonSerializer.SerializeToUtf8Bytes(@event, @event.GetType(), _subscriptionInfo.JsonSerializerOptions);
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            var config = new ConsumerConfig
            {
                GroupId = _topicName,
                BootstrapServers = "localhost:9092",
                AutoOffsetReset = AutoOffsetReset.Earliest
            };

            _consumer = new ConsumerBuilder<Null, string>(config).Build();
            _consumer.Subscribe(_topicName);

            Task.Run(() =>
            {
                while (!cancellationToken.IsCancellationRequested)
                {
                    try
                    {
                        var message = _consumer.Consume(cancellationToken);
                        OnMessageReceived(this, message.Message, message.Topic).Wait();
                    }
                    catch (Exception ex)
                    {
                        logger.Error(ex, "Error consuming Kafka message");
                    }
                }
            }, cancellationToken);

            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _consumer?.Close();
            return Task.CompletedTask;
        }

        private static AsyncRetryPolicy CreateResiliencePipeline(int retryCount)
        {
            return Policy
                .Handle<KafkaException>()
                .WaitAndRetryAsync(retryCount, attempt => TimeSpan.FromSeconds(Math.Pow(2, attempt)));
        }
    }

