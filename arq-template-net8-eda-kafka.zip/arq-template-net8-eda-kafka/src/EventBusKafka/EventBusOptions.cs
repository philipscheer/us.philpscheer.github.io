﻿namespace EventBusKafka;

public class EventBusOptions
{
    public string SubscriptionClientName { get; set; }
    public int RetryCount { get; set; }
    public string BootstrapServers { get; set; }
}
