﻿using System.Diagnostics;
using OpenTelemetry.Context.Propagation;
using OpenTelemetry;

namespace EventBusKafka
{
    public class KafkaTelemetry
    {
        public static readonly ActivitySource ActivitySource = new(KafkaTelemetry.ActivitySourceName);
        public const string ActivitySourceName = "KafkaTelemetry";
        public TextMapPropagator Propagator { get; } = Propagators.DefaultTextMapPropagator;

        public async Task ProduceAsync<TKey, TValue>(IProducer<TKey, TValue> producer, string topic, Message<TKey, TValue> message)
        {
            using var activity = ActivitySource.StartActivity("Produce", ActivityKind.Producer);
            activity?.SetTag("messaging.system", "kafka");
            activity?.SetTag("messaging.destination", topic);

            await producer.ProduceAsync(topic, message);
        }

        public void Consume<TKey, TValue>(IConsumer<TKey, TValue> consumer, string topic, Action<ConsumeResult<TKey, TValue>> handler)
        {
            using var activity = ActivitySource.StartActivity("Consume", ActivityKind.Consumer);
            activity?.SetTag("messaging.system", "kafka");
            activity?.SetTag("messaging.destination", topic);

            var consumeResult = consumer.Consume();
            handler(consumeResult);
        }
    }
}
