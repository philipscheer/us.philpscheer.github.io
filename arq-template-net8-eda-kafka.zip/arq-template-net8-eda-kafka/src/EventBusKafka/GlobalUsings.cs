﻿global using System.Text.Json;
global using EventBus.Abstractions;
global using EventBus.Events;
global using Microsoft.Extensions.Logging;
global using EventBusKafka;
global using Confluent.Kafka;