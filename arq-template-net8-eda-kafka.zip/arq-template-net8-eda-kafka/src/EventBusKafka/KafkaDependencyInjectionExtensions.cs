﻿using System;
using Confluent.Kafka;
using EventBusKafka;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using OpenTelemetry.Trace;
using OpenTelemetry.Resources;
using OpenTelemetry.Metrics;
using Template.EventBusKafka;


namespace Microsoft.Extensions.Hosting;
public static class KafkaDependencyInjectionExtensions
{
    private const string SectionName = "EventBus";

    public static IEventBusBuilder AddKafkaEventBus(this IHostBuilder builder)
    {
        ArgumentNullException.ThrowIfNull(builder);

        builder.ConfigureServices((context, services) =>
        {
            // Options support
            services.Configure<EventBusOptions>(context.Configuration.GetSection(SectionName));

            // Kafka client configuration
            services.AddSingleton(sp =>
            {
                var options = sp.GetRequiredService<IOptions<EventBusOptions>>().Value;
                return new ProducerConfig
                {
                    BootstrapServers = options.BootstrapServers
                };
            });

            services.AddSingleton(sp =>
            {
                var options = sp.GetRequiredService<IOptions<EventBusOptions>>().Value;
                return new ConsumerConfig
                {
                    GroupId = options.SubscriptionClientName,
                    BootstrapServers = options.BootstrapServers,
                    AutoOffsetReset = AutoOffsetReset.Earliest
                };
            });

            // Kafka doesn't have built-in support for OpenTelemetry, so we need to add it ourselves
            // builder.Services.AddOpenTelemetry()
            //.WithTracing(tracing =>
            // {
            //    tracing.AddSource(KafkaTelemetry.ActivitySourceName);
            //});

            // Abstractions on top of the core client API
            services.AddSingleton<KafkaTelemetry>();
            services.AddSingleton<IEventBus, KafkaEventBus>();
            // Start consuming messages as soon as the application starts
            services.AddSingleton<IHostedService>(sp => (KafkaEventBus)sp.GetRequiredService<IEventBus>());
        });

        return new EventBusBuilder(builder);
    }

    private sealed class EventBusBuilder : IEventBusBuilder
    {
        public EventBusBuilder(IHostBuilder builder)
        {
            Services = new ServiceCollection();
            builder.ConfigureServices((context, services) =>
            {
                foreach (var service in Services)
                {
                    services.Add(service);
                }
            });
        }

        public IServiceCollection Services { get; }
    }
}
