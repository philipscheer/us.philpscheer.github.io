using MediatR;

namespace Template.Application.Querys.LastWeatherForecast
{
    public class LastWeatherForecastRequest : IRequest<LastWeatherForecastResponse>
    {
        
    }
}