namespace Template.Application.Response
{
    public class ApiMetaDataResponse
    {
        public int code { get; set; }

        public string pagination { get; set; }
    }
}