namespace Template.Batch.Commands
{
    public class Lote<T>
    {
        
    }
}