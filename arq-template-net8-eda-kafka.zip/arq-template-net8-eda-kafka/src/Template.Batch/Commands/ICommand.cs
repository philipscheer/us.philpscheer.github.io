
namespace Template.Batch.Commands
{
    public interface ICommand{
        void OnExecute();

    }
}