
create table WeatherForecast(
Id int auto_increment,
Date DateTime,
TemperatureC int,
Summary varchar(255),
KEY(Id)
)

create table exemplo1(
    Id int auto_increment,    
    Nome varchar(255),
    Descricao varchar(255),
    exemplo1_id int,
    KEY(Id)
)