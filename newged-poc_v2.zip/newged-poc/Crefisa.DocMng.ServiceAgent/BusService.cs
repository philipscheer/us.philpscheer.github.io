﻿using System;
using System.Collections.Generic;
using Crefisa.DocMng.ServiceAgent.ProxyServiceBus;
using Crefisa.Infraestrutura.Log;

namespace Crefisa.DocMng.ServiceAgent
{
    public static class BusService
    {

        public static ParamProcessoExecucao GravarProcessoExecucao<T>(T ObjInput)
        {
            ParamProcessoExecucao pr = new ParamProcessoExecucao();
            pr.NomeProcesso = "DOC_MNG";
            pr.DtInicioExecucao = DateTime.Now;
            pr.DescDadosRecebidos = Crefisa.Infraestrutura.Serializers.SerializerContext.Serialize<T>(ObjInput, Comum.Entidades.Enumeradores.SerializerTypes.Json);
            pr.CodLogin = Environment.UserName;
            pr.NomeEquipamento = System.Net.Dns.GetHostName().ToString();

            IncluirProcessoExecucao(pr);

            return pr;
        }

        public static void AtualizarProcessoExecucao<T>(T ObjInput, ParamProcessoExecucao param)
        {
            param.DescDadosEnviados = Crefisa.Infraestrutura.Serializers.SerializerContext.Serialize<T>(ObjInput, Comum.Entidades.Enumeradores.SerializerTypes.Json);
            param.DtFimExecucao = DateTime.Now;
            AtualizarProcessoExecucao(param);
        }

        public static ParamProcessoExecucao IncluirProcessoExecucao(ParamProcessoExecucao param)
        {
            ParamProcessoExecucao ret = new ParamProcessoExecucao();

            try
            {
                using (var obj = new ProxyServiceBus.ServiceBusServiceClient())
                {
                    ret = obj.IncluirProcessoExecucao(param);
                }
            }
            catch (Exception ex)
            {
                LoggerManager.Instance.UseErrorFloodContention = false;
                LoggerManager.Instance.Error(ex, "[Crefisa.DocMng.ServiceAgent.IncluirProcessoExecucao] - Erro ao incluir processo execução.");
            }

            return ret;
        }

        public static void AtualizarProcessoExecucao(ParamProcessoExecucao param)
        {
            try
            {
                using (var obj = new ProxyServiceBus.ServiceBusServiceClient())
                {
                    obj.AtualizarProcessoExecucao(param);
                }
            }
            catch (Exception ex)
            {
                LoggerManager.Instance.UseErrorFloodContention = false;
                LoggerManager.Instance.Error(ex, "[Crefisa.DocMng.ServiceAgent.AtualizarProcessoExecucao] - Erro ao alterar processo execução.");
            }
        }

        public static IEnumerable<DocumentoConfigDTO> ConsultarDocumentoConfig(ProxyServiceBus.DocumentoConfigEntity param)
        {
            IEnumerable<DocumentoConfigDTO> ret = new List<DocumentoConfigDTO>();

            try
            {
                using (var obj = new ProxyServiceBus.ServiceBusServiceClient())
                {
                    ret = obj.ConsultarDocumentoConfig(param);
                }
            }
            catch (Exception ex)
            {
                LoggerManager.Instance.UseErrorFloodContention = false;
                LoggerManager.Instance.Error(ex, "[Crefisa.DocMng.ServiceAgent.BusService] - Erro ao consultar condiguração do documento.");
            }

            return ret;
        }

        public static DocumentoGeradoDTO IncluirDocumentoGerado(DocumentoGeradoDTO docGerado)
        {
            DocumentoGeradoDTO ret = new DocumentoGeradoDTO();

            try
            {
                using (var obj = new ProxyServiceBus.ServiceBusServiceClient())
                {
                    ret = obj.IncluirDocumentoGerado(docGerado);
                }
            }
            catch (Exception ex)
            {
                LoggerManager.Instance.UseErrorFloodContention = false;
                LoggerManager.Instance.Error(ex, "[Crefisa.DocMng.ServiceAgent.BusService] - Erro ao incluir documento gerado.");
            }

            return ret;
        }

    }
}
