﻿using System;
using System.IO;
using System.Linq;
using Castle.MicroKernel.Registration;
using Castle.MicroKernel.SubSystems.Configuration;
using Castle.Windsor;
using Crefisa.DocMng.Contracts.Interface;
using Microsoft.Extensions.Hosting;

namespace Crefisa.DocMng.WCF.Installers
{
    public class DocumentInstaller : IWindsorInstaller
    {
        private readonly IHostingEnvironment _hostingEnvironment;

        public DocumentInstaller(IHostingEnvironment hostingEnvironment)
        {
            _hostingEnvironment = hostingEnvironment;
        }

        #region Atributes
        #endregion

        #region Public Methods

        public void Install(IWindsorContainer container, IConfigurationStore store)
        {
            Infraestrutura.Log.LoggerManager.Instance.Info("[DocumentInstaller.Install] - Iniciando Install");
            var pathToFind = (_hostingEnvironment.ContentRootPath == null ? AppDomain.CurrentDomain.BaseDirectory : Path.Combine(_hostingEnvironment.ContentRootPath, @"Plugins"));
            Infraestrutura.Log.LoggerManager.Instance.Info("[DocumentInstaller.Install] - Injection on {0} directory", pathToFind);

            try
            {
                Directory.GetDirectories(pathToFind).ToList().ForEach(directoryPlugin =>
                {
                    container.Register(Classes.FromAssemblyInDirectory(new AssemblyFilter(directoryPlugin))
                    .BasedOn<IDocumentController>().WithServiceFromInterface()
                    .LifestyleSingleton());
                }
                );
            }
            catch (Exception ex)
            {
                Infraestrutura.Log.LoggerManager.Instance.Error(ex, "[DocumentInstaller.Install] - Erro ao Install");
                throw;
            }

            Infraestrutura.Log.LoggerManager.Instance.Info("[DocumentInstaller.Install] - Finalizando Install");
        }

        #endregion

        #region Private Methods
        #endregion

    }
}
