﻿using System.ServiceModel;
using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.Contracts.DTO;

namespace Crefisa.DocMng.Contrato.Interface
{
    [ServiceContract]
    public interface IDocumentService
    {
        [OperationContract]
        DocMngDTO GenerateDocumentPdf(ParamGenerateDocPdf param);
    }
}
