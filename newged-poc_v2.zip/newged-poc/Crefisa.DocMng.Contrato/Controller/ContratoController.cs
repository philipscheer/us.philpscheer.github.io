﻿using System;
using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.Contracts.DTO;
using Crefisa.DocMng.Contracts.Enumerator;
using Crefisa.DocMng.Contracts.Interface;
using Crefisa.DocMng.Contrato.Business;


namespace Crefisa.DocMng.Contrato.Controller
{
    public class ContratoController : IDocumentController
    {

        #region Atributes

        public EnumDocumentType DocumentType { get; set; }

        #endregion

        #region Public Constructors

        #region ContratoController()
        /// <summary>
        /// Construtor padrão da classe ReciboController.
        /// </summary>
        public ContratoController()
        {
            DocumentType = EnumDocumentType.Proposta;
        }
        #endregion

        #endregion

        #region Public Methods

        #region GenerateDocumentPdf(ParamGenerateDocPdf param)
        /// <summary>
        /// Cria documento .PDF a partir de um arquivo .DOC
        /// </summary>
        /// <param name="param"></param>
        public DocMngDTO GenerateDocumentPdf(ParamGenerateDocPdf param)
        {
            try
            {
                DocMngDTO docMngDTO = new DocMngDTO();
                docMngDTO = ContratoBo.GenerateDocumentPdf(param);

                return docMngDTO;
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion

        #endregion

        #region Private Methods
        #endregion

    }
}
