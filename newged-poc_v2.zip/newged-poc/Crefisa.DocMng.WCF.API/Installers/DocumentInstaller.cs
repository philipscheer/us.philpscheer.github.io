﻿using Castle.MicroKernel.Registration;
using Castle.MicroKernel.SubSystems.Configuration;
using Castle.Windsor;
using Crefisa.DocMng.Contracts.Interface;
using Microsoft.Extensions.Hosting.Internal;

namespace Crefisa.DocMng.WCF.API.Installers
{
    public class DocumentInstaller : IWindsorInstaller
    {

        #region Atributes
        private readonly IWebHostEnvironment _env;
        #endregion

        public DocumentInstaller(IWebHostEnvironment env)
        {
            _env = env;
        }

        #region Public Methods

        public void Install(IWindsorContainer container, IConfigurationStore store)
        {
            Infraestrutura.Log.LoggerManager.Instance.Info("[DocumentInstaller.Install] - Iniciando Install");
            
            //var pathToFind = (HostingEnvironment.ApplicationPhysicalPath == null ? AppDomain.CurrentDomain.BaseDirectory : Path.Combine(HostingEnvironment.ApplicationPhysicalPath, @"Plugins"));

            var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            var pathToFind = _env.ContentRootPath != null ? Path.Combine(_env.ContentRootPath, "Plugins") : baseDirectory;


            Infraestrutura.Log.LoggerManager.Instance.Info("[DocumentInstaller.Install] - Injection on {0} directory", pathToFind);

            try
            {
                Directory.GetDirectories(pathToFind).ToList().ForEach(directoryPlugin =>
                {
                    container.Register(Classes.FromAssemblyInDirectory(new AssemblyFilter(directoryPlugin))
                    .BasedOn<IDocumentController>().WithServiceFromInterface()
                    .LifestyleSingleton());
                }
                );
            }
            catch (Exception ex)
            {
                Infraestrutura.Log.LoggerManager.Instance.Error(ex, "[DocumentInstaller.Install] - Erro ao Install");
                throw;
            }

            Infraestrutura.Log.LoggerManager.Instance.Info("[DocumentInstaller.Install] - Finalizando Install");
        }

        #endregion

        #region Private Methods
        #endregion

    }
}
