﻿using Crefisa.DocMng.Contracts.DTO;
using Crefisa.DocMng.Contracts.Enumerator;

namespace Crefisa.DocMng.Contracts.Interface
{
    public interface IDocumentController
    {

        EnumDocumentType DocumentType { get; set; }

        DocMngDTO GenerateDocumentPdf(ParamGenerateDocPdf param);

    }
}