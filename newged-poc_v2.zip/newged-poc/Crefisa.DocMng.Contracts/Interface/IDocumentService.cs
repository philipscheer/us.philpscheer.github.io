﻿using Crefisa.DocMng.Contracts.DTO;

namespace Crefisa.DocMng.Contracts.Interface
{
    //   [ServiceContract]
    public interface IDocumentService
    {
        //       [OperationContract]
        DocMngDTO GenerateDocumentPdf(ParamGenerateDocPdf param);
    }
}
