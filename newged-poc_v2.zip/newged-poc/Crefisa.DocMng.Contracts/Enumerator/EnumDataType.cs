﻿namespace Crefisa.DocMng.Contracts.Enumerator
{
    public enum EnumDataType
    {
        Undefined = 0,
        Xml = 1,
        Json = 2,
        Rest = 3
    }
}
