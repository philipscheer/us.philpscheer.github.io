﻿using System.Runtime.Serialization;
using Crefisa.DocMng.Contracts.Enumerator;

namespace Crefisa.DocMng.Contracts
{
    public class ParamGenerateDocPdf
    {
        [DataMember]
        public EnumDocumentType DocumentType { get; set; }

        [DataMember]
        public Crefisa.Comum.Entidades.Enumeradores.SerializerTypes SerializerTypes { get; set; }

        [DataMember]
        public string Data { get; set; }

        [DataMember]
        public string User { get; set; }

        [DataMember]
        public bool? RetornaBase64 { get; set; }
    }
}
