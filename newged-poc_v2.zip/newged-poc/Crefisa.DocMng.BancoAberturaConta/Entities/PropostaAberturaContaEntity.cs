﻿using System;
using Crefisa.Comum.Atributos;
using Crefisa.Comum.Interfaces;

namespace Crefisa.DocMng.BancoAberturaConta.Entities
{

    [EntidadeDB(ProcedureConsulta = "PC_DOC_SELCADASTROPFFILTRO")]
    public class PropostaAberturaContaEntity : IEntidadeDB
    {
        [ColunaDB("NOME_CLIENTE")]
        public string NomeCliente { get; set; }

        [ColunaDB("COD_SEXO")]
        public string CodSexo { get; set; }

        [ColunaDB("DATA_NASCIMENTO")]
        public DateTime DataNascimento { get; set; }

        [ColunaDB("NUM_CPF")]
        public decimal NumCPF { get; set; }

        [ColunaDB("DESC_PROFISSAO")]
        public string DescProfissao { get; set; }

        [ColunaDB("TIPO_DOCUMENTO")]
        public int TipoDocumento { get; set; }

        [ColunaDB("NUM_DOCTO")]
        public string NumDocto { get; set; }

        [ColunaDB("COD_ORG_EMIS")]
        public string CodOrgEmis { get; set; }

        [ColunaDB("DATA_EMISSAO_DOCTO")]
        public DateTime DataEmissaoDocto { get; set; }

        [ColunaDB("DESC_NATURALIDADE")]
        public string DescNaturalidade { get; set; }

        [ColunaDB("SIGLA_UF_NATU")]
        public string SiglaUFNatu { get; set; }

        [ColunaDB("DESC_NACIONALIDADE")]
        public string DescNacionalidade { get; set; }

        [ColunaDB("NOME_PAI")]
        public string NomePai { get; set; }

        [ColunaDB("NOME_MAE")]
        public string NomeMae { get; set; }

        [ColunaDB("DESC_ESTADO_CIVIL")]
        public string DescEstadoCivil { get; set; }

        [ColunaDB("NOME_CONJUGE")]
        public string NomeConjuge { get; set; }

        [ColunaDB("CPF_CONJUGE")]
        public decimal CPFConjuge { get; set; }

        [ColunaDB("DESC_LOGRADOURO")]
        public string DescLogradouro { get; set; }

        [ColunaDB("NUM_LOGRADOURO")]
        public string NumLogradouro { get; set; }

        [ColunaDB("DESC_COMPL_LOGR")]
        public string DescComplLogr { get; set; }

        [ColunaDB("DESC_BAIRRO")]
        public string DescBairro { get; set; }

        [ColunaDB("DESC_CIDADE")]
        public string DescCidade { get; set; }

        [ColunaDB("COD_CEP")]
        public int CodCEP { get; set; }

        [ColunaDB("DESC_TP_RESID")]
        public string DescTpResid { get; set; }

        [ColunaDB("NUM_AREA_TELEFONE")]
        public string NumAreaTelefone { get; set; }

        [ColunaDB("NUM_TELEFONE")]
        public int NumTelefone { get; set; }

        [ColunaDB("NUM_AREA_CELULAR")]
        public string NumAreaCelular { get; set; }

        [ColunaDB("NUM_CELULAR")]
        public int NumCelular { get; set; }

        [ColunaDB("EMAIL")]
        public string Email { get; set; }

        [ColunaDB("VAL_RENDA_BRUTA")]
        public decimal ValRendaBruta { get; set; }

        [ColunaDB("COD_CONTA")]
        public string CodConta { get; set; }

        [ColunaDB("COD_BANCO")]
        public int CodBanco { get; set; }

        [ColunaDB("COD_AGENCIA")]
        public int CodAgencia { get; set; }

        [ColunaDB("DIG_AGENCIA")]
        public string DigAgencia { get; set; }

        [ColunaDB("CONFIRMA_DOCUMENTO")]
        public string ConfirmaDocumento { get; set; }

        [ColunaDB("COD_LOJA")]
        public int CodLoja { get; set; }

        [ColunaDB("FLG_AUT_CONSULTA_PROT_CRED")]
        public string FlgAutConsultaProtCred { get; set; }

        [ColunaDB("FLG_AUT_CONSULTA_CHEQ_DEVO")]
        public string FlgAutConsultaCheqDev { get; set; }

        [ColunaDB("FLG_AUT_TRANSFERIR_VALORES")]
        public string FlgAutTransferirValores { get; set; }

        [ColunaDB("NOME_REPRESENTANTE")]
        public string NomeRepresentante { get; set; }

        [ColunaDB("CPF_REPRESENTANTE")]
        public decimal CPFRepresentante { get; set; }

        [ColunaDB("DESC_LOJA")]
        public string DescLoja { get; set; }

        [ColunaDB("TIPO_CONTA")]
        public string TipoConta { get; set; }

    }
}