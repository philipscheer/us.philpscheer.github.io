﻿using System;
using Crefisa.Comum.Atributos;
using Crefisa.Comum.Interfaces;

namespace Crefisa.DocMng.BancoAberturaConta.Entities
{

    [EntidadeDB(ProcedureConsulta = "PC_BPN_SELCADASTRO")]
    public class FichaCadPFEntity : IEntidadeDB
    {
        [ColunaDB("FLAG_TIPO_CLIENTE")]
        public string TipoCliente { get; set; }

        [ColunaDB("NOME_CLIENTE")]
        public string NomeCliente { get; set; }

        [ColunaDB("COD_SEXO")]
        public string CodSexo { get; set; }

        [ColunaDB("NUM_CPF")]
        public decimal? NumCPF { get; set; }

        [ColunaDB("DATA_NASCIMENTO")]
        public DateTime? DataNascimento { get; set; }

        [ColunaDB("DESC_PROFISSAO")]
        public string DescProfissao { get; set; }

        [ColunaDB("TIPO_DOCUMENTO")]
        public int? TipoDocumento { get; set; }

        [ColunaDB("NUM_DOCTO")]
        public string NumDocto { get; set; }

        [ColunaDB("ORG_EMISSAO_DOCTO")]
        public string OrgEmissaoDocto { get; set; }

        [ColunaDB("DATA_EMISSAO_DOCTO")]
        public DateTime? DataEmissaoDocto { get; set; }

        [ColunaDB("DATA_VALIDADE_DOCTO")]
        public DateTime? DataValidadeDocto { get; set; }

        [ColunaDB("DESC_NATURALIDADE")]
        public string DescNaturalidade { get; set; }

        [ColunaDB("SIGLA_UF_NATU")]
        public string SiglaUFNatu { get; set; }

        [ColunaDB("DESC_NACIONALIDADE")]
        public string DescNacionalidade { get; set; }

        [ColunaDB("DATA_ENTRADA_BRASIL")]
        public DateTime? DataEntradaBrasil { get; set; }

        [ColunaDB("FLAG_FATCA")]
        public string FlagFatca { get; set; }

        [ColunaDB("NOME_PAI")]
        public string NomePai { get; set; }

        [ColunaDB("NOME_MAE")]
        public string NomeMae { get; set; }

        [ColunaDB("COD_ESTADO_CIVIL")]
        public string CodEstadoCivil { get; set; }

        [ColunaDB("NOME_CONJUGE")]
        public string NomeConjuge { get; set; }

        [ColunaDB("CPF_CONJUGE")]
        public decimal? CpfConjuge { get; set; }

        [ColunaDB("DESC_LOGRADOURO")]
        public string DescLogradouro { get; set; }

        [ColunaDB("NUM_LOGRADOURO")]
        public string NumLogradouro { get; set; }

        [ColunaDB("DESC_COMPL_LOGR")]
        public string DescComplLogr { get; set; }

        [ColunaDB("DESC_BAIRRO")]
        public string DescBairro { get; set; }

        [ColunaDB("DESC_CIDADE")]
        public string DesCidade { get; set; }

        [ColunaDB("SIGLA_UF_END")]
        public string SiglaUFEnd { get; set; }

        [ColunaDB("COD_CEP")]
        public string CodCEP { get; set; }

        [ColunaDB("TIPO_RESIDENCIA")]
        public string TipoResidencia { get; set; }

        [ColunaDB("FLAG_TEL_PROPRIO")]
        public string TelefoneProprio { get; set; }

        [ColunaDB("FLAG_TEL_RECADO")]
        public string TelefoneRecado { get; set; }

        [ColunaDB("NUM_AREA_TELEFONE")]
        public string NumAreaTelefone { get; set; }

        [ColunaDB("NUM_TELEFONE")]
        public int? NumTelefone { get; set; }

        [ColunaDB("NUM_AREA_CELULAR")]
        public string NumAreaCelular { get; set; }

        [ColunaDB("NUM_CELULAR")]
        public int? NumCelular { get; set; }

        [ColunaDB("EMAIL")]
        public string Email { get; set; }

        [ColunaDB("DESC_RAZAO_SOCIAL")]
        public string DescRazaoSocial { get; set; }

        [ColunaDB("DESC_LOGRADOURO_EMP")]
        public string DescLogradouroEmp { get; set; }

        [ColunaDB("NUM_LOGRADOURO_EMP")]
        public string NumLogradouroEmp { get; set; }

        [ColunaDB("DESC_COMPL_LOGR_EMP")]
        public string DescComplLogrEmp { get; set; }

        [ColunaDB("DESC_BAIRRO_EMP")]
        public string DescBairroEmp { get; set; }

        [ColunaDB("DESC_CIDADE_EMP")]
        public string DescCidadeEmp { get; set; }

        [ColunaDB("SIGLA_UF_END_EMP")]
        public string SiglaUFEndEmp { get; set; }

        [ColunaDB("COD_CEP_EMP")]
        public string CodCEPEmp { get; set; }

        [ColunaDB("NOME_REFERENCIA")]
        public string NomeReferencia { get; set; }

        [ColunaDB("NUM_AREA_TELEFONE_REF")]
        public int? NumAreaTelefoneRef { get; set; }

        [ColunaDB("NUM_TELEFONE_REF")]
        public int? NumTelefoneRef { get; set; }

        [ColunaDB("VAL_RENDA_BRUTA")]
        public decimal? ValRendaBruta { get; set; }

        [ColunaDB("VAL_RENDIMENTOS")]
        public decimal? ValRendimentos { get; set; }

        [ColunaDB("DESC_RENDIMENTOS")]
        public string DescRendimentos { get; set; }

        [ColunaDB("FLAG_BENS_IMOVEIS")]
        public string FlagBensImoveis { get; set; }

        [ColunaDB("VAL_IMOVEIS")]
        public decimal? ValImoveis { get; set; }

        [ColunaDB("VAL_AUTOMOVEIS")]
        public decimal? ValAutomoveis { get; set; }

        [ColunaDB("VAL_AERONAVES")]
        public decimal? ValAeronaves { get; set; }

        [ColunaDB("VAL_EMBARCACOES")]
        public decimal? ValEmbarcacoes { get; set; }

        [ColunaDB("VAL_INVESTIMENTOS")]
        public decimal? ValInvestimentos { get; set; }

        [ColunaDB("VAL_JOIAS")]
        public decimal? ValJoias { get; set; }

        [ColunaDB("VAL_OBRAS_ARTE")]
        public decimal? ValObrasArte { get; set; }

        [ColunaDB("VAL_OUTROS")]
        public decimal? ValOutros { get; set; }

        [ColunaDB("FLAG_PPE")]
        public string FlagPPE { get; set; }

        [ColunaDB("NOME_REPRESENTANTE")]
        public string NomeRepresentante { get; set; }

        [ColunaDB("CPF_REPRESENTANTE")]
        public decimal? CPFRepresentante { get; set; }

        [ColunaDB("COD_LOJA")]
        public int? CodLoja { get; set; }

        [ColunaDB("DESC_LOJA")]
        public string DescLoja { get; set; }

        [ColunaDB("DESC_CIDADE_LOJA")]
        public string DescCidadeLoja { get; set; }

        [ColunaDB("COD_CONTA")]
        public string CodConta { get; set; }

        [ColunaDB("COD_BANCO")]
        public int? CodBanco { get; set; }

        [ColunaDB("COD_AGENCIA")]
        public int? CodAgencia { get; set; }

        [ColunaDB("DIG_AGENCIA")]
        public string DigAgencia { get; set; }

        [ColunaDB("TIPO_CONTA")]
        public string TipoConta { get; set; }

    }
}