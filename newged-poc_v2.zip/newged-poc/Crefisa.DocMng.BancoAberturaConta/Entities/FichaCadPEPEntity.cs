﻿using System;
using Crefisa.Comum.Atributos;
using Crefisa.Comum.Interfaces;

namespace Crefisa.DocMng.BancoAberturaConta.Entities
{

    [EntidadeDB(ProcedureConsulta = "PC_BPN_SELCADASTRO_PEP")]
    public class FichaCadPEPEntity : IEntidadeDB
    {
        [ColunaDB("NUM_CPF")]
        public decimal? NumCPF { get; set; }

        [ColunaDB("NOME_CLIENTE")]
        public string NomeCliente { get; set; }

        [ColunaDB("FLG_FUNCAO_PUBLICA")]
        public string FlgFuncaoPublica { get; set; }

        [ColunaDB("DESC_CARGO")]
        public string Cargo { get; set; }

        [ColunaDB("DATA_INICIO")]
        public DateTime? DataInicio { get; set; }

        [ColunaDB("DATA_FIM")]
        public DateTime? DataFim { get; set; }

        [ColunaDB("EMPRESA")]
        public string Empresa { get; set; }

        [ColunaDB("FLG_REL_AGENTE_PUBLICO")]
        public string FlgAgentePublico { get; set; }

        [ColunaDB("NOME_RELACIONADO")]
        public string NomeRelacionado { get; set; }

        [ColunaDB("NUM_CPF_RELACIONADO")]
        public decimal? NumCPFRelacionado { get; set; }

        [ColunaDB("DESC_CARGO_RELACIONADO")]
        public string CargoRelacionado { get; set; }

        [ColunaDB("TIPO_RELACIONAMENTO")]
        public string TipoRelacionamento { get; set; }

        [ColunaDB("COD_LOJA")]
        public int? CodLoja { get; set; }

        [ColunaDB("DESC_LOJA")]
        public string DescLoja { get; set; }

        [ColunaDB("DESC_CIDADE")]
        public string DescCidadeLoja { get; set; }

    }
}