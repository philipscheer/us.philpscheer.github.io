﻿using Crefisa.Comum.Atributos;
using Crefisa.Comum.Interfaces;

namespace Crefisa.DocMng.BancoAberturaConta.Entities
{

    [EntidadeDB(ProcedureConsulta = "PC_BPN_SELCADASTRO_FATCA")]
    public class FichaCadFATCAEntity : IEntidadeDB
    {
        [ColunaDB("NUM_CPF")]
        public decimal? NumCPF { get; set; }

        [ColunaDB("NOME_CLIENTE")]
        public string NomeCliente { get; set; }

        [ColunaDB("LOCAL_NASCIMENTO")]
        public string LocalNascimento { get; set; }

        [ColunaDB("LOGRADOURO")]
        public string Logradouro { get; set; }

        [ColunaDB("NUMERO")]
        public int? Numero { get; set; }

        [ColunaDB("COMPLEMENTO")]
        public string Complemento { get; set; }

        [ColunaDB("BAIRRO")]
        public string Bairro { get; set; }

        [ColunaDB("CIDADE")]
        public string Cidade { get; set; }

        [ColunaDB("CEP")]
        public string Cep { get; set; }

        [ColunaDB("PAIS")]
        public string Pais { get; set; }

        [ColunaDB("FLG_ESTUDANTE")]
        public string FlgEstudante { get; set; }

        [ColunaDB("FLG_DIPLOMATA")]
        public string FlgDiplomata { get; set; }

        [ColunaDB("FLG_CONJUGE")]
        public string FlgConjuge { get; set; }

        [ColunaDB("FLG_PRESENCA_SUBSTANCIAL")]
        public string FlgPresencaSubstancial { get; set; }

        [ColunaDB("FLG_ABDIQUEI_NAC")]
        public string FlgAbdiqueiNac { get; set; }

        [ColunaDB("FLG_RENUNCIEI")]
        public string FlgRenunciei { get; set; }

        [ColunaDB("FLG_VISTO_GREENCARD")]
        public string FlgVistoGreenCard { get; set; }

        [ColunaDB("FLG_CERTIF_ABANDONO")]
        public string FlgCertifAbandono { get; set; }

        [ColunaDB("COD_LOJA")]
        public int? CodLoja { get; set; }

        [ColunaDB("DESC_LOJA")]
        public string DescLoja { get; set; }

        [ColunaDB("DESC_CIDADE")]
        public string DescCidadeLoja { get; set; }

        [ColunaDB("NUM_DIAS_EUA_ANOCORRENTE")]
        public int NumDiasEUACorrente { get; set; }

        [ColunaDB("NUM_DIAS_EUA_ANOPASSADO")]
        public int NumDiasEUAPassado { get; set; }

        [ColunaDB("NUM_DIAS_EUA_ANOANTERIOR")]
        public int NumDiasEUAAnterior { get; set; }

    }
}