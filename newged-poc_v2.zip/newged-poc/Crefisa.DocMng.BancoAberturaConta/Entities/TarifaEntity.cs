﻿using Crefisa.Comum.Atributos;
using Crefisa.Comum.Interfaces;

namespace Crefisa.DocMng.BancoAberturaConta.Entities
{
    [EntidadeDB]
    public class TarifaEntity : IEntidadeDB
    {
        [ColunaDB("CODTARIFA")]
        public string Codigo { get; set; }

        [ColunaDB("NOME")]
        public string Nome { get; set; }

        [ColunaDB("TIPOTARIFA")]
        public string Tipo { get; set; }

        [ColunaDB("VALOR")]
        public decimal? Valor { get; set; }

        [ColunaDB("VLRMINIMO")]
        public decimal? ValorMinimo { get; set; }

        [ColunaDB("VLRMAXIMO")]
        public decimal? ValorMaximo { get; set; }
    }
}
