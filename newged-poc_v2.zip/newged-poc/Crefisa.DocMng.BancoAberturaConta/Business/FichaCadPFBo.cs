﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Crefisa.DocMng.BancoAberturaConta.DataAccess;
using Crefisa.DocMng.BancoAberturaConta.Entities;
using Crefisa.DocMng.BancoAberturaConta.Util;
using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.Contracts.DTO;
using Crefisa.DocMng.Contracts.Enumerator;
using Crefisa.Infraestrutura.Log;
using Spire.Doc.Fields;

namespace Crefisa.DocMng.BancoAberturaConta.Business
{
    public class FichaCadPFBo
    {
        #region Atributes

        #endregion

        #region Public Constructors

        #region FichaCadPFBo()
        /// <summary>
        /// Construtor padrão da classe FichaCadPFBo.
        /// </summary>
        public FichaCadPFBo()
        {

        }
        #endregion

        #endregion

        #region Public Methods

        #region GenerateDocumentPdf(ParamGenerateDocPdf param)
        /// <summary>
        /// Geração do Documento de acordo com o tipo do Documento
        /// </summary>
        /// <param name="param"></param>
        public static DocMngDTO GenerateDocumentPdf(ParamGenerateDocPdf param)
        {
            try
            {
                ServiceBus.ParamImpressaoDocto impressaoDoctoDTO = new ServiceBus.ParamImpressaoDocto();
                DocMngDTO docMngDTO;

                LoggerManager.Instance.Info("[FichaCadPFBo.GenerateDocumentPdf] - Descerializando XML campo [Data]");
                docMngDTO = Crefisa.Infraestrutura.Serializers.SerializerContext.Deserialize<DocMngDTO>(param.Data, param.SerializerTypes);
                LoggerManager.Instance.Info("[FichaCadPFBo.GenerateDocumentPdf] - Descerializando XML campo [Data] - OK");

                LoggerManager.Instance.Info("[FichaCadPFBo.GenerateDocumentPdf] - Método [trataCaminhoArquivoPDF] de configuração do diretório onde será salvo arquivo em PDF ...");
                string caminhoArquivoPDF = Utils.TratarCaminhoArquivoPDF(docMngDTO);
                string caminhoTemplate = Utils.TratarCaminhoTemplate(docMngDTO);
                LoggerManager.Instance.Info("[FichaCadPFBo.GenerateDocumentPdf] - Método [trataCaminhoArquivoPDF] de configuração do diretório onde será salvo arquivo em PDF ... - OK");

                //Consulta Dados do Cliente
                LoggerManager.Instance.Info("[FichaCadPFBo.GenerateDocumentPdf] - Consulta Dados do Cliente para emissão do Recibo em PDF");

                using (FichaCadPFDao obj = new FichaCadPFDao(Defines.ConnectionNameTstProd))
                {
                    IEnumerable<FichaCadPFEntity> ret = obj.ConsultarFichaCadPF(decimal.Parse(docMngDTO.CodigoExterno));

                    if (ret.Count() != 0)
                    {
                        foreach (var item in ret)
                        {
                            LoggerManager.Instance.Info("[FichaCadPFBo.GenerateDocumentPdf] - Ficha Cadastral em PDF para o CPF [" + item.NumCPF + "]");
                            LoggerManager.Instance.Info("[FichaCadPFBo.GenerateDocumentPdf] - Busca arquivo template [" + docMngDTO.NomeArquivo + "]");
                            Spire.Doc.Document document = new Spire.Doc.Document(System.IO.Path.Combine(caminhoTemplate, docMngDTO.NomeArquivo));

                            if (item.CPFRepresentante != null && item.CPFRepresentante.Value > 0)
                            {
                                var fileExtension = Path.GetExtension(docMngDTO.NomeArquivo);
                                var templateFileName = docMngDTO.NomeArquivo.Replace(fileExtension, "") + "Representante" + fileExtension;

                                document = new Spire.Doc.Document(System.IO.Path.Combine(caminhoTemplate, templateFileName));

                                IEnumerable<FichaCadPFEntity> retRep = obj.ConsultarFichaCadPF(item.CPFRepresentante.Value);

                                if (retRep.ToList().Count > 0)
                                    AdicionaValoresPDFRepresentante(document, retRep.FirstOrDefault());
                                else
                                    LoggerManager.Instance.Warning("CPF {0} do Representante nao encontrado no cadastro", item.CPFRepresentante.ToString());
                            }

                            if (AdicionaValoresPDF(document, item))
                            {
                                //Save doc file.
                                LoggerManager.Instance.Info("[FichaCadPFBo.GenerateDocumentPdf] - Salvar arquivo no diretório [" + docMngDTO.CaminhoArquivoPdf + "]");
                                docMngDTO.NomeArquivo = docMngDTO.NomeArquivo.Substring(0, docMngDTO.NomeArquivo.Length - 5) + "." + item.NumCPF + "." +
                                                            DateTime.Now.Day.ToString().PadLeft(2, '0') +
                                                            DateTime.Now.Month.ToString().PadLeft(2, '0') +
                                                            DateTime.Now.Year.ToString() + "." +
                                                            DateTime.Now.Hour.ToString().PadLeft(2, '0') +
                                                            DateTime.Now.Minute.ToString().PadLeft(2, '0')
                                                            + ".pdf";

                                //Save doc file.
                                LoggerManager.Instance.Info("[FichaCadPFBo.GenerateDocumentPdf] - Salvar arquivo no diretório [" + caminhoArquivoPDF + "]");
                                document.SaveToFile(System.IO.Path.Combine(caminhoArquivoPDF, System.IO.Path.ChangeExtension(docMngDTO.NomeArquivo, "pdf")), Spire.Doc.FileFormat.PDF);

                                docMngDTO.CaminhoArquivoPdf = caminhoArquivoPDF;

                                Utils.IncluirRegistroImpressao(docMngDTO, item.CodLoja != null ? item.CodLoja.Value : 0, (item.CPFRepresentante != null && item.CPFRepresentante.Value > 0 ? EnumDocumentType.FichaCadastroPessoFisiscaRepresentante : EnumDocumentType.FichaCadastroPessoFisisca));
                            }

                            LoggerManager.Instance.Info("[FichaCadPFBo.GenerateDocumentPdf] - Executa WebSevice OK");
                        }
                    }
                    else
                    {
                        LoggerManager.Instance.Info("[FichaCadPFBo.GenerateDocumentPdf] - Não existe Dados para a geração do Ficha Cadastral em PDF do contrato [" + docMngDTO.CodigoExterno + "]");
                        docMngDTO.NomeArquivo = "Arquivo não gerado para o cpf [" + docMngDTO.CodigoExterno + "]";
                    }

                    return docMngDTO;
                }
            }
            catch (Exception ex)
            {
                LoggerManager.Instance.Error(ex, "[FichaCadPFBo.GenerateDocumentPdf] - Erro ao gerar Ficha Cadastral em PDF", ex);
                throw; // Fix: Re-throw the original exception without using 'throw ex'
            }
        }
        #endregion

        #endregion

        #region Private Methods

        #region AdicionaValoresPDF(Spire.Doc.Document document, FichaCadPFEntity item)
        /// <summary>
        /// Adiciona valores nos campos mapeados ao PDF gerado
        /// </summary>
        /// <param name="document"></param>
        /// <param name="item"></param>
        /// <returns></returns>
        private static bool AdicionaValoresPDF(Spire.Doc.Document document, FichaCadPFEntity item)
        {
            try
            {
                //Adiciona valores aos atributos do arquivo que será gerado em PDF
                foreach (Spire.Doc.Fields.FormField field in document.Sections[0].Body.FormFields)
                {
                    switch (field.Name)
                    {
                        //case "chkCliente":
                        //    if (item.TipoCliente == "C")
                        //    {
                        //        CheckBoxFormField chkCliente = field as CheckBoxFormField;
                        //        chkCliente.Checked = true;
                        //    }
                        //    break;
                        //case "chkRepresentante":
                        //    if (item.TipoCliente == "R")
                        //    {
                        //        CheckBoxFormField chkRepresentante = field as CheckBoxFormField;
                        //        chkRepresentante.Checked = true;
                        //    }
                        //    break;
                        case "txtNomeCompleto":
                            field.Text = item.NomeCliente;
                            break;
                        case "chkMasculino":
                            if (item.CodSexo == "M")
                            {
                                CheckBoxFormField chkMasculino = field as CheckBoxFormField;
                                chkMasculino.Checked = true;
                            }
                            break;
                        case "chkFeminino":
                            if (item.CodSexo == "F")
                            {
                                CheckBoxFormField chkFeminino = field as CheckBoxFormField;
                                chkFeminino.Checked = true;
                            }
                            break;
                        case "txtDataNascimento":
                            field.Text = item.DataNascimento != null ? item.DataNascimento.Value.ToString("dd/MM/yyyy") : "";
                            break;
                        case "txtCPF1":
                            field.Text = item.NumCPF != null ? item.NumCPF.Value.ToString(@"000\.000\.000\-00") : "";
                            break;
                        case "txtProfissão":
                            field.Text = item.DescProfissao;
                            break;
                        case "chkRG":
                            if (item.TipoDocumento != null && item.TipoDocumento == 1)
                            {
                                CheckBoxFormField chkRG = field as CheckBoxFormField;
                                chkRG.Checked = true;
                            }
                            break;
                        case "txtDataEmissao":
                            field.Text = item.DataEmissaoDocto != null ? item.DataEmissaoDocto.Value.ToString("dd/MM/yyyy") : "";
                            break;
                        case "chkCNH":
                            if (item.TipoDocumento != null && item.TipoDocumento == 6)
                            {
                                CheckBoxFormField chkCNH = field as CheckBoxFormField;
                                chkCNH.Checked = true;
                            }
                            break;
                        case "chkCarteira":
                            if (item.TipoDocumento != null && item.TipoDocumento == 160)
                            {
                                CheckBoxFormField chkCarteira = field as CheckBoxFormField;
                                chkCarteira.Checked = true;
                            }
                            break;
                        case "chkRNE":
                            if (item.TipoDocumento != null && item.TipoDocumento == 55)
                            {
                                CheckBoxFormField chkRNE = field as CheckBoxFormField;
                                chkRNE.Checked = true;
                            }
                            break;
                        case "chkPassaporte":
                            if (item.TipoDocumento != null && item.TipoDocumento == 159)
                            {
                                CheckBoxFormField chkPassaporte = field as CheckBoxFormField;
                                chkPassaporte.Checked = true;
                            }
                            break;
                        case "chkOutros":
                            if (item.TipoDocumento != null &&
                                (item.TipoDocumento != 1 && item.TipoDocumento != 6 &&
                                item.TipoDocumento != 160 && item.TipoDocumento != 55 &&
                                item.TipoDocumento != 159))
                            {
                                CheckBoxFormField chkOutros = field as CheckBoxFormField;
                                chkOutros.Checked = true;
                            }
                            break;
                        case "txtNumeroDocumento":
                            field.Text = item.NumDocto;
                            break;
                        case "txtOrgaoEmissor":
                            field.Text = item.OrgEmissaoDocto;
                            break;
                        case "txtDataVencimento":
                            field.Text = item.DataValidadeDocto != null ? item.DataValidadeDocto.Value.ToString("dd/MM/yyyy") : "";
                            break;
                        case "txtLocalNascimento":
                            field.Text = item.DescNaturalidade;
                            break;
                        case "txtUF":
                            field.Text = item.SiglaUFNatu;
                            break;
                        case "txtNacionalidade":
                            field.Text = item.DescNacionalidade;
                            break;
                        case "txtDataEntrBrasil":
                            field.Text = item.DataEntradaBrasil != null ? item.DataEntradaBrasil.Value.ToString("dd/MM/yyyy") : "";
                            break;
                        case "chkSDomicilioFiscalS":
                            if (item.FlagFatca == "S")
                            {
                                CheckBoxFormField chkSDomicilioFiscalE = field as CheckBoxFormField;
                                chkSDomicilioFiscalE.Checked = true;
                            }
                            break;
                        case "chkNDomicilioFiscalN":
                            if (item.FlagFatca == "N")
                            {
                                CheckBoxFormField chkSDomicilioFiscalE = field as CheckBoxFormField;
                                chkSDomicilioFiscalE.Checked = true;
                            }
                            break;
                        case "txtNomePai":
                            field.Text = item.NomePai;
                            break;
                        case "txtNomeMae":
                            field.Text = item.NomeMae;
                            break;
                        case "chkSolteiro":
                            if (item.CodEstadoCivil.Replace(" ", "") == "6")
                            {
                                CheckBoxFormField chkSolteiro = field as CheckBoxFormField;
                                chkSolteiro.Checked = true;
                            }
                            break;
                        case "chkCasado":
                            if (item.CodEstadoCivil.Replace(" ", "") == "1" ||
                                item.CodEstadoCivil.Replace(" ", "") == "2" ||
                                item.CodEstadoCivil.Replace(" ", "") == "3" ||
                                item.CodEstadoCivil.Replace(" ", "") == "4")
                            {
                                CheckBoxFormField chkCasado = field as CheckBoxFormField;
                                chkCasado.Checked = true;
                            }
                            break;
                        case "chkUniaoEstavel":
                            if (item.CodEstadoCivil.Replace(" ", "") == "5")
                            {
                                CheckBoxFormField chkUniaoEstavel = field as CheckBoxFormField;
                                chkUniaoEstavel.Checked = true;
                            }
                            break;
                        case "chkDivorciado":
                            if (item.CodEstadoCivil.Replace(" ", "") == "7")
                            {
                                CheckBoxFormField chkDivorciado = field as CheckBoxFormField;
                                chkDivorciado.Checked = true;
                            }
                            break;
                        case "chkSepJudicialmente":
                            if (item.CodEstadoCivil.Replace(" ", "") == "8")
                            {
                                CheckBoxFormField chkSepJudicialmente = field as CheckBoxFormField;
                                chkSepJudicialmente.Checked = true;
                            }
                            break;
                        case "chkViuvo":
                            if (item.CodEstadoCivil.Replace(" ", "") == "9")
                            {
                                CheckBoxFormField chkViuvo = field as CheckBoxFormField;
                                chkViuvo.Checked = true;
                            }
                            break;
                        case "txtNomeConjuge":
                            field.Text = item.NomeConjuge;
                            break;
                        case "txtCPFConjuge":
                            field.Text = item.CpfConjuge != null ? item.CpfConjuge.Value.ToString(@"000\.000\.000\-00") : "";
                            break;
                        case "txtEndResidencial":
                            field.Text = item.DescLogradouro;
                            break;
                        case "txtNumero":
                            field.Text = item.NumLogradouro;
                            break;
                        case "txtComplemento":
                            field.Text = item.DescComplLogr;
                            break;
                        case "txtBairro":
                            field.Text = item.DescBairro;
                            break;
                        case "txtCidade":
                            field.Text = item.DesCidade;
                            break;
                        case "txtCEP":
                            field.Text = !string.IsNullOrEmpty(item.CodCEP) ? item.CodCEP.PadLeft(8, '0') : "";
                            break;
                        case "chkResPropria":
                            if (item.TipoResidencia.Trim() == "1" ||
                                item.TipoResidencia.Trim() == "2")
                            {
                                CheckBoxFormField chkResPropria = field as CheckBoxFormField;
                                chkResPropria.Checked = true;
                            }
                            break;
                        case "chkResPaisAvos":
                            if (item.TipoResidencia == "4" ||
                                item.TipoResidencia == "5" ||
                                item.TipoResidencia == "6")
                            {
                                CheckBoxFormField chkResPaisAvos = field as CheckBoxFormField;
                                chkResPaisAvos.Checked = true;
                            }
                            break;
                        case "chkResAlugada":
                            if (item.TipoResidencia == "3")
                            {
                                CheckBoxFormField chkResAlugada = field as CheckBoxFormField;
                                chkResAlugada.Checked = true;
                            }
                            break;
                        case "chkTelProprio":
                            if (item.TelefoneProprio != null && item.TelefoneProprio == "S")
                            {
                                CheckBoxFormField chkTelProprio = field as CheckBoxFormField;
                                chkTelProprio.Checked = true;
                            }
                            break;
                        case "chkTelRecado":
                            if (item.TelefoneProprio != null && item.TelefoneProprio == "N")
                            {
                                CheckBoxFormField chkTelRecado = field as CheckBoxFormField;
                                chkTelRecado.Checked = true;
                            }
                            break;
                        case "txtTelDDI":
                            field.Text = item.NumAreaTelefone;
                            break;
                        case "txtTelNumero":
                            field.Text = item.NumTelefone != null ? item.NumTelefone.Value.ToString() : "";
                            break;
                        case "txtCelDDI":
                            field.Text = item.NumAreaCelular;
                            break;
                        case "txtCelNumero":
                            field.Text = item.NumCelular != null ? item.NumCelular.Value.ToString() : "";
                            break;
                        case "txtEmail":
                            field.Text = item.Email;
                            break;
                        case "txtEmpresa":
                            field.Text = item.DescRazaoSocial;
                            break;
                        case "txtEndComercial":
                            field.Text = item.DescLogradouroEmp;
                            break;
                        case "txtNumeroEndEmp":
                            field.Text = item.NumLogradouroEmp;
                            break;
                        case "txtCompEmp":
                            field.Text = item.DescComplLogrEmp;
                            break;
                        case "txtBairroEmpresa":
                            field.Text = item.DescBairroEmp;
                            break;
                        case "txtCidadeEmpresa":
                            field.Text = item.DescCidadeEmp;
                            break;
                        case "txtCEPEmpresa":
                            field.Text = !string.IsNullOrEmpty(item.CodCEPEmp) ? item.CodCEPEmp.PadLeft(8, '0') : "";
                            break;
                        case "txtNomeReferencia":
                            field.Text = item.NomeReferencia;
                            break;
                        case "txtDDDReferencia":
                            field.Text = item.NumAreaTelefoneRef != null ? item.NumAreaTelefoneRef.ToString() : "";
                            break;
                        case "txtTelNumeroRef":
                            field.Text = item.NumTelefoneRef.ToString();
                            break;
                        case "txtSalario":
                            field.Text = item.ValRendaBruta != null ? item.ValRendaBruta.Value.ToString("C2") : "";
                            break;
                        case "txtOutrosRendimentos":
                            field.Text = item.ValRendimentos != null ? item.ValRendimentos.Value.ToString("C2") : "";
                            break;
                        case "chkBensMoveisN":
                            if (item.FlagBensImoveis == "N")
                            {
                                CheckBoxFormField chkBensMoveisN = field as CheckBoxFormField;
                                chkBensMoveisN.Checked = true;
                            }
                            break;
                        case "chkBensMoveisS":
                            if (item.FlagBensImoveis == "S")
                            {
                                CheckBoxFormField chkBensMoveisS = field as CheckBoxFormField;
                                chkBensMoveisS.Checked = true;
                            }
                            break;
                        case "txtValorImovel":
                            field.Text = item.ValImoveis != null ? item.ValImoveis.Value.ToString("C2") : "";
                            break;
                        case "txtValorAutomovel":
                            field.Text = item.ValAutomoveis != null ? item.ValAutomoveis.Value.ToString("C2") : "";
                            break;
                        case "txtValorInvestimento":
                            field.Text = item.ValInvestimentos != null ? item.ValInvestimentos.Value.ToString("C2") : "";
                            break;
                        case "txtValorOutros":
                            field.Text = item.ValOutros != null ? item.ValOutros.Value.ToString("C2") : "";
                            break;
                        case "chkPEPN":
                            if (item.FlagPPE == "N")
                            {
                                CheckBoxFormField chkPEPN = field as CheckBoxFormField;
                                chkPEPN.Checked = true;
                            }
                            break;
                        case "chkPEPS":
                            if (item.FlagPPE == "S")
                            {
                                CheckBoxFormField chkPEPS = field as CheckBoxFormField;
                                chkPEPS.Checked = true;
                            }
                            break;
                        case "txtNomeProcurador":
                            field.Text = item.NomeRepresentante;
                            break;
                        case "txtCPFRep":
                            field.Text = item.CPFRepresentante != null ? item.CPFRepresentante.Value.ToString(@"000\.000\.000\-00") : "";
                            break;
                        case "txtLocal":
                            CultureInfo culture = new CultureInfo("pt-BR");
                            DateTimeFormatInfo dtfi = culture.DateTimeFormat;

                            int dia = DateTime.Now.Day;
                            int ano = DateTime.Now.Year;
                            string mes = culture.TextInfo.ToTitleCase(dtfi.GetMonthName(DateTime.Now.Month));
                            string data = dia + " de " + mes + " de " + ano;

                            field.Text = item.DescCidadeLoja + ", " + data;
                            break;
                        default:
                            // Throw an error or do nothing.
                            break;
                    }
                }

                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion

        #region AdicionaValoresPDFRepresentante(Spire.Doc.Document document, FichaCadPFEntity item)
        /// <summary>
        /// Adiciona valores nos campos mapeados ao PDF gerado
        /// </summary>
        /// <param name="document"></param>
        /// <param name="item"></param>
        /// <returns></returns>
        private static bool AdicionaValoresPDFRepresentante(Spire.Doc.Document document, FichaCadPFEntity item)
        {
            try
            {
                //Adiciona valores aos atributos do arquivo que será gerado em PDF
                foreach (Spire.Doc.Fields.FormField field in document.Sections[0].Body.FormFields)
                {
                    switch (field.Name)
                    {
                        //case "chkClienteRep":
                        //    if (item.TipoCliente == "C")
                        //    {
                        //        CheckBoxFormField chkCliente = field as CheckBoxFormField;
                        //        chkCliente.Checked = true;
                        //    }
                        //    break;
                        //case "chkRepresentanteRep":
                        //    if (item.TipoCliente == "R")
                        //    {
                        //        CheckBoxFormField chkRepresentante = field as CheckBoxFormField;
                        //        chkRepresentante.Checked = true;
                        //    }
                        //    break;
                        case "txtNomeCompletoRep":
                            field.Text = item.NomeCliente;
                            break;
                        case "chkMasculinoRep":
                            if (item.CodSexo == "M")
                            {
                                CheckBoxFormField chkMasculino = field as CheckBoxFormField;
                                chkMasculino.Checked = true;
                            }
                            break;
                        case "chkFemininoRep":
                            if (item.CodSexo == "F")
                            {
                                CheckBoxFormField chkFeminino = field as CheckBoxFormField;
                                chkFeminino.Checked = true;
                            }
                            break;
                        case "txtDataNascimentoRep":
                            field.Text = item.DataNascimento != null ? item.DataNascimento.Value.ToString("dd/MM/yyyy") : "";

                            break;
                        case "txtCPF1Rep":
                            field.Text = item.NumCPF != null ? item.NumCPF.Value.ToString(@"000\.000\.000\-00") : "";

                            break;
                        case "txtProfissaoRep":
                            field.Text = item.DescProfissao;
                            break;
                        case "chkRGRep":
                            if (item.TipoDocumento != null && item.TipoDocumento.Value == 1)
                            {
                                CheckBoxFormField chkRG = field as CheckBoxFormField;
                                chkRG.Checked = true;
                            }
                            break;
                        case "chkCNHRep":
                            if (item.TipoDocumento != null && item.TipoDocumento.Value == 6)
                            {
                                CheckBoxFormField chkCNH = field as CheckBoxFormField;
                                chkCNH.Checked = true;
                            }
                            break;
                        case "chkCarteiraRep":
                            if (item.TipoDocumento != null && item.TipoDocumento.Value == 160)
                            {
                                CheckBoxFormField chkCarteira = field as CheckBoxFormField;
                                chkCarteira.Checked = true;
                            }
                            break;
                        case "chkRNERep":
                            if (item.TipoDocumento != null && item.TipoDocumento.Value == 55)
                            {
                                CheckBoxFormField chkRNE = field as CheckBoxFormField;
                                chkRNE.Checked = true;
                            }
                            break;
                        case "chkPassaporteRep":
                            if (item.TipoDocumento != null && item.TipoDocumento.Value == 159)
                            {
                                CheckBoxFormField chkPassaporte = field as CheckBoxFormField;
                                chkPassaporte.Checked = true;
                            }
                            break;
                        case "txtDataEmissaoRep":
                            field.Text = item.DataEmissaoDocto != null ? item.DataEmissaoDocto.Value.ToString("dd/MM/yyyy") : "";
                            break;
                        case "chkOutrosRep":
                            if (item.TipoDocumento != null && (item.TipoDocumento.Value != 1 && item.TipoDocumento.Value != 6 &&
                                item.TipoDocumento.Value != 160 && item.TipoDocumento.Value != 55 &&
                                item.TipoDocumento.Value != 159))
                            {
                                CheckBoxFormField chkOutros = field as CheckBoxFormField;
                                chkOutros.Checked = true;
                            }
                            break;
                        case "txtNumeroDocRep":
                            field.Text = item.NumDocto;
                            break;
                        case "txtOrgaoEmissorRep":
                            field.Text = item.OrgEmissaoDocto;
                            break;
                        case "txtDataVencimentoRep":
                            field.Text = item.DataValidadeDocto != null ? item.DataValidadeDocto.Value.ToString("dd/MM/yyyy") : "";
                            break;
                        case "txtLocalNascRep":
                            field.Text = item.DescNaturalidade;
                            break;
                        case "txtUFRep":
                            field.Text = item.SiglaUFNatu;
                            break;
                        case "txtNacionalidadeRep":
                            field.Text = item.DescNacionalidade;
                            break;
                        case "txtDataEntrBrasilRep":
                            field.Text = item.DataEntradaBrasil != null ? item.DataEntradaBrasil.Value.ToString("dd/MM/yyyy") : "";

                            break;
                        case "chkSDomFiscalSRep":
                            if (item.FlagFatca == "S")
                            {
                                CheckBoxFormField chkSDomicilioFiscalE = field as CheckBoxFormField;
                                chkSDomicilioFiscalE.Checked = true;
                            }
                            break;
                        case "chkNDomFiscalNRep":
                            if (item.FlagFatca == "N")
                            {
                                CheckBoxFormField chkSDomicilioFiscalE = field as CheckBoxFormField;
                                chkSDomicilioFiscalE.Checked = true;
                            }
                            break;
                        case "txtNomePaiRep":
                            field.Text = item.NomePai;
                            break;
                        case "txtNomeMaeRep":
                            field.Text = item.NomeMae;
                            break;
                        case "chkSolteiroRep":
                            if (item.CodEstadoCivil.Replace(" ", "") == "6")
                            {
                                CheckBoxFormField chkSolteiro = field as CheckBoxFormField;
                                chkSolteiro.Checked = true;
                            }
                            break;
                        case "chkCasadoRep":
                            if (item.CodEstadoCivil.Replace(" ", "") == "1" ||
                                item.CodEstadoCivil.Replace(" ", "") == "2" ||
                                item.CodEstadoCivil.Replace(" ", "") == "3" ||
                                item.CodEstadoCivil.Replace(" ", "") == "4")
                            {
                                CheckBoxFormField chkCasado = field as CheckBoxFormField;
                                chkCasado.Checked = true;
                            }
                            break;
                        case "chkUniaoEstavelRep":
                            if (item.CodEstadoCivil.Replace(" ", "") == "5")
                            {
                                CheckBoxFormField chkUniaoEstavel = field as CheckBoxFormField;
                                chkUniaoEstavel.Checked = true;
                            }
                            break;
                        case "chkDivorciadoRep":
                            if (item.CodEstadoCivil.Replace(" ", "") == "7")
                            {
                                CheckBoxFormField chkDivorciado = field as CheckBoxFormField;
                                chkDivorciado.Checked = true;
                            }
                            break;
                        case "chkSepJudRep":
                            if (item.CodEstadoCivil.Replace(" ", "") == "8")
                            {
                                CheckBoxFormField chkSepJudicialmente = field as CheckBoxFormField;
                                chkSepJudicialmente.Checked = true;
                            }
                            break;
                        case "chkViuvoRep":
                            if (item.CodEstadoCivil.Replace(" ", "") == "9")
                            {
                                CheckBoxFormField chkViuvo = field as CheckBoxFormField;
                                chkViuvo.Checked = true;
                            }
                            break;
                        case "txtNomeConjugeRep":
                            field.Text = item.NomeConjuge;
                            break;
                        case "txtCPFConjugeRep":
                            field.Text = item.CpfConjuge != null ? item.CpfConjuge.Value.ToString(@"000\.000\.000\-00") : "";

                            break;
                        case "txtEndResidencialRep":
                            field.Text = item.DescLogradouro;
                            break;
                        case "txtNumeroRep":
                            field.Text = item.NumLogradouro;
                            break;
                        case "txtComplementoRep":
                            field.Text = item.DescComplLogr;
                            break;
                        case "txtBairroRep":
                            field.Text = item.DescBairro;
                            break;
                        case "txtCidadeRep":
                            field.Text = item.DesCidade;
                            break;
                        case "txtCEPRep":
                            field.Text = !string.IsNullOrEmpty(item.CodCEP) ? item.CodCEP.PadLeft(8, '0') : "";
                            break;
                        case "chkResPropriaRep":
                            if (item.TipoResidencia == "1")
                            {
                                CheckBoxFormField chkResPropria = field as CheckBoxFormField;
                                chkResPropria.Checked = true;
                            }
                            break;
                        case "chkResPaisAvosRep":
                            if (item.TipoResidencia == "3")
                            {
                                CheckBoxFormField chkResPaisAvos = field as CheckBoxFormField;
                                chkResPaisAvos.Checked = true;
                            }
                            break;
                        case "chkResAlugadaRep":
                            if (item.TipoResidencia == "4")
                            {
                                CheckBoxFormField chkResAlugada = field as CheckBoxFormField;
                                chkResAlugada.Checked = true;
                            }
                            break;

                        case "chkTelProprioRep":
                            if (item.TelefoneProprio != null && item.TelefoneProprio == "S")
                            {
                                CheckBoxFormField chkTelProprioRep = field as CheckBoxFormField;
                                chkTelProprioRep.Checked = true;
                            }
                            break;
                        case "chkTelRecadoRep":
                            if (item.TelefoneProprio != null && item.TelefoneProprio == "N")
                            {
                                CheckBoxFormField chkTelRecadoRep = field as CheckBoxFormField;
                                chkTelRecadoRep.Checked = true;
                            }
                            break;
                        case "txtTelDDIRep":
                            field.Text = item.NumAreaTelefone;
                            break;
                        case "txtTelNumeroRep":
                            field.Text = item.NumTelefone != null ? item.NumTelefone.ToString() : "";
                            break;
                        case "txtRamalRep":
                            break;
                        case "txtCelDDIRep":
                            field.Text = item.NumAreaCelular;
                            break;
                        case "txtCelNumeroRep":
                            field.Text = item.NumCelular != null ? item.NumCelular.ToString() : "";
                            break;
                        case "txtEmailRep":
                            field.Text = item.Email;
                            break;
                        case "txtEmpresaRep":
                            field.Text = item.DescRazaoSocial;
                            break;
                        case "txtEndComercialRep":
                            field.Text = item.DescLogradouroEmp;
                            break;
                        case "txtNumeroEndEmpRep":
                            field.Text = item.NumLogradouroEmp;
                            break;
                        case "txtCompEmpRep":
                            field.Text = item.DescComplLogrEmp;
                            break;
                        case "txtBairroEmpresaRep":
                            field.Text = item.DescBairroEmp;
                            break;
                        case "txtCidadeEmpresaRep":
                            field.Text = item.DescCidadeEmp;
                            break;
                        case "txtCEPEmpresaRep":
                            field.Text = !string.IsNullOrEmpty(item.CodCEPEmp) ? item.CodCEPEmp.PadLeft(8, '0') : "";
                            break;
                        case "txtTelEmpresaRep":
                            break;
                        case "txtNomeReferenciaRep":
                            field.Text = item.NomeReferencia;
                            break;
                        //case "txtDDIReferenciaRep":
                        //    field.Text = item.NumAreaTelefoneRef.ToString();
                        //    break;
                        case "txtDDDReferenciaRep":
                            field.Text = item.NumAreaTelefoneRef != null ? item.NumAreaTelefoneRef.ToString() : "";
                            break;
                        case "txtTelNumeroRefRep":
                            field.Text = item.NumTelefoneRef != null ? item.NumTelefoneRef.ToString() : "";
                            break;
                        case "txtRamalRefRep":
                            break;
                        case "txtSalarioRep":
                            field.Text = item.ValRendaBruta != null ? item.ValRendaBruta.Value.ToString("C2") : "";
                            break;
                        case "txtOutrosRendRep":
                            field.Text = item.ValRendimentos != null ? item.ValRendimentos.Value.ToString("C2") : "";
                            break;
                        case "chkBensMoveisNRep":
                            if (item.FlagBensImoveis == "N")
                            {
                                CheckBoxFormField chkBensMoveisN = field as CheckBoxFormField;
                                chkBensMoveisN.Checked = true;
                            }
                            break;
                        case "chkBensMoveisSRep":
                            if (item.FlagBensImoveis == "S")
                            {
                                CheckBoxFormField chkBensMoveisS = field as CheckBoxFormField;
                                chkBensMoveisS.Checked = true;
                            }
                            break;
                        case "txtValorImovelRep":
                            field.Text = item.ValImoveis != null ? item.ValImoveis.Value.ToString("C2") : "";
                            break;
                        case "txtValorAutomovelRep":
                            field.Text = item.ValAutomoveis != null ? item.ValAutomoveis.Value.ToString("C2") : "";
                            break;
                        case "txtValorInvestRep":
                            field.Text = item.ValInvestimentos != null ? item.ValInvestimentos.Value.ToString("C2") : "";
                            break;
                        case "txtValorOutrosRep":
                            field.Text = item.ValOutros != null ? item.ValOutros.Value.ToString("C2") : "";
                            break;
                        case "chkPEPNRep":
                            if (item.FlagPPE == "N")
                            {
                                CheckBoxFormField chkPEPN = field as CheckBoxFormField;
                                chkPEPN.Checked = true;
                            }
                            break;
                        case "chkPEPSRep":
                            if (item.FlagPPE == "S")
                            {
                                CheckBoxFormField chkPEPS = field as CheckBoxFormField;
                                chkPEPS.Checked = true;
                            }
                            break;
                        case "txtNomeProcuradorRep":
                            field.Text = item.NomeRepresentante;
                            break;
                        case "txtCPFRepRep":
                            field.Text = item.CPFRepresentante != null ? item.CPFRepresentante.Value.ToString(@"000\.000\.000\-00") : "";

                            break;
                        case "chkCtaDepAVistaRep":
                            break;
                        case "chkOpCreditoRep":
                            break;
                        case "chkInvestimentosRep":
                            break;
                        case "chkCambioRep":
                            break;
                        case "txtLocalRep":
                            CultureInfo culture = new CultureInfo("pt-BR");
                            DateTimeFormatInfo dtfi = culture.DateTimeFormat;

                            int dia = DateTime.Now.Day;
                            int ano = DateTime.Now.Year;
                            string mes = culture.TextInfo.ToTitleCase(dtfi.GetMonthName(DateTime.Now.Month));
                            string data = dia + " de " + mes + " de " + ano;

                            field.Text = item.DescCidadeLoja + ", " + data;
                            break;
                        default:
                            // Throw an error or do nothing.
                            break;
                    }
                }

                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion

        #endregion


    }
}
