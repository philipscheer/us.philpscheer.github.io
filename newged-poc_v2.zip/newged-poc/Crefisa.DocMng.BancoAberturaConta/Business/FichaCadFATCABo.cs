﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Crefisa.Comum.Negocio.Dominio;
using Crefisa.DocMng.BancoAberturaConta.DataAccess;
using Crefisa.DocMng.BancoAberturaConta.Entities;
using Crefisa.DocMng.BancoAberturaConta.Util;
using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.Contracts.DTO;
using Crefisa.DocMng.Contracts.Enumerator;
using Crefisa.Infraestrutura.Log;
using Spire.Doc.Fields;

namespace Crefisa.DocMng.BancoAberturaConta.Business
{
    public class FichaCadFATCABo
    {
        #region Atributes

        #endregion

        #region Public Constructors

        #region FichaCadFACTABo()
        /// <summary>
        /// Construtor padrão da classe FichaCadFACTABo.
        /// </summary>
        public FichaCadFATCABo()
        {

        }
        #endregion

        #endregion

        #region Public Methods

        #region GenerateDocumentPdf(ParamGenerateDocPdf param)
        /// <summary>
        /// Geração do Documento de acordo com o tipo do Documento
        /// </summary>
        /// <param name="param"></param>
        public static DocMngDTO GenerateDocumentPdf(ParamGenerateDocPdf param)
        {
            try
            {
                string caminhoArquivoPDF, caminhoTemplate;
                DocMngDTO docMngDTO;

                LoggerManager.Instance.Info("[FichaCadFATCABo.GenerateDocumentPdf] - Descerializando XML campo [Data]");
                docMngDTO = Crefisa.Infraestrutura.Serializers.SerializerContext.Deserialize<DocMngDTO>(param.Data, param.SerializerTypes);
                LoggerManager.Instance.Info("[FichaCadFATCABo.GenerateDocumentPdf] - Descerializando XML campo [Data] - OK");

                LoggerManager.Instance.Info("[FichaCadFATCABo.GenerateDocumentPdf] - Método [trataCaminhoArquivoPDF] de configuração do diretório onde será salvo arquivo em PDF ...");
                caminhoArquivoPDF = Utils.TratarCaminhoArquivoPDF(docMngDTO);
                caminhoTemplate = Utils.TratarCaminhoTemplate(docMngDTO);
                LoggerManager.Instance.Info("[FichaCadFATCABo.GenerateDocumentPdf] - Método [trataCaminhoArquivoPDF] de configuração do diretório onde será salvo arquivo em PDF ... - OK");

                //Consulta Dados do Cliente
                LoggerManager.Instance.Info("[FichaCadFATCABo.GenerateDocumentPdf] - Consulta Dados do Cliente para emissão do Recibo em PDF");

                using (FichaCadFATCADao obj = new FichaCadFATCADao(Defines.ConnectionNameTstProd))
                {

                    IEnumerable<FichaCadFATCAEntity> ret = obj.ConsultarFichaCadFACTA(decimal.Parse(docMngDTO.CodigoExterno));

                    if (ret.Count() != 0)
                    {
                        foreach (var item in ret)
                        {
                            LoggerManager.Instance.Info("[FichaCadFATCABo.GenerateDocumentPdf] - Emissão de Recibo em PDF para o CPF [" + item.NumCPF + "]");
                            LoggerManager.Instance.Info("[FichaCadFATCABo.GenerateDocumentPdf] - Busca arquivo template [" + docMngDTO.NomeArquivo + "]");
                            Spire.Doc.Document document = new Spire.Doc.Document(System.IO.Path.Combine(caminhoTemplate, docMngDTO.NomeArquivo));

                            if (AdicionaValoresPDF(document, item))
                            {
                                //Save doc file.
                                LoggerManager.Instance.Info("[FichaCadFATCABo.GenerateDocumentPdf] - Salvar arquivo no diretório [" + docMngDTO.CaminhoArquivoPdf + "]");
                                docMngDTO.NomeArquivo = docMngDTO.NomeArquivo.Substring(0, docMngDTO.NomeArquivo.Length - 5) + "." + item.NumCPF + "." +
                                                            DateTime.Now.Day.ToString().PadLeft(2, '0') +
                                                            DateTime.Now.Month.ToString().PadLeft(2, '0') +
                                                            DateTime.Now.Year.ToString() + "." +
                                                            DateTime.Now.Hour.ToString().PadLeft(2, '0') +
                                                            DateTime.Now.Minute.ToString().PadLeft(2, '0')
                                                            + ".pdf";

                                //Save doc file.
                                LoggerManager.Instance.Info("[FichaCadFATCABo.GenerateDocumentPdf] - Salvar arquivo no diretório [" + docMngDTO.CaminhoArquivoPdf + "]");
                                document.SaveToFile(System.IO.Path.Combine(caminhoArquivoPDF, System.IO.Path.ChangeExtension(docMngDTO.NomeArquivo, "pdf")), Spire.Doc.FileFormat.PDF);

                                docMngDTO.CaminhoArquivoPdf = caminhoArquivoPDF;

                                Utils.IncluirRegistroImpressao(docMngDTO, item.CodLoja != null ? item.CodLoja.Value : 0, EnumDocumentType.FichaCadastroFACTA);
                            }
                        }
                    }
                    else
                    {
                        LoggerManager.Instance.Info("[FichaCadFATCABo.GenerateDocumentPdf] - Não existe Dados para a geração do Recibo em PDF do contrato [" + docMngDTO.CodigoExterno + "]");
                        docMngDTO.NomeArquivo = "Arquivo não gerado para o cpf [" + docMngDTO.CodigoExterno + "]";
                    }

                    return docMngDTO;
                }
            }
            catch (Exception ex)
            {
                LoggerManager.Instance.Error(ex, "[FichaCadFATCABo.GenerateDocumentPdf] - Erro ao gerar Recibo em PDF", ex);
                throw; // Fix: Re-throw the original exception without using 'throw ex'
            }
        }
        #endregion

        #endregion

        #region Private Methods
        /// <summary>
        /// Adiciona valores nos campos mapeados ao PDF gerado
        /// </summary>
        /// <param name="document"></param>
        /// <param name="item"></param>
        /// <returns></returns>
        private static bool AdicionaValoresPDF(Spire.Doc.Document document, FichaCadFATCAEntity item)
        {
            try
            {
                var confirmaDocumentos = NegocioDominio.ConsultarDominio(Defines.ConfirmaDocumentos);

                //Adiciona valores aos atributos do arquivo que será gerado em PDF
                foreach (Spire.Doc.Fields.FormField field in document.Sections[0].Body.FormFields)
                {
                    switch (field.Name)
                    {
                        case "txtNome":
                            field.Text = item.NomeCliente;
                            break;
                        case "txtCPF1":
                            field.Text = item.NumCPF != null ? item.NumCPF.Value.ToString(@"000\.000\.000\-00") : "";
                            break;
                        case "txtLocalNascimento":
                            field.Text = item.LocalNascimento;
                            break;
                        case "txtEndereco":
                            field.Text = item.Logradouro;
                            break;
                        case "txtNumero":
                            field.Text = item.Numero != null ? item.Numero.Value.ToString() : "";
                            break;
                        case "txtComplemento":
                            field.Text = item.Complemento;
                            break;
                        case "txtBairro":
                            field.Text = item.Bairro;
                            break;
                        case "txtCidade":
                            field.Text = item.Cidade;
                            break;
                        case "txtCEP":
                            field.Text = item.Cep;
                            break;
                        case "txtPais":
                            field.Text = item.Pais;
                            break;
                        case "chkEstudante":
                            if (item.FlgEstudante == "True")
                            {
                                CheckBoxFormField chkEstudante = field as CheckBoxFormField;
                                chkEstudante.Checked = true;
                            }
                            break;
                        case "chkDiplomata":
                            if (item.FlgDiplomata == "True")
                            {
                                CheckBoxFormField chkDiplomata = field as CheckBoxFormField;
                                chkDiplomata.Checked = true;
                            }
                            break;
                        case "chkConjuge":
                            if (item.FlgConjuge == "True")
                            {
                                CheckBoxFormField chkConjuge = field as CheckBoxFormField;
                                chkConjuge.Checked = true;
                            }
                            break;
                        case "chkNEstiveEUA":
                            if (item.FlgPresencaSubstancial == "True")
                            {
                                CheckBoxFormField chkNEstiveEUA = field as CheckBoxFormField;
                                chkNEstiveEUA.Checked = true;
                            }
                            break;
                        case "chkAbdiqueiNac":
                            if (item.FlgAbdiqueiNac == "True")
                            {
                                CheckBoxFormField chkAbdiqueiNac = field as CheckBoxFormField;
                                chkAbdiqueiNac.Checked = true;
                            }
                            break;
                        case "chkRenunciei":
                            if (item.FlgRenunciei == "True")
                            {
                                CheckBoxFormField chkRenunciei = field as CheckBoxFormField;
                                chkRenunciei.Checked = true;
                            }
                            break;
                        case "chkNPossuoVisto":
                            if (item.FlgVistoGreenCard == "True")
                            {
                                CheckBoxFormField chkNPossuoVisto = field as CheckBoxFormField;
                                chkNPossuoVisto.Checked = true;
                            }
                            break;
                        case "chkAbdiqueiVisto":
                            if (item.FlgCertifAbandono == "True")
                            {
                                CheckBoxFormField chkAbdiqueiVisto = field as CheckBoxFormField;
                                chkAbdiqueiVisto.Checked = true;
                            }
                            break;
                        case "txtLocal":
                            CultureInfo culture = new CultureInfo("pt-BR");
                            DateTimeFormatInfo dtfi = culture.DateTimeFormat;

                            int dia = DateTime.Now.Day;
                            int ano = DateTime.Now.Year;
                            string mes = culture.TextInfo.ToTitleCase(dtfi.GetMonthName(DateTime.Now.Month));
                            string data = dia + " de " + mes + " de " + ano;

                            field.Text = item.DescCidadeLoja + ", " + data;
                            break;
                        case "txtDiasCorrente":
                            field.Text = item.NumDiasEUACorrente.ToString() != null ? item.NumDiasEUACorrente.ToString() : "";
                            break;
                        case "txtDiasPassado":
                            field.Text = item.NumDiasEUAPassado.ToString() != null ? item.NumDiasEUAPassado.ToString() : "";
                            break;
                        case "txtDiasAnterior":
                            field.Text = item.NumDiasEUAAnterior.ToString() != null ? item.NumDiasEUAAnterior.ToString() : "";
                            break;
                        default:
                            // Throw an error or do nothing.
                            break;
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                LoggerManager.Instance.Error(ex, "[FichaCadFATCABo.AdicionaValoresPDF] - Erro ao adicionar valores ao PDF", ex);
                throw;
            }
        }

        #endregion

    }
}