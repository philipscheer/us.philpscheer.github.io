﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Crefisa.Comum.Negocio.Dominio;
using Crefisa.DocMng.BancoAberturaConta.DataAccess;
using Crefisa.DocMng.BancoAberturaConta.Entities;
using Crefisa.DocMng.BancoAberturaConta.Util;
using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.Contracts.DTO;
using Crefisa.DocMng.Contracts.Enumerator;
using Crefisa.Infraestrutura.Log;
using Spire.Doc.Fields;

namespace Crefisa.DocMng.BancoAberturaConta.Business
{
    public class PropostaAberturaContaBo
    {
        #region Atributes

        #endregion

        #region Public Constructors

        #region PropostaAberturaContaBo()
        /// <summary>
        /// Construtor padrão da classe PropostaAberturaContaBo.
        /// </summary>
        public PropostaAberturaContaBo()
        {

        }
        #endregion

        #endregion

        #region Public Methods

        #region GenerateDocumentPdf(ParamGenerateDocPdf param)
        /// <summary>
        /// Geração do Documento de acordo com o tipo do Documento
        /// </summary>
        /// <param name="param"></param>
        public static DocMngDTO GenerateDocumentPdf(ParamGenerateDocPdf param)
        {
            try
            {
                string caminhoArquivoPDF, caminhoTemplate;

                DocMngDTO docMngDTO;

                LoggerManager.Instance.Info("[PropostaAberturaContaBo.GenerateDocumentPdf] - Descerializando XML campo [Data]");
                docMngDTO = Crefisa.Infraestrutura.Serializers.SerializerContext.Deserialize<DocMngDTO>(param.Data, param.SerializerTypes);
                LoggerManager.Instance.Info("[PropostaAberturaContaBo.GenerateDocumentPdf] - Descerializando XML campo [Data] - OK");

                LoggerManager.Instance.Info("[PropostaAberturaContaBo.GenerateDocumentPdf] - Método [trataCaminhoArquivoPDF] de configuração do diretório onde será salvo arquivo em PDF ...");
                caminhoArquivoPDF = Utils.TratarCaminhoArquivoPDF(docMngDTO);
                caminhoTemplate = Utils.TratarCaminhoTemplate(docMngDTO);
                LoggerManager.Instance.Info("[PropostaAberturaContaBo.GenerateDocumentPdf] - Método [trataCaminhoArquivoPDF] de configuração do diretório onde será salvo arquivo em PDF ... - OK");

                //Consulta Dados do Cliente
                LoggerManager.Instance.Info("[PropostaAberturaContaBo.GenerateDocumentPdf] - Consulta Dados do Cliente para emissão de Prop de Abertura de Contas em PDF");


                using (FichaCadPFDao obj = new FichaCadPFDao(Defines.ConnectionNameTstProd))
                {
                    IEnumerable<FichaCadPFEntity> ret = obj.ConsultarFichaCadPF(decimal.Parse(docMngDTO.CodigoExterno));

                    if (ret.Count() != 0)
                    {
                        foreach (var item in ret)
                        {
                            LoggerManager.Instance.Info("[PropostaAberturaContaBo.GenerateDocumentPdf] - Emissão de Proposta de Abertura de Conta em PDF para o CPF [" + item.NumCPF + "]");
                            Spire.Doc.Document document = new Spire.Doc.Document(System.IO.Path.Combine(caminhoTemplate, docMngDTO.NomeArquivo));

                            if (AdicionaValoresPDF(document, item))
                            {
                                //Save doc file.
                                LoggerManager.Instance.Info("[PropostaAberturaContaBo.GenerateDocumentPdf] - Salvar arquivo no diretório [" + docMngDTO.CaminhoArquivoPdf + "]");
                                docMngDTO.NomeArquivo = docMngDTO.NomeArquivo.Substring(0, docMngDTO.NomeArquivo.Length - 5) + "." + item.NumCPF + "." +
                                                            DateTime.Now.Day.ToString().PadLeft(2, '0') +
                                                            DateTime.Now.Month.ToString().PadLeft(2, '0') +
                                                            DateTime.Now.Year.ToString() + "." +
                                                            DateTime.Now.Hour.ToString().PadLeft(2, '0') +
                                                            DateTime.Now.Minute.ToString().PadLeft(2, '0')
                                                            + ".pdf";

                                //Save doc file.
                                LoggerManager.Instance.Info("[PropostaAberturaContaBo.GenerateDocumentPdf] - Salvar arquivo no diretório [" + docMngDTO.CaminhoArquivoPdf + "]");
                                document.SaveToFile(System.IO.Path.Combine(caminhoArquivoPDF, System.IO.Path.ChangeExtension(docMngDTO.NomeArquivo, "pdf")), Spire.Doc.FileFormat.PDF);

                                docMngDTO.CaminhoArquivoPdf = caminhoArquivoPDF;

                                Utils.IncluirRegistroImpressao(docMngDTO, item.CodLoja != null ? item.CodLoja.Value : 0, EnumDocumentType.PropostaAberturaConta);
                            }
                        }
                    }
                    else
                    {
                        LoggerManager.Instance.Info("[PropostaAberturaContaBo.GenerateDocumentPdf] - Não existe Dados para a geração da PAC em PDF do contrato [" + docMngDTO.CodigoExterno + "]");
                        docMngDTO.NomeArquivo = "Arquivo não gerado para o contrato [" + docMngDTO.CodigoExterno + "]";
                    }

                    return docMngDTO;
                }
            }
            catch (Exception ex)
            {
                LoggerManager.Instance.Error(ex, "[PropostaAberturaContaBo.GenerateDocumentPdf] - Erro ao gerar PAC em PDF", ex);
                throw; // Fix: Re-throw the original exception without using 'throw ex'
            }
        }
        #endregion

        #endregion

        #region Private Methods
        /// <summary>
        /// Adiciona valores nos campos mapeados ao PDF gerado
        /// </summary>
        /// <param name="document"></param>
        /// <param name="item"></param>
        /// <returns></returns>
        private static bool AdicionaValoresPDF(Spire.Doc.Document document, FichaCadPFEntity item)
        {
            try
            {
                InfoBancDao obj = new InfoBancDao(Defines.ConnectionInfoBanc);
                var confirmaDocumentos = NegocioDominio.ConsultarDominio(Defines.ConfirmaDocumentos);
                decimal tarifaInicioRelacionamento = 25;

                try
                {
                    tarifaInicioRelacionamento = obj.ConsultarTarifas("063"); // Retorna o valor da tarifa 063 (inicio relacionamento) Zero Reais
                }
                catch (Exception ex)
                {
                    LoggerManager.Instance.UseErrorFloodContention = false;
                    LoggerManager.Instance.Error(ex, "Tarifa 063 (inicio relacionamento) nao encontrada na INFOBANC");
                }

                //Adiciona valores aos atributos do arquivo que será gerado em PDF
                foreach (Spire.Doc.Fields.FormField field in document.Sections[0].Body.FormFields)
                {
                    switch (field.Name)
                    {
                        case "chkIndividual":
                            CheckBoxFormField chkIndividual = field as CheckBoxFormField;
                            chkIndividual.Checked = true;
                            break;
                        case "txtTitular1":
                            field.Text = item.NomeCliente;
                            break;
                        case "txtCPF1":
                            field.Text = item.NumCPF != null ? item.NumCPF.Value.ToString(@"000\.000\.000\-00") : "";
                            break;
                        case "chkDocIndentidade":
                            if (item.TipoDocumento == 1)
                            {
                                CheckBoxFormField chkDocIndentidade = field as CheckBoxFormField;
                                chkDocIndentidade.Checked = true;
                            }
                            break;
                        case "chkComprovanteRes":
                            if (item.TipoDocumento == 2)
                            {
                                CheckBoxFormField chkComprovanteRes = field as CheckBoxFormField;
                                chkComprovanteRes.Checked = true;
                            }
                            break;
                        case "chkCPFCNPJ":
                            if (item.TipoDocumento == 3)
                            {
                                CheckBoxFormField chkCPFCNPJ = field as CheckBoxFormField;
                                chkCPFCNPJ.Checked = true;
                            }
                            break;
                        case "chkComprovanteRenda":
                            if (item.TipoDocumento == 4)
                            {
                                CheckBoxFormField chkitemComprovanteRenda = field as CheckBoxFormField;
                                chkitemComprovanteRenda.Checked = true;
                            }
                            break;
                        case "chkAderirCCS":
                            CheckBoxFormField chkAderirCCS = field as CheckBoxFormField;
                            chkAderirCCS.Checked = true;
                            break;
                        case "txtNomeRep":
                            field.Text = item.NomeRepresentante;
                            break;
                        case "chkTitular1":
                            CheckBoxFormField chkTitular1 = field as CheckBoxFormField;
                            chkTitular1.Checked = true;
                            break;
                        case "txtCPFRep":
                            field.Text = item.CPFRepresentante != null ? item.CPFRepresentante.Value.ToString(@"000\.000\.000\-00") : "";
                            break;
                        case "chkBanco":
                            CheckBoxFormField chkBanco = field as CheckBoxFormField;
                            chkBanco.Checked = true;
                            break;
                        case "txtBanco":
                            field.Text = item.CodBanco != null ? item.CodBanco.Value.ToString() : "";
                            break;
                        case "txtAgencia":
                            field.Text = item.CodAgencia != null ? item.CodAgencia.Value.ToString() : "";
                            break;
                        case "txtConta":
                            field.Text = item.CodConta.ToString();
                            break;
                        case "txtLocal":
                            CultureInfo culture = new CultureInfo("pt-BR");
                            DateTimeFormatInfo dtfi = culture.DateTimeFormat;

                            int dia = DateTime.Now.Day;
                            int ano = DateTime.Now.Year;
                            string mes = culture.TextInfo.ToTitleCase(dtfi.GetMonthName(DateTime.Now.Month));
                            string data = dia + " de " + mes + " de " + ano;

                            field.Text = item.DescCidadeLoja + ", " + data;
                            break;
                        case "chkTipoContaPoupanca":
                            if (item.TipoConta == "P")
                            {
                                CheckBoxFormField chkTipoContaPoupanca = field as CheckBoxFormField;
                                chkTipoContaPoupanca.Checked = true;
                            }

                            break;
                        case "chkTipoContaCorrente":
                            if (item.TipoConta == "C")
                            {

                                CheckBoxFormField chkTipoContaCorrente = field as CheckBoxFormField;
                                chkTipoContaCorrente.Checked = true;
                            }

                            break;
                        case "txtPrimeiroTitular":
                            field.Text = item.NomeCliente;
                            break;
                        case "txtTarifaIniRelac":
                            field.Text = tarifaInicioRelacionamento.ToString("C2");
                            break;
                        case "txtTarifaIniRelacD":
                            field.Text = Utils.EscreverExtenso(tarifaInicioRelacionamento);
                            break;
                        case "txtTarifaMsgAut":
                            field.Text = "R$ 1,00";
                            break;
                        case "txtTarifaMsgAutD":
                            field.Text = Utils.EscreverExtenso(1);
                            break;
                        default:
                            // Throw an error or do nothing.
                            break;
                    }
                }
                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }

        #endregion

    }
}
