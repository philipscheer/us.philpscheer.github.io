﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Crefisa.Comum.Negocio.Dominio;
using Crefisa.DocMng.BancoAberturaConta.DataAccess;
using Crefisa.DocMng.BancoAberturaConta.Entities;
using Crefisa.DocMng.BancoAberturaConta.Util;
using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.Contracts.DTO;
using Crefisa.DocMng.Contracts.Enumerator;
using Crefisa.Infraestrutura.Log;
using Spire.Doc.Fields;

namespace Crefisa.DocMng.BancoAberturaConta.Business
{
    public class FichaCadPEPBo
    {
        #region Atributes

        #endregion

        #region Public Constructors

        #region FichaCadPEPBo()
        /// <summary>
        /// Construtor padrão da classe FichaCadPEPBo.
        /// </summary>
        public FichaCadPEPBo()
        {

        }
        #endregion

        #endregion

        #region Public Methods

        #region GenerateDocumentPdf(ParamGenerateDocPdf param)
        /// <summary>
        /// Geração do Documento de acordo com o tipo do Documento
        /// </summary>
        /// <param name="param"></param>
        public static DocMngDTO GenerateDocumentPdf(ParamGenerateDocPdf param)
        {
            try
            {
                string caminhoArquivoPDF, caminhoTemplate;
                DocMngDTO docMngDTO;

                LoggerManager.Instance.Info("[FichaCadPEPBo.GenerateDocumentPdf] - Descerializando XML campo [Data]");
                docMngDTO = Crefisa.Infraestrutura.Serializers.SerializerContext.Deserialize<DocMngDTO>(param.Data, param.SerializerTypes);
                LoggerManager.Instance.Info("[FichaCadPEPBo.GenerateDocumentPdf] - Descerializando XML campo [Data] - OK");

                LoggerManager.Instance.Info("[FichaCadPEPBo.GenerateDocumentPdf] - Método [trataCaminhoArquivoPDF] de configuração do diretório onde será salvo arquivo em PDF ...");
                caminhoArquivoPDF = Utils.TratarCaminhoArquivoPDF(docMngDTO);
                caminhoTemplate = Utils.TratarCaminhoTemplate(docMngDTO);
                LoggerManager.Instance.Info("[FichaCadPEPBo.GenerateDocumentPdf] - Método [trataCaminhoArquivoPDF] de configuração do diretório onde será salvo arquivo em PDF ... - OK");

                //Consulta Dados do Cliente
                LoggerManager.Instance.Info("[FichaCadPEPBo.GenerateDocumentPdf] - Consulta Dados do Cliente para emissão da Ficha Cadastral PEP em PDF");

                using (FichaCadPEPDao obj = new FichaCadPEPDao(Defines.ConnectionNameTstProd))
                {

                    IEnumerable<FichaCadPEPEntity> ret = obj.ConsultarFichaCadPEPDao(decimal.Parse(docMngDTO.CodigoExterno.ToString()));

                    if (ret.Count() != 0)
                    {
                        foreach (var item in ret)
                        {
                            LoggerManager.Instance.Info("[FichaCadPEPBo.GenerateDocumentPdf] - Ficha Cadastral PEP em PDF para o CPF [" + item.NumCPF + "]");
                            LoggerManager.Instance.Info("[FichaCadPEPBo.GenerateDocumentPdf] - Busca arquivo template [" + docMngDTO.NomeArquivo + "]");
                            Spire.Doc.Document document = new Spire.Doc.Document(System.IO.Path.Combine(caminhoTemplate, docMngDTO.NomeArquivo));

                            if (AdicionaValoresPDF(document, item))
                            {
                                //Save doc file.
                                LoggerManager.Instance.Info("[FichaCadPEPBo.GenerateDocumentPdf] - Salvar arquivo no diretório [" + docMngDTO.CaminhoArquivoPdf + "]");
                                docMngDTO.NomeArquivo = docMngDTO.NomeArquivo.Substring(0, docMngDTO.NomeArquivo.Length - 5) + "." + item.NumCPF + "." +
                                                            DateTime.Now.Day.ToString().PadLeft(2, '0') +
                                                            DateTime.Now.Month.ToString().PadLeft(2, '0') +
                                                            DateTime.Now.Year.ToString() + "." +
                                                            DateTime.Now.Hour.ToString().PadLeft(2, '0') +
                                                            DateTime.Now.Minute.ToString().PadLeft(2, '0')
                                                            + ".pdf";

                                //Save doc file.
                                LoggerManager.Instance.Info("[FichaCadPEPBo.GenerateDocumentPdf] - Salvar arquivo no diretório [" + docMngDTO.CaminhoArquivoPdf + "]");
                                document.SaveToFile(System.IO.Path.Combine(caminhoArquivoPDF, System.IO.Path.ChangeExtension(docMngDTO.NomeArquivo, "pdf")), Spire.Doc.FileFormat.PDF);

                                docMngDTO.CaminhoArquivoPdf = caminhoArquivoPDF;

                                Utils.IncluirRegistroImpressao(docMngDTO, item.CodLoja != null ? item.CodLoja.Value : 0, EnumDocumentType.FichaCadastroPEP);
                            }
                        }
                    }
                    else
                    {
                        LoggerManager.Instance.Info("[FichaCadPEPBo.GenerateDocumentPdf] - Não existe Dados para a geração da Ficha Cadastral PEP em PDF do contrato [" + docMngDTO.CodigoExterno + "]");
                        docMngDTO.NomeArquivo = "Arquivo não gerado para o cpf [" + docMngDTO.CodigoExterno + "]";
                    }

                    return docMngDTO;
                }
            }
            catch (Exception ex)
            {
                LoggerManager.Instance.Error(ex, "[FichaCadPEPBo.GenerateDocumentPdf] - Erro ao gerar Ficha Cadastral PEP em PDF", ex);
                throw; // Fix: Re-throw the original exception without using 'throw ex'
            }
        }
        #endregion

        #endregion

        #region Private Methods
        /// <summary>
        /// Adiciona valores nos campos mapeados ao PDF gerado
        /// </summary>
        /// <param name="document"></param>
        /// <param name="item"></param>
        /// <returns></returns>
        private static bool AdicionaValoresPDF(Spire.Doc.Document document, FichaCadPEPEntity item)
        {
            try
            {
                var confirmaDocumentos = NegocioDominio.ConsultarDominio(Defines.ConfirmaDocumentos);

                //Adiciona valores aos atributos do arquivo que será gerado em PDF
                foreach (Spire.Doc.Fields.FormField field in document.Sections[0].Body.FormFields)
                {
                    switch (field.Name)
                    {
                        case "txtNome":
                            field.Text = item.NomeCliente;
                            break;
                        case "txtCPF1":
                            field.Text = item.NumCPF != null ? item.NumCPF.Value.ToString(@"000\.000\.000\-00") : "";
                            break;
                        case "chkFuncaoPublicaS":
                            if (item.FlgFuncaoPublica == "S")
                            {
                                CheckBoxFormField chkFuncaoPublicaS = field as CheckBoxFormField;
                                chkFuncaoPublicaS.Checked = true;
                            }
                            break;
                        case "chkFuncaoPublicaN":
                            if (item.FlgFuncaoPublica == "N")
                            {
                                CheckBoxFormField chkFuncaoPublicaS = field as CheckBoxFormField;
                                chkFuncaoPublicaS.Checked = true;
                            }
                            break;
                        case "txtCargo":
                            if (item.FlgFuncaoPublica == "S")
                                field.Text = item.Cargo;
                            break;
                        case "txtDataInicio":
                            if (item.FlgFuncaoPublica == "S")
                                field.Text = item.DataInicio != null ? item.DataInicio.Value.ToString("dd/MM/yyyy") : "";
                            break;
                        case "txtDataFim":
                            if (item.FlgFuncaoPublica == "S")
                                field.Text = item.DataFim != null ? item.DataFim.Value.ToString("dd/MM/yyyy") : "";
                            break;
                        case "txtEmpresa":
                            if (item.FlgFuncaoPublica == "S")
                                field.Text = item.Empresa;
                            break;
                        case "chkAgentePublicoS":
                            if (item.FlgAgentePublico == "S")
                            {
                                CheckBoxFormField chkFuncaoPublicaS = field as CheckBoxFormField;
                                chkFuncaoPublicaS.Checked = true;
                            }
                            break;
                        case "chkAgentePublicoN":
                            if (item.FlgAgentePublico == "N")
                            {
                                CheckBoxFormField chkFuncaoPublicaS = field as CheckBoxFormField;
                                chkFuncaoPublicaS.Checked = true;
                            }
                            break;
                        case "txtNomeRelacionado":
                            if (item.FlgAgentePublico == "S")
                                field.Text = item.NomeRelacionado;
                            break;
                        case "txtCPFRel":
                            if (item.FlgAgentePublico == "S")
                                field.Text = item.NumCPFRelacionado != null ? item.NumCPFRelacionado.Value.ToString(@"000\.000\.000\-00") : "";
                            break;
                        case "txtCargoFuncaoRel":
                            if (item.FlgAgentePublico == "S")
                                field.Text = item.CargoRelacionado;
                            break;
                        case "txtTipoRelacionament":
                            if (item.FlgAgentePublico == "S")
                                field.Text = item.TipoRelacionamento;
                            break;
                        case "txtLocal":
                            CultureInfo culture = new CultureInfo("pt-BR");
                            DateTimeFormatInfo dtfi = culture.DateTimeFormat;

                            int dia = DateTime.Now.Day;
                            int ano = DateTime.Now.Year;
                            string mes = culture.TextInfo.ToTitleCase(dtfi.GetMonthName(DateTime.Now.Month));
                            string data = dia + " de " + mes + " de " + ano;

                            field.Text = item.DescCidadeLoja + ", " + data;
                            break;
                        default:
                            // Throw an error or do nothing.
                            break;
                    }
                }

                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }

        #endregion

    }
}
