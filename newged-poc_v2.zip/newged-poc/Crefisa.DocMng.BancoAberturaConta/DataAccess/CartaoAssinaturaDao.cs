﻿using System;
using System.Collections.Generic;
using Crefisa.DocMng.BancoAberturaConta.DataAccess.Interface;
using Crefisa.DocMng.BancoAberturaConta.Entities;
using Crefisa.DocMng.Contracts;
using Crefisa.Infraestrutura.Dados;
using Crefisa.Infraestrutura.Log;

namespace Crefisa.DocMng.BancoAberturaConta.DataAccess
{
    public class CartaoAssinaturaDao : RepositorioBase<CartaoAssinaturaEntity>, ICartaoAssinaturaDao, IDisposable
    {

        #region Atributes
        #endregion

        #region Public Constructors

        #region CartaoAssinaturaDao(string nomeConexao)
        /// <summary>
        /// Construtor padrao classe CartaoAssinaturaDao.
        /// </summary>
        /// <param name="nomeConexao"></param>
        public CartaoAssinaturaDao(string nomeConexao)
            : base(nomeConexao)
        {

        }
        #endregion

        #endregion

        #region Public Methods

        /// <summary>
        /// Consulta Cartão Assinatura
        /// </summary>
        /// <param name="numCPF"></param>
        /// <returns></returns>
        public IEnumerable<CartaoAssinaturaEntity> ConsultarCartaoAssinatura(decimal numCPF)
        {
            CartaoAssinaturaEntity cartaoAssinaturaEntity = new CartaoAssinaturaEntity();
            cartaoAssinaturaEntity.NumCPF = numCPF;

            try
            {
                using (RepositorioBase<CartaoAssinaturaEntity> obj = new RepositorioBase<CartaoAssinaturaEntity>(Defines.ConnectionNameTstProd))
                {
                    return obj.Consultar(cartaoAssinaturaEntity);
                }
            }
            catch (Exception ex)
            {
                LoggerManager.Instance.Error(ex, "[DocMng.GenerateDocumentPdf] - Erro cartaoAssinaturaEntity", ex);
                throw; // Fix: Re-throw the original exception without using 'throw ex'
            }
        }

        #endregion

        #region Private Methods
        #endregion

    }
}
