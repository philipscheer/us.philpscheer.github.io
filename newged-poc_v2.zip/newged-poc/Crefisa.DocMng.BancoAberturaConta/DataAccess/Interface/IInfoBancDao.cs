﻿namespace Crefisa.DocMng.BancoAberturaConta.DataAccess.Interface
{
    public interface IInfoBancDao
    {
        decimal ConsultarTarifas(string codigoTarifa);
    }
}
