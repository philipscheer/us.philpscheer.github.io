﻿using System.Collections.Generic;
using Crefisa.Comum.Interfaces;
using Crefisa.DocMng.BancoAberturaConta.Entities;

namespace Crefisa.DocMng.BancoAberturaConta.DataAccess.Interface
{
    public interface IFichaCadPEPDao : IEntidadeDB
    {
        IEnumerable<FichaCadPEPEntity> ConsultarFichaCadPEPDao(decimal numCPF);
    }
}
