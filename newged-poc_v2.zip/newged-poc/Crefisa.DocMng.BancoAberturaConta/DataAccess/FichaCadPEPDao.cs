﻿using System;
using System.Collections.Generic;
using Crefisa.DocMng.BancoAberturaConta.DataAccess.Interface;
using Crefisa.DocMng.BancoAberturaConta.Entities;
using Crefisa.DocMng.Contracts;
using Crefisa.Infraestrutura.Dados;
using Crefisa.Infraestrutura.Log;

namespace Crefisa.DocMng.BancoAberturaConta.DataAccess
{
    public class FichaCadPEPDao : RepositorioBase<FichaCadPEPEntity>, IFichaCadPEPDao, IDisposable
    {

        #region Atributes
        #endregion

        #region Public Constructors

        #region FichaCadPEPDao(string nomeConexao)
        /// <summary>
        /// Construtor padrao classe FichaCadPEPDao.
        /// </summary>
        /// <param name="nomeConexao"></param>
        public FichaCadPEPDao(string nomeConexao)
            : base(nomeConexao)
        {

        }
        #endregion

        #endregion

        #region Public Methods

        /// <summary>
        /// Busca Ficha Cadastral para Clientes PEP
        /// </summary>
        /// <param name="numCPF"></param>
        /// <returns></returns>
        public IEnumerable<FichaCadPEPEntity> ConsultarFichaCadPEPDao(decimal numCPF)
        {
            FichaCadPEPEntity fichaCadPEPEntity = new FichaCadPEPEntity();
            fichaCadPEPEntity.NumCPF = numCPF;

            try
            {
                using (RepositorioBase<FichaCadPEPEntity> obj = new RepositorioBase<FichaCadPEPEntity>(Defines.ConnectionNameTstProd))
                {
                    return obj.Consultar(fichaCadPEPEntity);
                }
            }
            catch (Exception ex)
            {
                LoggerManager.Instance.Error(ex, "[DocMng.GenerateDocumentPdf] - Erro fichaCadPEPEntity", ex);
                throw; // Fix: Re-throw the original exception without using 'throw ex'
            }
        }

        #endregion

        #region Private Methods
        #endregion

    }
}
