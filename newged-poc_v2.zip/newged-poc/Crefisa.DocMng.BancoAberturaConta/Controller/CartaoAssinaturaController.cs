﻿using System;
using Crefisa.DocMng.BancoAberturaConta.Business;
using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.Contracts.DTO;
using Crefisa.DocMng.Contracts.Enumerator;
using Crefisa.DocMng.Contracts.Interface;

namespace Crefisa.DocMng.BancoAberturaConta.Controller
{
    public class CartaoAssinaturaController : IDocumentController
    {

        #region Atributes

        public EnumDocumentType DocumentType { get; set; }

        #endregion

        #region Public Constructors

        #region CartaoAssinaturaController()
        /// <summary>
        /// Construtor padrão da classe CartaoAssinaturaController.
        /// </summary>
        public CartaoAssinaturaController()
        {
            DocumentType = EnumDocumentType.CartaoAssinatura;
        }
        #endregion

        #endregion

        #region Public Methods

        #region GenerateDocumentPdf(ParamGenerateDocPdf param)
        /// <summary>
        /// Cria documento .PDF a partir de um arquivo .DOC
        /// </summary>
        /// <param name="param"></param>
        public DocMngDTO GenerateDocumentPdf(ParamGenerateDocPdf param)
        {
            try
            {
                DocMngDTO docMngDTO = new DocMngDTO();
                docMngDTO = CartaoAssinaturaBo.GenerateDocumentPdf(param);

                return docMngDTO;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #endregion

        #region Private Methods
        #endregion

    }
}
