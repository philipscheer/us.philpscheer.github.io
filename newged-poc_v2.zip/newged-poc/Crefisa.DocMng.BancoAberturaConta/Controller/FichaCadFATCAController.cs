﻿using System;
using Crefisa.DocMng.BancoAberturaConta.Business;
using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.Contracts.DTO;
using Crefisa.DocMng.Contracts.Enumerator;
using Crefisa.DocMng.Contracts.Interface;

namespace Crefisa.DocMng.BancoAberturaConta.Controller
{
    public class FichaCadFATCAController : IDocumentController
    {

        #region Atributes

        public EnumDocumentType DocumentType { get; set; }

        #endregion

        #region Public Constructors

        #region FichaCadFATCAController()
        /// <summary>
        /// Construtor padrão da classe FichaCadFATCAController.
        /// </summary>
        public FichaCadFATCAController()
        {
            DocumentType = EnumDocumentType.FichaCadastroFACTA;
        }
        #endregion

        #endregion

        #region Public Methods

        #region GenerateDocumentPdf(ParamGenerateDocPdf param)
        /// <summary>
        /// Cria documento .PDF a partir de um arquivo .DOC
        /// </summary>
        /// <param name="param"></param>
        public DocMngDTO GenerateDocumentPdf(ParamGenerateDocPdf param)
        {
            try
            {
                DocMngDTO docMngDTO = new DocMngDTO();
                docMngDTO = FichaCadFATCABo.GenerateDocumentPdf(param);

                return docMngDTO;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #endregion

        #region Private Methods
        #endregion

    }
}
