﻿using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.Contracts.DTO;
using Crefisa.DocMng.Contracts.Enumerator;
//using Crefisa.DocMng.RecEnt.Business.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crefisa.DocMng.RecEnt.Controller.Interface
{
    public interface IDocMngController
    {

        EnumDocumentType DocumentType { get; set; }

        DocMngDTO GenerateDocumentPdf(ParamGenerateDocPdf param);

    }
}
