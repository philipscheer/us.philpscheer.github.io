﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Crefisa.DocMng.Contracts.Enumerator;
using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.RecEnt.Controller.Interface;
using Crefisa.DocMng.Contracts.DTO;
using Crefisa.DocMng.PropAberConta.Business;
using Crefisa.DocMng.FichaCadPEP.Business;
using Crefisa.DocMng.FichaCadFACTA.Business;

namespace Crefisas.DocMng.Controller
{
    public class DocMngController : IDocMngController
    {

        #region Atributes

        public EnumDocumentType DocumentType { get; set; }

        #endregion

        #region Public Constructors

        #region DocMngController()
        /// <summary>
        /// Construtor padrão da classe DocMngController.
        /// </summary>
        public DocMngController()
        {
            //DocumentType = EnumDocumentType.ReciboEntregaContrato;
        }
        #endregion

        #endregion

        #region Public Methods

        #region GenerateDocumentPdf(ParamGenerateDocPdf param)
        /// <summary>
        /// Cria documento .PDF a partir de um arquivo .DOC
        /// </summary>
        /// <param name="param"></param>
        public DocMngDTO GenerateDocumentPdf(ParamGenerateDocPdf param)
        {
            DocMngDTO docMngDTO = new DocMngDTO();

            //switch (param.DocumentType)
            //{
            //    case EnumDocumentType.ReciboEntregaContrato:
            //        docMngDTO = ReciboEntregaBo.GenerateDocumentPdf(param);
            //        break;
            //    case EnumDocumentType.PropostaAberturaConta:
            //        docMngDTO = PropostaAberturaContaBo.GenerateDocumentPdf(param);
            //        break;
            //    case EnumDocumentType.FichaCadastroPessoFisisca:
            //        break;
            //    case EnumDocumentType.FichaCadastroFACTA:
            //        docMngDTO = FichaCadFACTABo.GenerateDocumentPdf(param);
            //        break;
            //    case EnumDocumentType.FichaCadastroPEP:
            //        docMngDTO = FichaCadPEPBo.GenerateDocumentPdf(param);
            //        break;
            //    case EnumDocumentType.PortabilidadeSalario:
            //        break;
            //    case EnumDocumentType.ContratoCartaoPrePago:
            //        break;
            //    case EnumDocumentType.CartaoAssinatura:
            //        break;
            //}

            return docMngDTO;
        }
        #endregion

        #endregion

        #region Private Methods
        #endregion

    }
}
