﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using Crefisa.Comum.Entidades.Enumeradores;
using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.Contracts.DTO;
using Crefisa.DocMng.DocGenerico.Util;
using Crefisa.DocMng.ServiceAgent;
using Crefisa.DocMng.ServiceAgent.ProxyServiceBus;
using Crefisa.Infraestrutura.Log;
using Spire.Doc;
using Spire.Doc.Documents;
using Spire.Doc.Fields;

namespace Crefisa.DocMng.DocGenerico.Business
{
    class DocGenericoBo
    {
        #region Atributes
        #endregion

        #region Public Constructors

        #region DocGenericoBo()
        /// <summary>
        /// Construtor padrão da classe DocGenericoBo.
        /// </summary>
        public DocGenericoBo()
        {

        }
        #endregion

        #endregion

        #region Public Methods

        #region GenerateDocumentPdf(ParamGenerateDocPdf param)
        /// <summary>
        /// Geração de um Documento não específico
        /// </summary>
        /// <param name="param"></param>
        public static DocMngDTO GenerateDocumentPdf(ParamGenerateDocPdf param)
        {
            Byte[] bytes = new Byte[0];
            string arquivoBase64 = string.Empty;

            try
            {
                IEnumerable<DocumentoConfigDTO> docConfig = null;
                string caminhoArquivoPDF, caminhoTemplate;
                var ret = new DocMngDTO();
                DocGenericoDTO docGenericoDTO;

                LoggerManager.Instance.Info("[DocGenericoBo.GenerateDocumentPdf] - Deserializando XML campo [Data]");
                docGenericoDTO = Crefisa.Infraestrutura.Serializers.SerializerContext.Deserialize<DocGenericoDTO>(param.Data, param.SerializerTypes);
                LoggerManager.Instance.Info("[DocGenericoBo.GenerateDocumentPdf] - Deserializando XML campo [Data] - OK");

                LoggerManager.Instance.Info("[DocGenericoBo.GenerateDocumentPdf] - Método [trataCaminhoArquivoPDF] de configuração do diretório onde será salvo arquivo em PDF ...");
                caminhoArquivoPDF = "";
                caminhoTemplate = "";
                LoggerManager.Instance.Info("[DocGenericoBo.GenerateDocumentPdf] - Método [trataCaminhoArquivoPDF] de configuração do diretório onde será salvo arquivo em PDF ... - OK");

                LoggerManager.Instance.Info("[DocGenericoBo.GenerateDocumentPdf] - Convertendo XML(CodigoExterno2) para PDF");

                /* ------------------------------------------------------------------------------------------ */
                /* Código do Tipo de Documento é o Código do Documento da Tabela OWR_GRF_BSI.TB_DMG_DOCUMENTO */
                /* ------------------------------------------------------------------------------------------ */
                if (!string.IsNullOrEmpty(docGenericoDTO.TipoDocumento))
                {
                    docConfig = BusService.ConsultarDocumentoConfig(new ServiceAgent.ProxyServiceBus.DocumentoConfigEntity
                    {
                        CodigoDocumento = Convert.ToInt32(docGenericoDTO.TipoDocumento),
                        DataHoraInclusao = docGenericoDTO.DataVigenciaTemplate //TO_DO - DataVigenciaTemplate check this field
                    });

                    if (docConfig == null)
                        throw new Exception("Nenhum template cadastrado para a vigencia informada!");

                    if (string.IsNullOrEmpty(docGenericoDTO.CaminhoArquivoPdf))
                    {
                        var diretorioBase = docConfig.ToList().FirstOrDefault(x => x.DescricaoCfg == "DIRETORIO_BASE_GERACAO").ValorConfiguracao;

                        //Seta Caminho base configurado para o arquivo
                        caminhoArquivoPDF = diretorioBase;

                        //Verifica se existe diretorio referente ao documento
                        if (!Directory.Exists(caminhoArquivoPDF))
                            Directory.CreateDirectory(caminhoArquivoPDF);

                        //Seta ano ao caminho base
                        caminhoArquivoPDF = Path.Combine(caminhoArquivoPDF, DateTime.Now.Year.ToString().PadLeft(4, '0'));

                        //Verifica se existe diretorio base + ano
                        if (!Directory.Exists(caminhoArquivoPDF))
                            Directory.CreateDirectory(caminhoArquivoPDF);

                        caminhoArquivoPDF = Path.Combine(caminhoArquivoPDF, DateTime.Now.Month.ToString().PadLeft(2, '0'));

                        //Verifica se existe diretorio base + ano + mes
                        if (!Directory.Exists(caminhoArquivoPDF))
                            Directory.CreateDirectory(caminhoArquivoPDF);

                        caminhoArquivoPDF = Path.Combine(caminhoArquivoPDF, DateTime.Now.Day.ToString().PadLeft(2, '0'));

                        //Verifica se existe diretorio base + ano + mes + dia
                        if (!Directory.Exists(caminhoArquivoPDF))
                            Directory.CreateDirectory(caminhoArquivoPDF);

                    }

                    if (string.IsNullOrEmpty(docGenericoDTO.CaminhoArquivoTemplate))
                    {
                        var nomeTemplateArquivo = docConfig.ToList().FirstOrDefault(x => x.DescricaoCfg == "NOME_TEMPLATE_ARQUIVO").ValorConfiguracao;
                        caminhoTemplate = Path.Combine(docConfig.ToList().FirstOrDefault(x => x.DescricaoCfg == "DIRETORIO_BASE_TEMPLATE").ValorConfiguracao, nomeTemplateArquivo);
                    }

                    docGenericoDTO.CaminhoArquivoPdf = caminhoArquivoPDF;
                    docGenericoDTO.CaminhoArquivoTemplate = caminhoTemplate;

                }
                else
                {
                    caminhoArquivoPDF = Utils.TratarCaminhoArquivoPDF(docGenericoDTO);
                    caminhoTemplate = Utils.TratarCaminhoTemplate(docGenericoDTO);
                }

                if (docGenericoDTO.CodigoExterno != "")
                {
                    LoggerManager.Instance.Info("[DocGenericoBo.GenerateDocumentPdf] - Busca arquivo template [" + caminhoTemplate + "]");
                    Spire.Doc.Document document = new Spire.Doc.Document(caminhoTemplate);

                    LoggerManager.Instance.Info("[DocGenericoBo.GenerateDocumentPdf] - Adicionar valores no PDF [" + docGenericoDTO.CodigoExterno + "]");
                    if (AdicionaValoresPDF(document, docGenericoDTO.Campos) && AdicionaImagensPDF(document, docGenericoDTO.Campos) && RemoverLinhas(document, docGenericoDTO.Campos))
                    {

                        #region [ *** TICKET 433861 *** ]

                        LoggerManager.Instance.Info("[DocGenericoBo.GenerateDocumentPdf] - Salvar arquivo no diretório [" + docGenericoDTO.CaminhoArquivoPdf + docGenericoDTO.NomeArquivo + "]");

                        if (string.IsNullOrEmpty(docGenericoDTO.FormatoArquivo))
                        {
                            document.SaveToFile(System.IO.Path.Combine(caminhoArquivoPDF, System.IO.Path.ChangeExtension(docGenericoDTO.NomeArquivo, "pdf")), Spire.Doc.FileFormat.PDF);
                        }
                        else
                        {
                            Spire.Doc.FileFormat _OutFormat;
                            Enum.TryParse<Spire.Doc.FileFormat>(docGenericoDTO.FormatoArquivo, out _OutFormat);
                            docGenericoDTO.NomeArquivo = System.IO.Path.ChangeExtension(docGenericoDTO.NomeArquivo, docGenericoDTO.FormatoArquivo);
                            document.SaveToFile(System.IO.Path.Combine(caminhoArquivoPDF, docGenericoDTO.NomeArquivo), _OutFormat);
                        }

                        #endregion

                        if (docConfig != null)
                        {
                            docConfig.ToList().Where(x => x.DescricaoCfg == "NOME_ARQUIVO_GERADO").FirstOrDefault().ValorConfiguracao = System.IO.Path.ChangeExtension(docGenericoDTO.NomeArquivo, "pdf");
                            docConfig.ToList().Where(x => x.DescricaoCfg == "DIRETORIO_BASE_GERACAO").FirstOrDefault().ValorConfiguracao = caminhoArquivoPDF;
                            docConfig.ToList().Where(x => x.DescricaoCfg == "URL_BASE_VISUALIZACAO").FirstOrDefault().ValorConfiguracao =
                            docConfig.ToList().Where(x => x.DescricaoCfg == "URL_BASE_VISUALIZACAO").FirstOrDefault().ValorConfiguracao +
                            DateTime.Now.Year.ToString().PadLeft(4, '0') + "/" + DateTime.Now.Month.ToString().PadLeft(2, '0') + "/" + DateTime.Now.Day.ToString().PadLeft(2, '0') + "/";

                            BusService.IncluirDocumentoGerado(
                                new DocumentoGeradoDTO
                                {
                                    CfgJSON = Crefisa.Infraestrutura.Serializers.SerializerContext.Serialize(docConfig, SerializerTypes.Json),
                                    CodigoDocumento = Convert.ToInt32(docGenericoDTO.TipoDocumento),
                                    CodigoExterno = docGenericoDTO.CodigoExterno,
                                    DataHoraInclusao = DateTime.Now,
                                    UsuarioInclusao = Environment.UserName
                                });
                        }
                    }
                }
                else
                {
                    LoggerManager.Instance.Info("[DocGenericoBo.GenerateDocumentPdf] - Não existe Dados para a geração do Cartão de Assinatura em PDF do contrato [" + docGenericoDTO.CodigoExterno + "]");
                    docGenericoDTO.NomeArquivo = "Arquivo não gerado para o cpf [" + docGenericoDTO.CodigoExterno + "]";
                }

                if (param.RetornaBase64 != null)
                {
                    bytes = File.ReadAllBytes(Path.Combine(caminhoArquivoPDF, docGenericoDTO.NomeArquivo));
                    arquivoBase64 = Convert.ToBase64String(bytes);
                }

                return (new DocMngDTO
                {
                    CaminhoArquivoPdf = docGenericoDTO.CaminhoArquivoPdf,
                    CaminhoArquivoTemplate = docGenericoDTO.CaminhoArquivoTemplate,
                    CodigoExterno = docGenericoDTO.CodigoExterno,
                    NomeArquivo = docGenericoDTO.NomeArquivo,
                    ArquivoBase64 = Convert.ToBase64String(bytes)
                });
            }
            catch (Exception ex)
            {
                LoggerManager.Instance.Error(ex, "[DocGenericoBo.GenerateDocumentPdf] - Erro ao gerar documento em PDF", ex);
                throw; // Fix: Re-throw the original exception without using 'throw ex'
            }
        }
        #endregion

        #endregion

        #region Private Methods

        private static bool RemoverLinhas(Spire.Doc.Document document, IEnumerable<CampoDocGenericoDTO> items)
        {
            try
            {
                CampoDocGenericoDTO campoRemoverLinha = items.Where(item => item.NomeCampo.Contains("RemoverLinhasQuadros")).FirstOrDefault();

                if (campoRemoverLinha != null)
                {
                    int[] quadros = campoRemoverLinha.ValorCampo.Split(',').Select(Int32.Parse).ToArray();

                    foreach (int quadro in quadros)
                    {
                        //consulta no XML quantas parcelas existem
                        double qtdeParcelas = items.Where(item => item.NomeCampo.ToLower().Contains(string.Format("q{0}nrparcela", quadro))).Count();

                        //primeira página do Doc
                        Spire.Doc.Table table = document.Sections[0].Tables[1] as Spire.Doc.Table;

                        if (quadro == 3)
                            table = document.Sections[0].Tables[2] as Spire.Doc.Table; //segunda página do Doc

                        //para o quadro de parcelas de acordo, devemos colocar 3 parcelas por linha
                        if (quadro == 2 || quadro == 3)
                        {
                            qtdeParcelas = qtdeParcelas / 3;

                            if (qtdeParcelas % 3 > 0)
                                qtdeParcelas += 1;

                            qtdeParcelas = Math.Floor(qtdeParcelas);
                        }

                        if (qtdeParcelas > 0)
                        {
                            int linha = 0;
                            int linhaUltimaParcela = 0;
                            int linhaFinalQuadro = 0;

                            while (linha < table.Rows.Count)
                            {
                                //início quadro parcelas de acordo
                                if (table.Rows[linha].Cells[0].Paragraphs[0].Text.ToLower().Contains(string.Format("{0}º quadro", quadro)))
                                {
                                    //pulamos uma linha para pegar o início da primeira parcela
                                    linha++;

                                    //final do quadro = início do quadro + quantidade de parcelas
                                    linhaUltimaParcela = linha + Convert.ToInt32(qtdeParcelas);

                                    //determina o final do loop. Para o quadro 1 são 12 linhas. Para o quadro 2 e 3 são 8 linhas
                                    if (quadro == 1)
                                        linhaFinalQuadro = linha + 12;
                                    else if (quadro == 2 || quadro == 3)
                                        linhaFinalQuadro = linha + 8;

                                    break;
                                }
                                linha++;
                            }

                            while (linha <= linhaFinalQuadro)
                            {
                                if (linha > linhaUltimaParcela)
                                {
                                    //remover linha vazia
                                    table.Rows.RemoveAt(linha);

                                    //como removemos um item do array é preciso regredir um nível para continuar a interação
                                    linha--;
                                    linhaFinalQuadro--;
                                }
                                linha++;
                            }
                        }
                    }
                }

                return true;
            }
            catch (Exception e)
            {
                throw;
            }
        }

        /// <summary>
        /// Adiciona valores nos campos mapeados ao PDF gerado
        /// </summary>
        /// <param name="document"></param>
        /// <param name="item"></param>
        /// <returns></returns>
        private static bool AdicionaValoresPDF(Spire.Doc.Document document, IEnumerable<CampoDocGenericoDTO> items)
        {
            try
            {
                //Adiciona valores aos atributos do arquivo que será gerado em PDF
                foreach (Spire.Doc.Fields.FormField field in document.Sections[0].Body.FormFields)
                {
                    foreach (var item in items)
                    {
                        if (item.NomeCampo.ToLower() == field.Name.ToLower())
                        {
                            switch (item.TipoCampo.ToLower())
                            {
                                case "textfield":
                                    field.Text = item.ValorCampo;
                                    //if (field.Name == "motivo") { field.Text = "teste"; }
                                    break;
                                case "textfieldhtml":
                                    var p1 = field.OwnerParagraph;
                                    p1.AppendHTML(item.ValorCampo);
                                    break;
                                case "checkfield":
                                    CheckBoxFormField chkForm = field as CheckBoxFormField;
                                    if (item.ValorCampo.ToLower() == "true")
                                    {
                                        chkForm.Checked = true;
                                    }
                                    else
                                    {
                                        chkForm.Checked = false;
                                    }
                                    break;
                                default:
                                    break;
                            }

                        }
                    }
                }

                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }

        private static bool AdicionaImagensPDF(Spire.Doc.Document document, IEnumerable<CampoDocGenericoDTO> items)
        {
            try
            {
                foreach (var item in items)
                {
                    if (item.TipoCampo == "barcode128field")
                    {
                        if (item.NomeCampo.ToLower() == "codigobarrastermodeacordo")
                            AdicionaCodBarrasTermoDeAcordo(item.ValorCampo, document, item.NomeCampo);
                        else
                            AdicionaCodBarras(item.ValorCampo, document, item.NomeCampo);
                    }
                    else if (item.TipoCampo == "barcodeinterleaved2of5")
                        AdicionaCodBarrasBoleto(item.ValorCampo, document, item.NomeCampo);
                    else if (item.TipoCampo == "banklogotype")
                        AdicionarLogoBoleto(item.ValorCampo, document, item.NomeCampo);
                }

                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static void AdicionaCodBarras(String codigo, Spire.Doc.Document document, String nomeImagem)
        {
            foreach (Section section in document.Sections)
            {
                foreach (Paragraph paragraph in section.Paragraphs)
                {
                    //Loop through the child elements of paragraph
                    foreach (DocumentObject docObj in paragraph.ChildObjects)
                    {
                        if (docObj.DocumentObjectType == DocumentObjectType.Picture)
                        {
                            DocPicture picture = docObj as DocPicture;
                            picture.Width = 135;
                            picture.Height = 32;

                            if (picture.Title == nomeImagem)
                            {
                                BarcodeLib.Barcode bCode = new BarcodeLib.Barcode();
                                bCode.LabelFont = new Font("Myriad Pro", 18, FontStyle.Bold);
                                bCode.IncludeLabel = true;
                                //Replace the image
                                picture.LoadImage(bCode.Encode(BarcodeLib.TYPE.CODE128, codigo));
                                picture.Width = 135;
                                picture.Height = 32;
                                return;
                            }
                        }
                    }

                }
            }
        }

        private static void AdicionaCodBarrasTermoDeAcordo(String codigo, Spire.Doc.Document document, String nomeImagem)
        {
            foreach (Section section in document.Sections)
            {
                foreach (Spire.Doc.Table table in section.Body.Tables)
                {
                    foreach (Spire.Doc.TableRow row in table.Rows)
                    {
                        foreach (Spire.Doc.TableCell cell in row.Cells)
                        {
                            foreach (Spire.Doc.Documents.Paragraph paragraph in cell.Paragraphs)
                            {
                                foreach (DocumentObject paragraphItem in paragraph.Items)
                                {
                                    if (paragraphItem.DocumentObjectType == DocumentObjectType.Picture)
                                    {
                                        DocPicture picture = paragraphItem as DocPicture;
                                        float largura = picture.Width;
                                        float altura = picture.Height;

                                        if (picture.Title.ToLower() == nomeImagem.ToLower())
                                        {
                                            BarcodeLib.Barcode bCode = new BarcodeLib.Barcode();
                                            bCode.Width = Convert.ToInt32(largura);
                                            bCode.Height = Convert.ToInt32(altura);
                                            bCode.Alignment = BarcodeLib.AlignmentPositions.RIGHT;
                                            //Replace the image
                                            picture.LoadImage(bCode.Encode(BarcodeLib.TYPE.CODE128, codigo));
                                            picture.Width = largura;
                                            picture.Height = altura;
                                            return;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }


        private static void AdicionaCodBarrasBoleto(String codigo, Spire.Doc.Document document, String nomeImagem)
        {
            foreach (Section section in document.Sections)
            {
                foreach (Paragraph paragraph in section.Paragraphs)
                {
                    //Loop through the child elements of paragraph
                    foreach (DocumentObject docObj in paragraph.ChildObjects)
                    {
                        if (docObj.DocumentObjectType == DocumentObjectType.Picture)
                        {
                            DocPicture picture = docObj as DocPicture;

                            if (picture.Title == nomeImagem)
                            {
                                BarcodeLib.Barcode bCode = new BarcodeLib.Barcode();
                                bCode.Alignment = BarcodeLib.AlignmentPositions.LEFT;
                                bCode.Width = 700;
                                bCode.Height = 50;
                                //Replace the image
                                picture.LoadImage(bCode.Encode(BarcodeLib.TYPE.Interleaved2of5, codigo));
                                picture.Width = 700;
                                picture.SetScale(50, 700); // Fix: Use SetScale method instead of WidthScale and HeightScale
                                picture.HorizontalAlignment = ShapeHorizontalAlignment.Left;
                                return;
                            }
                        }
                    }
                }
            }
        }

        private static void AdicionarLogoBoleto(String caminhoImagem, Spire.Doc.Document document, String nomeImagem)
        {
            foreach (Section section in document.Sections)
            {
                foreach (Paragraph paragraph in section.Paragraphs)
                {
                    //Loop through the child elements of paragraph
                    foreach (DocumentObject docObj in paragraph.ChildObjects)
                    {
                        if (docObj.DocumentObjectType == DocumentObjectType.Picture)
                        {
                            DocPicture picture = docObj as DocPicture;

                            if (picture.Title == nomeImagem)
                            {
                                //Replace the image
                                picture.LoadImage(Image.FromFile(caminhoImagem));
                                picture.Width = 80;
                                picture.SetScale(40, 80); // Fix: Use SetScale method instead of WidthScale and HeightScale
                            }
                        }
                    }
                }
            }
        }
        #endregion
    }
}

