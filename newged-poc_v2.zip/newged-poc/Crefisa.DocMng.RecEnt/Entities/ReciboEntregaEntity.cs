﻿using System;
using Crefisa.Comum.Atributos;
using Crefisa.Comum.Interfaces;

namespace Crefisa.DocMng.RecEnt.Entities
{

    [EntidadeDB(ProcedureConsulta = "PC_DOC_SELRECIBOENTREGAFILTRO")]
    public class ReciboEntregaEntity : IEntidadeDB
    {
        [ColunaDB("COD_CONTRATO")]
        public string CodContrato { get; set; }

        [ColunaDB("COD_LOJA")]
        public int CodLoja { get; set; }

        [ColunaDB("NUM_TRANSACAO")]
        public int NumTransacao { get; set; }

        [ColunaDB("NUM_CPF")]
        public decimal NumCPF { get; set; }

        [ColunaDB("FLAG_AUT_EMAIL_SMS")]
        public string FlagAutEmailSMS { get; set; }

        [ColunaDB("DESC_LOJA")]
        public string DescLoja { get; set; }

        [ColunaDB("NOME_CLIENTE")]
        public string NomeCliente { get; set; }

        [ColunaDB("VAL_PRINCIPAL")]
        public string ValPrincipal { get; set; }

        [ColunaDB("VAL_PRESTACAO")]
        public string ValPrestacao { get; set; }

        [ColunaDB("QTDE_PRESTACOES")]
        public decimal QtdePrestacoes { get; set; }

        [ColunaDB("NUM_RG")]
        public Int64 NumRG { get; set; }

        [ColunaDB("EXISTE_IMPRESSAO")]
        public string ExisteImpressao { get; set; }

        [ColunaDB("SESSION_ID")]
        public string SessionID { get; set; }

        [ColunaDB("DESC_RET_GERA_DOC")]
        public string DescRetGeraDOC { get; set; }

        [ColunaDB("COD_USUARIO")]
        public string CodUsuario { get; set; }

        [ColunaDB("NOME_USUARIO")]
        public string NomeUsuario { get; set; }

        [ColunaDB("VAL_PRIN")]
        public string ValPrin { get; set; }

        [ColunaDB("VAL_PREST")]
        public string ValPrest { get; set; }

        [ColunaDB("VAL_FINANC")]
        public string ValFinanc { get; set; }

        [ColunaDB("VAL_RENOVACAO")]
        public string ValRenovacao { get; set; }

        [ColunaDB("VAL_LIBERACAO")]
        public string ValLiberacao { get; set; }

        [ColunaDB("NOME_BANCO")]
        public string NomeBanco { get; set; }

        [ColunaDB("COD_BANCO")]
        public int CodBanco { get; set; }

        [ColunaDB("COD_AGENCIA")]
        public int CodAgencia { get; set; }

        [ColunaDB("DIG_AGENCIA")]
        public string DigAgencia { get; set; }

        [ColunaDB("COD_CONTA")]
        public decimal CodConta { get; set; }

        [ColunaDB("DIG_CONTA")]
        public string DigConta { get; set; }

        [ColunaDB("DESC_CIDADE")]
        public string DescCidade { get; set; }

        //INFORMACAO PARA RECIBO
        [ColunaDB("NUM_DDD")]
        public string DescDdd { get; set; }

        [ColunaDB("NUM_TELEFONE")]
        public string DescTelefone { get; set; }

        [ColunaDB("DESC_EMAIL")]
        public string DescEmail { get; set; }

        [ColunaDB("COD_ENVIO_DOC")]
        public string CodEnviodoc { get; set; }



    }
}