using System.Threading.Tasks;
using Grpc.Core;



namespace Crefisa.DocMng.RecEnt.gRPC // Added namespace
{
    public class DocumentServiceImplementation : DocumentService.DocumentServiceBase
    {
        public override Task<DocMngDTO> GenerateDocumentPdf(ParamGenerateDocPdf request, ServerCallContext context)
        {
            return Task.FromResult(new DocMngDTO
            {
                Result = "Documento Gerado com Sucesso"
            });
        }
    }
}