﻿using System.Collections.Generic;
using Crefisa.Comum.Interfaces;
using Crefisa.DocMng.RecEnt.Entities;

namespace Crefisa.DocMng.RecEnt.DataAccess.Interface
{
    public interface IRepositorioReciboEntrega : IEntidadeDB
    {
        IEnumerable<ReciboEntregaEntity> ConsultarReciboEntrega(int codLoja, int numTransacao);
    }
}
