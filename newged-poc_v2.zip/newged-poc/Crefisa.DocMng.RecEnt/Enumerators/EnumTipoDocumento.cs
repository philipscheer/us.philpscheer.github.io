﻿namespace Crefisa.DocMng.RecEnt.Enumerators
{
    public enum EnumTipoDocumento
    {
        ReciboEntrega = 63
    }
}
