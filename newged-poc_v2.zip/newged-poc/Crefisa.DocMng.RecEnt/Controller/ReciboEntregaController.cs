﻿using System;
using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.Contracts.DTO;
using Crefisa.DocMng.Contracts.Enumerator;
using Crefisa.DocMng.RecEnt.Business;
using Microsoft.AspNetCore.Mvc;

namespace Crefisas.DocMng.RecEnt.Controller
{
    [ApiController]
    [Route("TESTE")]
    public class ReciboEntregaController : ControllerBase
    {

        #region Atributes

        public EnumDocumentType DocumentType { get; set; }

        #endregion

        #region Public Constructors

        #region ReciboEntregaController()
        /// <summary>
        /// Construtor padrão da classe ReciboEntregaController.
        /// </summary>
        public ReciboEntregaController()
        {
            DocumentType = EnumDocumentType.ReciboEntregaContrato;
        }
        #endregion

        #endregion

        #region Public Methods

        #region GenerateDocumentPdf(ParamGenerateDocPdf param)
        /// <summary>
        /// Cria documento .PDF a partir de um arquivo .DOC
        /// </summary>
        /// <param name="param"></param>
        [HttpPost]
        public IActionResult GenerateDocumentPdf(ParamGenerateDocPdf param)
        {
            try
            {
                DocMngDTO docMngDTO = new DocMngDTO();
                docMngDTO = ReciboEntregaBo.GenerateDocumentPdf(param);

                return Ok(docMngDTO);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #endregion

        #region Private Methods
        #endregion

    }
}
