﻿using Crefisa.Comum.Interfaces;
using Crefisa.DocMng.RecEnt.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crefisa.DocMng.RecEnt.DataAccess.Interface
{
    public interface IRepositorioReciboEntrega: IEntidadeDB
    {
        IEnumerable<ReciboEntregaEntity> ConsultarReciboEntrega(int codLoja, int numTransacao);
    }
}
