﻿using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.RecEnt.DataAccess.Interface;
using Crefisa.DocMng.RecEnt.Entities;
using Crefisa.Infraestrutura.Dados;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crefisa.DocMng.RecEnt.DataAccess
{
    public class ReciboEntregaDao : Crefisa.Infraestrutura.Dados.RepositorioBase<ReciboEntregaEntity>, IRepositorioReciboEntrega, IDisposable
    {

        #region Atributes
        #endregion

        #region Public Constructors

        #region ReciboEntregaDao(string nomeConexao)
        /// <summary>
        /// Construtor padrao classe ReciboEntregaDao.
        /// </summary>
        /// <param name="nomeConexao"></param>
        public ReciboEntregaDao(string nomeConexao)
            : base(nomeConexao)
        {

        }
        #endregion

        #endregion

        #region Public Methods

        /// <summary>
        /// Busca Recibo de Entrega
        /// </summary>
        /// <param name="codLoja"></param>
        /// <param name="numTransacao"></param>
        /// <returns></returns>
        public IEnumerable<ReciboEntregaEntity> ConsultarReciboEntrega(int codLoja, int numTransacao)
        {
            ReciboEntregaEntity reciboEntregaEntity = new ReciboEntregaEntity();
            reciboEntregaEntity.CodLoja = codLoja;
            reciboEntregaEntity.NumTransacao = numTransacao;

            try
            {
                using (RepositorioBase<ReciboEntregaEntity> obj = new RepositorioBase<ReciboEntregaEntity>(Defines.ConnectionNameTstProd))
                {
                    return obj.Consultar(reciboEntregaEntity);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region Private Methods
        #endregion
        
    }
}
