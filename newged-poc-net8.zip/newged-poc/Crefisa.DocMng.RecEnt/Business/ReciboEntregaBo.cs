﻿using Crefisa.Comum.Entidades.Dao;
using Crefisa.Comum.Negocio.Dominio;
using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.Contracts.DTO;
using Crefisa.DocMng.RecEnt.DataAccess;
using Crefisa.DocMng.RecEnt.Entities;
using Crefisa.DocMng.RecEnt.Enumerators;
using Crefisa.Infraestrutura.Dados;
using Crefisa.Infraestrutura.Log;
using Spire.Doc;
using Spire.Doc.Documents;
using Spire.Doc.Fields;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crefisa.DocMng.RecEnt.Business
{
    public class ReciboEntregaBo
    {
        #region Atributes

        #endregion

        #region Public Constructors

        #region ReciboEntregaBo()
        /// <summary>
        /// Construtor padrão da classe ReciboEntregaBo.
        /// </summary>
        public ReciboEntregaBo()
        {

        }
        #endregion

        #endregion

        #region Public Methods

        #region GenerateDocumentPdf(ParamGenerateDocPdf param)
        /// <summary>
        /// Geração do Documento de acordo com o tipo do Documento
        /// 
        /// Ex.:
        ///     XML: <Retorno xmlns=""><CodigoExterno>020390007752</CodigoExterno><NomeArquivo>ReciboEntrega_Modelo2.docx</NomeArquivo><CaminhoArquivoTemplate>C:\\inetpub\\wwwroot\\docmng\\Doc\\TemplatePDF</CaminhoArquivoTemplate><CaminhoArquivoPdf>\\\\syswebhmg\\sysin\\DESENVOLVIMENTO\\www\\documentos\\Recibo\\</CaminhoArquivoPdf></Retorno>
        /// </summary>
        /// <param name="param"></param>
        public static DocMngDTO GenerateDocumentPdf(ParamGenerateDocPdf param)
        {
            try
            {
                ServiceBus.ParamImpressaoDocto impressaoDoctoDTO = new ServiceBus.ParamImpressaoDocto();
                DocMngDTO docMngDTO;
                string caminhoArquivoPDF;

                LoggerManager.Instance.Info("[DocMng.GenerateDocumentPdf] - Descerializando XML campo [Data]");
                docMngDTO = Crefisa.Infraestrutura.Serializers.SerializerContext.Deserialize<DocMngDTO>(param.Data, param.SerializerTypes);
                LoggerManager.Instance.Info("[DocMng.GenerateDocumentPdf] - Descerializando XML campo [Data] - OK");
                LoggerManager.Instance.Info("[DocMng.GenerateDocumentPdf] - Método [trataCaminhoArquivoPDF] de configuração do diretório onde será salvo arquivo em PDF ...");
                caminhoArquivoPDF = tratarCaminhoArquivoPDF(docMngDTO.CaminhoArquivoPdf);
                LoggerManager.Instance.Info("[DocMng.GenerateDocumentPdf] - Método [trataCaminhoArquivoPDF] de configuração do diretório onde será salvo arquivo em PDF ... - OK");

                //Consulta Dados do Cliente
                LoggerManager.Instance.Info("[DocMng.GenerateDocumentPdf] - Consulta Dados do Cliente para emissão do Recibo em PDF");
                using (ReciboEntregaDao obj = new ReciboEntregaDao(Defines.ConnectionNameTstProd))
                {

                    IEnumerable<ReciboEntregaEntity> ret = obj.ConsultarReciboEntrega(int.Parse(docMngDTO.CodigoExterno.Substring(0, 5)), int.Parse(docMngDTO.CodigoExterno.Substring(5, 7)));

                    if (ret.Count() != 0)
                    {
                        foreach (var item in ret)
                        {
                            LoggerManager.Instance.Info("[DocMng.GenerateDocumentPdf] - Emissão de Recibo em PDF para o contrato [" + item.CodContrato + "]");
                            LoggerManager.Instance.Info("[DocMng.GenerateDocumentPdf] - Busca arquivo template [" + docMngDTO.NomeArquivo + "]");
                            Spire.Doc.Document document = new Spire.Doc.Document(System.IO.Path.Combine(docMngDTO.CaminhoArquivoTemplate, docMngDTO.NomeArquivo));

                            if (adicionaValoresPDF(document, item, docMngDTO))
                            {
                                //Save doc file.
                                LoggerManager.Instance.Info("[DocMng.GenerateDocumentPdf] - Salvar arquivo no diretório [" + docMngDTO.CaminhoArquivoPdf + "]");
                                docMngDTO.NomeArquivo = docMngDTO.NomeArquivo.Substring(0, docMngDTO.NomeArquivo.Length - 5) + "." + item.CodContrato + "." +
                                                            DateTime.Now.Day.ToString().PadLeft(2, '0') +
                                                            DateTime.Now.Month.ToString().PadLeft(2, '0') +
                                                            DateTime.Now.Year.ToString() + "." +
                                                            DateTime.Now.Hour.ToString().PadLeft(2, '0') +
                                                            DateTime.Now.Minute.ToString().PadLeft(2, '0')
                                                            + ".pdf";

                                //Save doc file.
                                LoggerManager.Instance.Info("[DocMng.GenerateDocumentPdf] - Salvar arquivo no diretório [" + caminhoArquivoPDF + "]");
                                document.SaveToFile(System.IO.Path.Combine(caminhoArquivoPDF, System.IO.Path.ChangeExtension(docMngDTO.NomeArquivo, "pdf")), Spire.Doc.FileFormat.PDF);

                                //Envia retorno somente do caminho do Path 
                                //  criado com a regra conforme método privado [trataCaminhoArquivoPDF]
                                docMngDTO.CaminhoArquivoPdf = caminhoArquivoPDF.Substring(docMngDTO.CaminhoArquivoPdf.Length - 1, caminhoArquivoPDF.Length - docMngDTO.CaminhoArquivoPdf.Length + 1);

                                //Prepara dados para inclusão nas tabelas de Impressão e Histórico
                                impressaoDoctoDTO.CodLoja = item.CodLoja;
                                impressaoDoctoDTO.CodContrato = item.CodContrato;
                                impressaoDoctoDTO.NumCPF = item.NumCPF;
                                impressaoDoctoDTO.NumTransacao = item.NumTransacao;
                                impressaoDoctoDTO.FlagAtivo = "1";
                                impressaoDoctoDTO.DescArquivoDOCCliente = docMngDTO.NomeArquivo;
                                impressaoDoctoDTO.DescCaminhoDOCCliente = caminhoArquivoPDF;
                                impressaoDoctoDTO.DescArquivoDOCCrefisa = docMngDTO.NomeArquivo;
                                impressaoDoctoDTO.DescCaminhoDOCCrefisa = caminhoArquivoPDF;
                                impressaoDoctoDTO.DescRetGeraDOC = item.DescRetGeraDOC;
                                impressaoDoctoDTO.DescValidaSite = null;
                                impressaoDoctoDTO.CodSeqBarcode = null;
                                impressaoDoctoDTO.ParEnvSMS = "S";
                                impressaoDoctoDTO.ParImpDadosContr = "S";
                                impressaoDoctoDTO.ParTipoFluxo = "C";
                                impressaoDoctoDTO.DescRetWS = "A";
                                impressaoDoctoDTO.SessionID = null;
                                impressaoDoctoDTO.TipoConta = "1";
                                impressaoDoctoDTO.TipoDocumento = "R";

                                LoggerManager.Instance.Info("[DocMng.GenerateDocumentPdf] - Executa WebSevice para inclusão dos dados do Recibo nas Tabelas de Impressão de Documentos");
                                //Aciona serviço de Inclusão 
                                using (ServiceBus.ServiceBusServiceClient serviceBus = new ServiceBus.ServiceBusServiceClient())
                                {
                                    serviceBus.IncluirImpressaoDocto(impressaoDoctoDTO);
                                }
                            }

                            LoggerManager.Instance.Info("[DocMng.GenerateDocumentPdf] - Executa WebSevice OK");
                        }
                    }
                    else
                    {
                        LoggerManager.Instance.Info("[DocMng.GenerateDocumentPdf] - Não existe Dados para a geração do Recibo em PDF do contrato [" + docMngDTO.CodigoExterno + "]");
                        docMngDTO.Exception = "Arquivo não gerado para o contrato [" + docMngDTO.CodigoExterno + "]";
                    }

                    return docMngDTO;
                }
            }
            catch (Exception ex)
            {
                LoggerManager.Instance.Error(ex, "[DocMng.GenerateDocumentPdf] - Erro ao gerar Recibo em PDF", ex);
                throw ex;
            }
        }
        #endregion

        #endregion

        #region Private Methods

        /// <summary>
        /// Trata Caminho do Arquivo PDF
        /// </summary>
        /// <param name="caminhoArquivoPdf"></param>
        /// <returns></returns>
        private static string tratarCaminhoArquivoPDF(string caminhoArquivoPdf)
        {
            try
            {
                string ano;
                string mes;
                string dia;
                string hora;
                string novoCaminhoPdf;

                if (caminhoArquivoPdf == null)
                {
                    novoCaminhoPdf = System.Configuration.ConfigurationManager.AppSettings["CaminhoArquivoTemplate"];
                }
                else { novoCaminhoPdf = caminhoArquivoPdf; }

                //Verificar se pasta já existe, caso não, cria uma nova
                // Considerar seguinte path: 
                // Path: Ano\Mes\Dia\
                ano = DateTime.Now.Year.ToString();
                mes = DateTime.Now.Month.ToString().PadLeft(2, '0');
                dia = DateTime.Now.Day.ToString().PadLeft(2, '0');
                hora = DateTime.Now.Hour.ToString().PadLeft(2, '0') + DateTime.Now.Minute.ToString().PadLeft(2, '0');

                //ano
                if (!Directory.Exists(novoCaminhoPdf + ano))
                    Directory.CreateDirectory(novoCaminhoPdf + ano);

                //mes
                if (!Directory.Exists(novoCaminhoPdf + ano + "\\" + mes))
                    Directory.CreateDirectory(novoCaminhoPdf + ano + "\\" + mes);

                //dia
                if (!Directory.Exists(novoCaminhoPdf + ano + "\\" + mes + "\\" + dia))
                    Directory.CreateDirectory(novoCaminhoPdf + ano + "\\" + mes + "\\" + dia);

                novoCaminhoPdf = novoCaminhoPdf + ano + "\\" + mes + "\\" + dia + '\\';

                return novoCaminhoPdf;
            }
            catch (Exception)
            {

                throw;
            }
        }

        /// <summary>
        /// Adiciona valores nos campos mapeados ao PDF gerado
        /// </summary>
        /// <param name="document"></param>
        /// <param name="item"></param>
        /// <returns></returns>
        private static bool adicionaValoresPDF(Spire.Doc.Document document, ReciboEntregaEntity item, DocMngDTO docMngDTO)
        {
            try
            {
                ///verificar biometria não gerar codigo de barras
                ///


                if (!docMngDTO.FlagBiometria)
                {


                    foreach (Paragraph paragraph in document.Sections[0].Paragraphs)
                    {
                        //Loop through the child elements of paragraph
                        foreach (DocumentObject docObj in paragraph.ChildObjects)
                        {
                            if (docObj.DocumentObjectType == DocumentObjectType.Picture)
                            {
                                DocPicture picture = docObj as DocPicture;
                                if (picture.Title == "BarcodeImg")
                                {
                                    BarcodeLib.Barcode bCode = new BarcodeLib.Barcode();
                                    bCode.IncludeLabel = true;
                                    
                                     
                                    //Replace the image
                                    picture.LoadImage(bCode.Encode(BarcodeLib.TYPE.CODE128, docMngDTO.CodBarrasRecibo));
                                    
                                    picture.Width = 145;
                                    picture.Height = 42;
                                }
                            }
                        }
                    }
                }
                //Adiciona valores aos atributos do arquivo que será gerado em PDF
                foreach (Spire.Doc.Fields.FormField field in document.Sections[0].Body.FormFields)
                {
                    switch (field.Name)
                    {
                        case "txtCidade":
                            field.Text = item.DescCidade;
                            break;
                        case "txtDia":
                            field.Text = DateTime.Now.Day.ToString();
                            break;
                        case "txtMes":
                            field.Text = DateTime.Now.ToString("MMMM", CultureInfo.CurrentCulture).ToUpper();
                            break;
                        case "txtAno":
                            field.Text = DateTime.Now.Year.ToString();
                            break;
                        case "txtContrato":
                            field.Text = item.CodContrato;
                            break;
                        case "txtNome":
                            field.Text = item.NomeCliente;
                            break;
                        case "txtCpf":
                            field.Text = item.NumCPF.ToString();
                            break;

                        case "txtContrato2":
                            field.Text = item.CodContrato;
                            break;

                        case "chkRecImpressao":
                            if (item.CodEnviodoc == "1")
                            {
                                CheckBoxFormField chkRecImpressao = field as CheckBoxFormField;
                                chkRecImpressao.Checked = true;
                            }
                            break;

                        case "chkRecEmail":
                            if (item.CodEnviodoc == "2")
                            {
                                CheckBoxFormField chkRecEmail = field as CheckBoxFormField;
                                chkRecEmail.Checked = true;
                            }
                            break;

                        case "txtEmail":
                            field.Text = item.DescEmail;
                        break;

                        case "chkRecSMS":
                            if (item.CodEnviodoc == "3")
                            {
                                CheckBoxFormField chkRecSMS = field as CheckBoxFormField;
                                chkRecSMS.Checked = true;
                            }
                            break;

                        case "txtDDD":
                            field.Text = item.DescDdd;
                            break;


                        case "txtTelefone":
                            field.Text = item.DescTelefone;
                            break;


                        case "txtLocalData":
                            CultureInfo culture = new CultureInfo("pt-BR");
                            DateTimeFormatInfo dtfi = culture.DateTimeFormat;

                            int dia = DateTime.Now.Day;
                            int ano = DateTime.Now.Year;
                            string mes = culture.TextInfo.ToTitleCase(dtfi.GetMonthName(DateTime.Now.Month));
                            string data = dia + " de " + mes + " de " + ano;

                            field.Text = item.DescCidade + ", " + data;
                            break;


                        default:
                            // Throw an error or do nothing.
                            break;
                    }
                }
                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }

        private static object DefinirParametrosComando(DbCommand cmd)
        {
            throw new NotImplementedException();
        }



        #endregion

    }
}
