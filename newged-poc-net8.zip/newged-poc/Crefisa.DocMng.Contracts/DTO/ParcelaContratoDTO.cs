﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Crefisa.DocMng.Contracts.DTO
{
    public class ParcelaContratoDTO
    {
        /// <summary>
        /// Número da parcela
        /// </summary>
        [XmlElement(ElementName = "Parcela")]
        public string Parcela { get; set; }

        /// <summary>
        /// Valor da parcela
        /// </summary>
        [XmlElement(ElementName = "Valor")]
        public string Valor { get; set; }

        /// <summary>
        /// Data do vencimento da parcela
        /// </summary>
        [XmlElement(ElementName = "Data")]
        public string Data { get; set; }
    }
}
