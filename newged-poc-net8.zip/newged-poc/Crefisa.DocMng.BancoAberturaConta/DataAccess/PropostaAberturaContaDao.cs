﻿using Crefisa.DocMng.BancoAberturaConta.DataAccess.Interface;
using Crefisa.DocMng.BancoAberturaConta.Entities;
using Crefisa.DocMng.Contracts;
using Crefisa.Infraestrutura.Dados;
using System;
using System.Collections.Generic;

namespace Crefisa.DocMng.BancoAberturaConta.DataAccess
{
    public class PropostaAberturaContaDao : RepositorioBase<PropostaAberturaContaEntity>, IPropostaAberturaContaDao, IDisposable
    {

        #region Atributes
        #endregion

        #region Public Constructors

        #region ReciboEntregaDao(string nomeConexao)
        /// <summary>
        /// Construtor padrao classe ReciboEntregaDao.
        /// </summary>
        /// <param name="nomeConexao"></param>
        public PropostaAberturaContaDao(string nomeConexao)
            : base(nomeConexao)
        {

        }
        #endregion

        #endregion

        #region Public Methods

        /// <summary>
        /// Busca Proposta Abertura de Conta
        /// </summary>
        /// <param name="numCPF"></param>
        /// <returns></returns>
        public IEnumerable<PropostaAberturaContaEntity> ConsultarPropostaAberturaConta(decimal numCPF)
        {
            PropostaAberturaContaEntity propostaAberturaContaEntity = new PropostaAberturaContaEntity();
            propostaAberturaContaEntity.NumCPF = numCPF;

            try
            {
                using (RepositorioBase<PropostaAberturaContaEntity> obj = new RepositorioBase<PropostaAberturaContaEntity>(Defines.ConnectionNameTstProd))
                {
                    return obj.Consultar(propostaAberturaContaEntity);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
         }

        #endregion

        #region Private Methods
        #endregion
        
    }
}
