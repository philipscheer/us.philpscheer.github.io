using Microsoft.AspNetCore.Mvc;
using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.Contracts.DTO;

namespace Crefisa.DocMng.RecEnt.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DocumentController : ControllerBase
    {
        [HttpPost("GenerateDocumentPdf")]
        public ActionResult<DocMngDTO> GenerateDocumentPdf([FromBody] ParamGenerateDocPdf param)
        {
            // Implementação do serviço WCF migrado
            var response = new DocMngDTO
            {
                // Defina os valores conforme necessário
            };

            return Ok(response);
        }
    }
}
