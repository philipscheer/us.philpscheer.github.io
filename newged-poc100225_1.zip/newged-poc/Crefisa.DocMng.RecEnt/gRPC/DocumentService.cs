using System.Threading.Tasks;
using Grpc.Core;
using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.Contracts.DTO;
using Crefisa.DocMng.RecEnt.gRPC; // Ensure this namespace is correct



namespace Crefisa.DocMng.RecEnt.gRPC // Added namespace
{
    public class DocumentServiceImplementation : DocumentService.DocumentServiceBase
    {
        public override Task<DocMngDTO> GenerateDocumentPdf(ParamGenerateDocPdf request, ServerCallContext context)
        {
            return Task.FromResult(new DocMngDTO
            {
                Result = "Documento Gerado com Sucesso"
            });
        }
    }
}