﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crefisa.DocMng.Contracts.Enumerator;
using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.DocGenerico.Business;
using Crefisa.DocMng.Contracts.DTO;
using Crefisa.DocMng.Contracts.Interface;

namespace Crefisa.DocMng.DocGenerico.Controller
{
    public class DocGenericoController: IDocumentController
    {
        #region Atributes

        public EnumDocumentType DocumentType { get; set; }

        #endregion

        #region Public Constructors

        #region DocGenericoController()
        /// <summary>
        /// Construtor padrão da classe DocGenericoController.
        /// </summary>
        public DocGenericoController()
        {
            DocumentType = EnumDocumentType.Undefined;
        }
        #endregion

        #endregion

        #region Public Methods

        #region GenerateDocumentPdf(ParamGenerateDocPdf param)
        /// <summary>
        /// Cria documento .PDF a partir de um arquivo .DOC
        /// </summary>
        /// <param name="param"></param>
        public DocMngDTO GenerateDocumentPdf(ParamGenerateDocPdf param)
        {
            try
            {
                var docGenericoDTO = new DocMngDTO();
                docGenericoDTO = DocGenericoBo.GenerateDocumentPdf(param);

                return docGenericoDTO;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #endregion

        #region Private Methods
        #endregion
    }
}


