﻿using System.Xml.Linq;
using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.Contracts.DTO;
using Crefisa.DocMng.Contracts.Interface;
using Crefisa.DocMng.ServiceAgent;
using Crefisa.DocMng.ServiceAgent.ProxyServiceBus;
using Crefisa.DocMng.WCF.API.Installers;
//using Crefisa.Infraestrutura.Installers;
using Crefisa.Infraestrutura.Log;
using Microsoft.AspNetCore.Mvc;
using Spire.Doc;
using System;

namespace Crefisa.DocMng.WCF.API.Controllers
{
    [ApiController]
    [Route("Service1")]
    public class DocumentService : ControllerBase
    {
        private static readonly CustomObjectManager _InjectCustomObjectManager = new CustomObjectManager();
        private readonly IWebHostEnvironment _env;
        private readonly IConfiguration _config;
        public DocumentService(IWebHostEnvironment env, IConfiguration configuration) { _env = env; _config = configuration; }

        [HttpPost]
        public IActionResult GenerateDocumentPdf(ParamGenerateDocPdf param)
        {
            try
            {
                Spire.License.LicenseProvider.SetLicenseFileFullPath(_config["PathLicenseSpireDoc"]);

                var ret = new DocMngDTO();
                //var json = new JavaScriptSerializer().Serialize(GetXmlData(XElement.Parse(param.Data)));

                var dadosRecebidos = Crefisa.Infraestrutura.Serializers.SerializerContext.Serialize<ParamGenerateDocPdf>(param, param.SerializerTypes);

                //var dadosRecebidos = Crefisa.Infraestrutura.Serializers.SerializerContext.Serialize<ParamGenerateDocPdf>(param, SerializerTypes.Json);
                var dtInicioExecucao = DateTime.Now;

                ParamProcessoExecucao paramProcessoRet = new ParamProcessoExecucao();

                if (_InjectCustomObjectManager.container == null)
                    _InjectCustomObjectManager.CreateContainer(new DocumentInstaller());

                //Gravar início do processo em execução
                ParamProcessoExecucao paramProcesso = BusService.GravarProcessoExecucao(param);

                _InjectCustomObjectManager.container.ResolveAll<IDocumentController>().ToList().ForEach(x =>
                {
                    if (x.DocumentType == param.DocumentType)
                    {
                        ret = x.GenerateDocumentPdf(param);
                    }
                });

                //Gravar fim do processo em execução
                BusService.AtualizarProcessoExecucao(ret, paramProcesso);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                LoggerManager.Instance.UseErrorFloodContention = false;
                LoggerManager.Instance.Error(ex, "[Crefisa.DocMng.WCF.Service1.GenerateDocumentPdf] - Erro na geração PDF.");
                throw;
            }
        }

        /// <summary>
        /// Get XML Data
        /// </summary>
        /// <param name="xml"></param>
        /// <returns></returns>
        private static Dictionary<string, object> GetXmlData(XElement xml)
        {
            var attr = xml.Attributes().ToDictionary(d => d.Name.LocalName, d => (object)d.Value);
            if (xml.HasElements) attr.Add("_value", xml.Elements().Select(e => GetXmlData(e)));
            else if (!xml.IsEmpty) attr.Add("_value", xml.Value);

            return new Dictionary<string, object> { { xml.Name.LocalName, attr } };
        }
    }
}
