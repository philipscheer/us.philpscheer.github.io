﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Crefisa.DocMng.Contracts.DTO
{
    /// <summary>
    /// Classe com definição do retorno recebido no metodo de recebimento dos dados 
    /// de Impressão de Recibo de Contrato.
    /// </summary>
    [XmlRoot("Retorno")]
    public class DocGenericoDTO
    {        
        /// <summary>
        /// Código Externo
        /// </summary>
        [XmlElement(ElementName = "CodigoExterno")]
        public string CodigoExterno { get; set; }

        /// <summary>
        /// Caminho onde esta localizado o Template para geração do PDF.
        /// </summary>
        [XmlElement(ElementName = "NomeArquivo")]
        public string NomeArquivo { get; set; }

        /// <summary>
        /// Caminho onde esta localizado o Template para geração do PDF.
        /// </summary>
        [XmlElement(ElementName = "CaminhoArquivoTemplate")]
        public string CaminhoArquivoTemplate { get; set; }

        /// <summary>
        /// Caminho onde seá salvo o PDF gerado.
        /// </summary>
        [XmlElement(ElementName = "CaminhoArquivoPdf")]
        public string CaminhoArquivoPdf { get; set; }

        /// <summary>
        /// Excção ocorrida no processo de geração do arquivo
        /// </summary>

        [XmlArray("CamposFormulario")]
        [XmlArrayItem("CampoDocGenerico")]
        //[XmlElement(ElementName = "CamposFormulario")]
        public List<CampoDocGenericoDTO> Campos;

        /// <summary>
        /// Código do Tipo de Documento é o Código do Documento da Tabela OWR_GRF_BSI.TB_DMG_DOCUMENTO
        /// </summary>
        [XmlElement(ElementName = "TipoDeDocumento")]
        public string TipoDocumento { get; set; }

        /// <summary>
        /// Indica formato do arquivo a ser gerado (DOCX ou PDF)
        /// </summary>
        [XmlElement(ElementName = "FormatoArquivo")]
        public string FormatoArquivo { get; set; }

        /// <summary>
        /// Data de vigencia template
        /// </summary>
        [XmlElement(ElementName = "DataVigenciaTemplate")]
        public DateTime DataVigenciaTemplate { get; set; }

        /// <summary>
        /// Data de vigencia template
        /// </summary>
        [XmlElement(ElementName = "Biometria")]
        public bool Biometria { get; set; }

    }
}



