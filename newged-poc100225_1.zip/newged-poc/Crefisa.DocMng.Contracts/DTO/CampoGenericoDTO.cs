﻿using System.Xml.Serialization;
using System;

namespace Crefisa.DocMng.Contracts.DTO
{
    //[XmlRoot("CampoDocGenerico")]
    public class CampoDocGenericoDTO
    {
        /// <summary>
        /// Nome do campo em referência ao formfield do doc template
        /// </summary>
        [XmlElement(ElementName = "NomeCampo")]
        public string NomeCampo { get; set; }

        /// <summary>
        /// Valor do campo em referência ao formfield do doc template
        /// </summary>
        [XmlElement(ElementName = "ValorCampo")]
        public string ValorCampo { get; set; }

        /// <summary>
        /// Tipo do campo em referência ao formfield do doc template
        /// </summary>
        [XmlElement(ElementName = "TipoCampo")]
        public string TipoCampo { get; set; }

        /// <summary>
        /// Data de vigência do template
        /// </summary>
        [XmlElement(ElementName = "DataVigenciaTemplate")]
        public DateTime DataVigenciaTemplate { get; set; } // Added this property
    }
}
