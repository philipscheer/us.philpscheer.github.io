﻿using Crefisa.DocMng.Contracts.DTO;
using Crefisa.DocMng.Contracts.Enumerator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crefisa.DocMng.Contracts.Interface
{
    public interface IDocumentController
    {

        EnumDocumentType DocumentType { get; set; }

        DocMngDTO GenerateDocumentPdf(ParamGenerateDocPdf param);

    }
}