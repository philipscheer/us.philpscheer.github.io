﻿using Crefisa.DocMng.Contracts.Interface;
using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.Contracts.DTO;
using Crefisa.DocMng.WCF.Installers;
using Crefisa.Infraestrutura.Installers;
using System;
using System.Collections.Generic;
using System.Linq;
//using System.Web.Script.Serialization;
using System.Xml.Linq;
using Crefisa.Comum.Entidades.Enumeradores;
using System.Configuration;
using Crefisa.Infraestrutura.Log;
using Crefisa.DocMng.ServiceAgent.ProxyServiceBus;
using Crefisa.DocMng.ServiceAgent;
using Spire;
using Microsoft.Extensions.Configuration;
using ConfigurationManager = System.Configuration.ConfigurationManager;
using System.Text.Json;

namespace Crefisa.DocMng.WCF
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IDocumentService
    {
        private static readonly CustomObjectManager _InjectCustomObjectManager = new CustomObjectManager();

        public DocMngDTO GenerateDocumentPdf(ParamGenerateDocPdf param)
        {
            try
            {
                Spire.License.LicenseProvider.SetLicenseFileFullPath(ConfigurationManager.AppSettings["PathLicenseSpireDoc"]);

                var ret = new DocMngDTO();
                //var json = new JavaScriptSerializer().Serialize(GetXmlData(XElement.Parse(param.Data)));
                var dadosRecebidos = Crefisa.Infraestrutura.Serializers.SerializerContext.Serialize<ParamGenerateDocPdf>(param, param.SerializerTypes);
                //var dadosRecebidos = Crefisa.Infraestrutura.Serializers.SerializerContext.Serialize<ParamGenerateDocPdf>(param, SerializerTypes.Json);
                var dtInicioExecucao = DateTime.Now;
                ParamProcessoExecucao paramProcessoRet = new ParamProcessoExecucao();

                if (_InjectCustomObjectManager.container == null)
                    _InjectCustomObjectManager.CreateContainer(new DocumentInstaller());

                //Gravar início do processo em execução
                ParamProcessoExecucao paramProcesso = BusService.GravarProcessoExecucao(param);

                _InjectCustomObjectManager.container.ResolveAll<IDocumentController>().ToList().ForEach(x =>
                {
                    if (x.DocumentType == param.DocumentType)
                    {
                        ret = x.GenerateDocumentPdf(param);
                    }
                });

                //Gravar fim do processo em execução
                BusService.AtualizarProcessoExecucao(ret, paramProcesso);

                return ret;
            }
            catch (Exception ex)
            {
                LoggerManager.Instance.UseErrorFloodContention = false;
                LoggerManager.Instance.Error(ex, "[Crefisa.DocMng.WCF.Service1.GenerateDocumentPdf] - Erro na geração PDF.");
                throw;
            }
        }

        /// <summary>
        /// Get XML Data
        /// </summary>
        /// <param name="xml"></param>
        /// <returns></returns>
        private static Dictionary<string, object> GetXmlData(XElement xml)
        {
            var attr = xml.Attributes().ToDictionary(d => d.Name.LocalName, d => (object)d.Value);
            if (xml.HasElements) attr.Add("_value", xml.Elements().Select(e => GetXmlData(e)));
            else if (!xml.IsEmpty) attr.Add("_value", xml.Value);

            return new Dictionary<string, object> { { xml.Name.LocalName, attr } };
        }

        
    }
}
