﻿using Crefisa.Comum.Interfaces;
using Crefisa.DocMng.BancoAberturaConta.Entities;
using System.Collections.Generic;

namespace Crefisa.DocMng.BancoAberturaConta.DataAccess.Interface
{
    public interface IFichaCadPFDao: IEntidadeDB
    {
        IEnumerable<FichaCadPFEntity> ConsultarFichaCadPF(decimal numCPF);
    }
}
