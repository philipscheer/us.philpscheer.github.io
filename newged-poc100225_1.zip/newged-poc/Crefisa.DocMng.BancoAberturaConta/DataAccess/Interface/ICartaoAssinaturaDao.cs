﻿using Crefisa.Comum.Interfaces;
using Crefisa.DocMng.BancoAberturaConta.Entities;
using System.Collections.Generic;

namespace Crefisa.DocMng.BancoAberturaConta.DataAccess.Interface
{
    public interface ICartaoAssinaturaDao: IEntidadeDB
    {
        IEnumerable<CartaoAssinaturaEntity> ConsultarCartaoAssinatura(decimal numCPF);
    }
}
