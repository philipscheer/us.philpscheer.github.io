﻿using Crefisa.DocMng.BancoAberturaConta.DataAccess.Interface;
using Crefisa.DocMng.BancoAberturaConta.Entities;
using Crefisa.DocMng.Contracts;
using Crefisa.Infraestrutura.Dados;
using System;
using System.Collections.Generic;

namespace Crefisa.DocMng.BancoAberturaConta.DataAccess
{
    public class FichaCadFATCADao : RepositorioBase<FichaCadFATCAEntity>, IFichaCadFATCADao, IDisposable
    {

        #region Atributes
        #endregion

        #region Public Constructors

        #region FichaCadFACTADao(string nomeConexao)
        /// <summary>
        /// Construtor padrao classe FichaCadFACTADao.
        /// </summary>
        /// <param name="nomeConexao"></param>
        public FichaCadFATCADao(string nomeConexao)
            : base(nomeConexao)
        {

        }
        #endregion

        #endregion

        #region Public Methods

        /// <summary>
        /// Busca Ficha Cadastral para Clientes PEP
        /// </summary>
        /// <param name="numCPF"></param>
        /// <returns></returns>
        public IEnumerable<FichaCadFATCAEntity> ConsultarFichaCadFACTA(decimal numCPF)
        {
            FichaCadFATCAEntity fichaCadFACTAEntity = new FichaCadFATCAEntity();
            fichaCadFACTAEntity.NumCPF = numCPF;

            try
            {
                using (RepositorioBase<FichaCadFATCAEntity> obj = new RepositorioBase<FichaCadFATCAEntity>(Defines.ConnectionNameTstProd))
                {
                    return obj.Consultar(fichaCadFACTAEntity);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region Private Methods
        #endregion
        
    }
}
