﻿using Crefisa.DocMng.Contracts.Interface;
using System;
using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.Contracts.DTO;
using Crefisa.DocMng.Contracts.Enumerator;

namespace Crefisa.DocMng.BancoAberturaConta.Controller
{
    public class BancoAberturaContaController : IDocumentController
    {

        #region Atributes

        public EnumDocumentType DocumentType { get; set; }

        #endregion

        #region Public Constructors

        #region CartaoAssinaturaController()
        /// <summary>
        /// Construtor padrão da classe CartaoAssinaturaController.
        /// </summary>
        public BancoAberturaContaController()
        {
            DocumentType = EnumDocumentType.BancoAberturaConta;
        }
        #endregion

        #endregion

        #region Public Methods

        #region GenerateDocumentPdf(ParamGenerateDocPdf param)
        /// <summary>
        /// Cria documento .PDF a partir de um arquivo .DOC
        /// </summary>
        /// <param name="param"></param>
        public DocMngDTO GenerateDocumentPdf(ParamGenerateDocPdf param)
        {
            try
            {
                var retCartaoAssinatura = new DocMngDTO();
                var retFichaCadastroPessoFisisca = new DocMngDTO();
                var retPropostaAberturaConta = new DocMngDTO();
                var ret = new DocMngDTO();

                var paramretCartaoAssinatura = new ParamGenerateDocPdf { Data = param.Data.Replace("<NomeArquivo></NomeArquivo>", "<NomeArquivo>Cartao_Assinaturas.docx</NomeArquivo>"), DocumentType = param.DocumentType, SerializerTypes = param.SerializerTypes, User = param.User };
                retCartaoAssinatura = Business.CartaoAssinaturaBo.GenerateDocumentPdf(paramretCartaoAssinatura);

                var paramFichaCadastroPessoFisisca = new ParamGenerateDocPdf { Data = param.Data.Replace("<NomeArquivo></NomeArquivo>", "<NomeArquivo>Ficha_Cadastral_PF_Proposta.docx</NomeArquivo>"), DocumentType = param.DocumentType, SerializerTypes = param.SerializerTypes, User = param.User };
                retFichaCadastroPessoFisisca = Business.FichaCadPFBo.GenerateDocumentPdf(paramFichaCadastroPessoFisisca);

                var paramPropostaAberturaConta = new ParamGenerateDocPdf { Data = param.Data.Replace("<NomeArquivo></NomeArquivo>", "<NomeArquivo>Proposta_Abertura_de_Conta_Pessoa_Fisica.docx</NomeArquivo>"), DocumentType = param.DocumentType, SerializerTypes = param.SerializerTypes, User = param.User };
                retPropostaAberturaConta = Business.PropostaAberturaContaBo.GenerateDocumentPdf(paramPropostaAberturaConta);

                if (string.IsNullOrEmpty(retCartaoAssinatura.Exception))
                    ret.NomeArquivo += "CARTAOASSINATURA__" + retCartaoAssinatura.NomeArquivo + "||";
                else
                    ret.Exception = "Erro geração cartao assinatura. Documento não gerado.";

                if (string.IsNullOrEmpty(retFichaCadastroPessoFisisca.Exception))
                    ret.NomeArquivo += "FICHACADASTROPESSOAFISICA__" + retFichaCadastroPessoFisisca.NomeArquivo + "||";
                else
                    ret.Exception = "Erro geração ficha cadastro pessoa fisica. Documento não gerado.";

                if (string.IsNullOrEmpty(retPropostaAberturaConta.Exception))
                    ret.NomeArquivo += "PROPOSTAABERTURACONTA__" + retPropostaAberturaConta.NomeArquivo + "||";
                else
                    ret.Exception = "Erro geração proposta abertura conta. Documento não gerado.";

                ret.CaminhoArquivoPdf = retCartaoAssinatura.CaminhoArquivoPdf;
                ret.CaminhoArquivoTemplate = retCartaoAssinatura.CaminhoArquivoTemplate;
                ret.CodigoExterno = retCartaoAssinatura.CodigoExterno;
                ret.Exception = "";

                return ret;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #endregion

        #region Private Methods
        #endregion
    }
}
