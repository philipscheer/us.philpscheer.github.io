﻿using System.Xml.Serialization;

namespace Crefisa.DocMng.Contracts.DTO
{

    /// <summary>
    /// Classe com definição do retorno recebido no metodo de recebimento dos dados 
    /// de Impressão de Recibo de Contrato.
    /// </summary>
    [XmlRoot("Retorno")]
    public class DocMngDTO
    {

        /// <summary>
        /// Código Externo
        /// </summary>
        [XmlElement(ElementName = "CodigoExterno")]
        public string CodigoExterno { get; set; }

        /// <summary>
        /// Caminho onde esta localizado o Template para geração do PDF.
        /// </summary>
        [XmlElement(ElementName = "NomeArquivo")]
        public string NomeArquivo { get; set; }

        /// <summary>
        /// Caminho onde esta localizado o Template para geração do PDF.
        /// </summary>
        [XmlElement(ElementName = "CaminhoArquivoTemplate")]
        public string CaminhoArquivoTemplate { get; set; }

        /// <summary>
        /// Caminho onde seá salvo o PDF gerado.
        /// </summary>
        [XmlElement(ElementName = "CaminhoArquivoPdf")]
        public string CaminhoArquivoPdf { get; set; }

        /// <summary>
        /// Excção ocorrida no processo de geração do arquivo
        /// </summary>
        [XmlElement(ElementName = "Exception")]
        public string Exception { get; set; }

        /// <summary>
        /// Código Externo 2
        /// </summary>
        [XmlElement(ElementName = "CodigoExterno2")]
        public string CodigoExterno2 { get; set; }


        /// <summary>
        /// Flag Biometria
        /// </summary>
        [XmlElement(ElementName = "FlagBiometria")]
        public bool FlagBiometria {  get; set;  }


        /// <summary>
        /// Código de barras
        /// </summary>
        [XmlElement(ElementName = "CodBarrasRecibo")]
        public string CodBarrasRecibo { get; set; }

        /// <summary>
        /// Caminho onde esta localizado o Template para geração do PDF.
        /// </summary>
        [XmlElement(ElementName = "ArquivoBase64")]
        public string ArquivoBase64 { get; set; }

    }





}
