﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crefisa.DocMng.Contracts.Enumerator
{
    public enum EnumDocumentType
    {
        Undefined = 0,
        Proposta = 1,
        CobrancaBoleto = 2,
        CobrancaDebito = 3,
        ReciboEntregaContrato = 4,
        FichaCadastroPessoFisisca = 5,
        FichaCadastroPessoFisiscaRepresentante = 6,
        CartaoAssinatura = 7,
        PropostaAberturaConta = 8,
        FichaCadastroPEP = 9,
        FichaCadastroFACTA = 10,
        ContratoCartaoPrePago = 11,
        BancoAberturaConta = 99
    }
}
