﻿using Crefisa.Comum.Atributos;
using Crefisa.Comum.Interfaces;

namespace Crefisa.DocMng.BancoAberturaConta.Entities
{

    [EntidadeDB(ProcedureConsulta = "PC_BPN_SELCADASTRO")]
    public class CartaoAssinaturaEntity: IEntidadeDB
    {
        [ColunaDB("FLAG_TIPO_CLIENTE")]
        public string FlagTipoPessoa { get; set; }

        [ColunaDB("NOME_CLIENTE")]
        public string NomeCliente { get; set; }

        [ColunaDB("NUM_CPF")]
        public decimal NumCPF { get; set; }

        [ColunaDB("NOME_REPRESENTANTE")]
        public string NomeRepresentante { get; set; }

        [ColunaDB("CPF_REPRESENTANTE")]
        public decimal CPFRepresentante { get; set; }

        [ColunaDB("COD_LOJA")]
        public int CodLoja { get; set; }

        [ColunaDB("DESC_LOJA")]
        public string DescLoja { get; set; }
    }
}