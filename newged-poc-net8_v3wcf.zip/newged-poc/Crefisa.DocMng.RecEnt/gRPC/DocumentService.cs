using Grpc.Core;
using Crefisa.DocMng.RecEnt.gRPC;

public class DocumentService : DocumentServiceBase
{
    public override Task<DocMngDTO> GenerateDocumentPdf(ParamGenerateDocPdf request, ServerCallContext context)
    {
        return Task.FromResult(new DocMngDTO
        {
            Result = "Documento Gerado com Sucesso"
        });
    }
}
