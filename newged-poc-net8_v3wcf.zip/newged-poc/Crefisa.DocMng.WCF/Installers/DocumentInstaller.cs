﻿using Castle.MicroKernel.Registration;
using Castle.MicroKernel.SubSystems.Configuration;
using Castle.Windsor;
using Crefisa.DocMng.Contracts.Interface;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Hosting;

namespace Crefisa.DocMng.WCF.Installers
{
    public class DocumentInstaller : IWindsorInstaller
    {

        #region Atributes
        #endregion

        #region Public Methods

        public void Install(IWindsorContainer container, IConfigurationStore store)
        {
            Infraestrutura.Log.LoggerManager.Instance.Info("[DocumentInstaller.Install] - Iniciando Install");
            var pathToFind = (HostingEnvironment.ApplicationPhysicalPath == null ? AppDomain.CurrentDomain.BaseDirectory : Path.Combine(HostingEnvironment.ApplicationPhysicalPath, @"Plugins"));
            Infraestrutura.Log.LoggerManager.Instance.Info("[DocumentInstaller.Install] - Injection on {0} directory", pathToFind);

            try
            {
                Directory.GetDirectories(pathToFind).ToList().ForEach(directoryPlugin =>
                {
                    container.Register(Classes.FromAssemblyInDirectory(new AssemblyFilter(directoryPlugin))
                    .BasedOn<IDocumentController>().WithServiceFromInterface()
                    .LifestyleSingleton());
                }
                );
            }
            catch (Exception ex)
            {
                Infraestrutura.Log.LoggerManager.Instance.Error(ex, "[DocumentInstaller.Install] - Erro ao Install");
                throw;
            }

            Infraestrutura.Log.LoggerManager.Instance.Info("[DocumentInstaller.Install] - Finalizando Install");
        }

        #endregion

        #region Private Methods
        #endregion

    }
}
