﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Crefisa.DocMng.Contracts.DTO
{
    /// <summary>
    /// Classe com definição do retorno recebido no metodo de recebimento dos dados 
    /// de Impressão de Recibo de Contrato.
    /// </summary>
    [XmlRoot("Retorno")]
    public class DocContratoDTO
    {        
        /// <summary>
        /// Código Externo
        /// </summary>
        [XmlElement(ElementName = "CodigoExterno")]
        public string CodigoExterno { get; set; }
        /// <summary>
        /// Número do Contrato
        /// </summary>
        [XmlElement(ElementName = "NumeroContrato")]
        public string NumeroContrato { get; set; }

        /// <summary>
        /// Caminho onde esta localizado o Template para geração do PDF.
        /// </summary>
        [XmlElement(ElementName = "NomeArquivo")]
        public string NomeArquivo { get; set; }

        /// <summary>
        /// Caminho onde esta localizado o Template para geração do PDF.
        /// </summary>
        [XmlElement(ElementName = "CaminhoArquivoTemplate")]
        public string CaminhoArquivoTemplate { get; set; }

        /// <summary>
        /// Caminho onde seá salvo o PDF gerado.
        /// </summary>
        [XmlElement(ElementName = "CaminhoArquivoPdf")]
        public string CaminhoArquivoPdf { get; set; }

        /// <summary>
        /// Excção ocorrida no processo de geração do arquivo
        /// </summary>

        [XmlArray("CamposFormulario")]
        [XmlArrayItem("CampoDocGenerico")]
        public List<CampoDocGenericoDTO> CamposFormulario { get; set; }

        [XmlArray("TabelaParcelas")]
        [XmlArrayItem("Parcela")]
        public List<ParcelaContratoDTO> TabelaParcelas { get; set; }

        [XmlArray("TabelaConfissaoDividas")]
        [XmlArrayItem("Divida")]
        public List<ConfissaoDividaDTO> TabelaConfissaoDividas { get; set; } 

    }
}



