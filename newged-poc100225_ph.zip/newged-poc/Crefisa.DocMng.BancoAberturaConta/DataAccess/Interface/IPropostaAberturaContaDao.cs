﻿using Crefisa.Comum.Interfaces;
using Crefisa.DocMng.BancoAberturaConta.Entities;
using System.Collections.Generic;

namespace Crefisa.DocMng.BancoAberturaConta.DataAccess.Interface
{
    public interface IPropostaAberturaContaDao: IEntidadeDB
    {
        IEnumerable<PropostaAberturaContaEntity> ConsultarPropostaAberturaConta(decimal numCPF);
    }
}
