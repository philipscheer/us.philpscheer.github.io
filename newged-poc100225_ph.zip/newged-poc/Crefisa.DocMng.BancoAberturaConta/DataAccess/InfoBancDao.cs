﻿using Crefisa.DocMng.BancoAberturaConta.DataAccess.Interface;
using Crefisa.DocMng.BancoAberturaConta.Entities;
using Crefisa.Infraestrutura.Dados;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crefisa.DocMng.BancoAberturaConta.DataAccess
{
    public class InfoBancDao : RepositorioBase<TarifaEntity>, IInfoBancDao, IDisposable
    {

        #region Atributes
        #endregion

        #region Public Constructors

        #region InfoBancDao(string nomeConexao)
        /// <summary>
        /// Construtor padrao classe InfoBancDao.
        /// </summary>
        /// <param name="nomeConexao"></param>
        public InfoBancDao(string nomeConexao)
            : base(nomeConexao)
        {

        }
        #endregion

        #endregion

        #region Public Methods

        #region ConsultarTarifas(string codigoTarifa)
        /// <summary>
        /// Busca Proposta Abertura de Conta
        /// </summary>
        /// <param name="numCPF"></param>
        /// <returns></returns>
        public decimal ConsultarTarifas(string codigoTarifa)
        {
            decimal ret = 0;

            try
            {
                var strSql = string.Format(@"SELECT * FROM AB_INFOBANC..TARIFAS WHERE CODTARIFA='{0}'", codigoTarifa);

                using (var comando = ObterComando(strSql, TipoComando.Texto))
                {
                    var retT = CustomExecuteReader<TarifaEntity>(comando);
                    if (retT != null && retT.ToList().Count > 0)
                        ret = retT.FirstOrDefault().Valor != null ? retT.FirstOrDefault().Valor.Value : 0;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ret;
        }
        #endregion

        #endregion

        #region Private Methods
        #endregion

    }
}
