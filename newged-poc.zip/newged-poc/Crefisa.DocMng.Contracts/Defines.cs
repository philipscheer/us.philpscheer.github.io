﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crefisa.DocMng.Contracts
{
    /// <summary>
    /// Classe com constantes utilizadas no projeto.
    /// </summary>
    public static class Defines
    {

        /// <summary>
        /// Nome do identificador da string de conexão para acessar CN_TSTPROD.
        /// </summary>
        public const string ConnectionNameTstProd = "ConnectionTSTPROD";

        /// <summary>
        /// Nome do identificador da string de conexão para acessar APP_GRF_BSI.
        /// </summary>
        public const string ConnectionNameBsi = "ConnectionBSI";

        /// <summary>
        /// Nome do identificador da string de conexão para acessar APP_GRF_BSI.
        /// </summary>
        public const string ConnectionInfoBanc = "ConnectionINFOBANC";

        /// <summary>
        /// Lista de identificador do Documento em PDF
        /// </summary>
        public const string ConfirmaDocumentos = "CONFIRMADOCUMENTOS";

        /// <summary>
        /// Nome do identificador do Tipo de Documento Recibo
        /// </summary>
        public const string TipoDocumentoR = "TIPODOCUMENTOR";
        
        /// <summary>
        /// Nome do identificador Possui Domicilio Fiscal
        /// </summary>
        public const string DomicilioFiscal = "DOMICILIOFISCAL";
        
    }
}
