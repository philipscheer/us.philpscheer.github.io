﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Crefisa.DocMng.Contracts.DTO
{
    public class ConfissaoDividaDTO
    {
        /// <summary>
        /// Número do contrato
        /// </summary>
        [XmlElement(ElementName = "Contrato")]
        public string Contrato { get; set; }

        /// <summary>
        /// Quantidade de parcelas
        /// </summary>
        [XmlElement(ElementName = "QtdParcelas")]
        public string QtdParcelas { get; set; }

        /// <summary>
        /// Valor total das parcelas
        /// </summary>
        [XmlElement(ElementName = "Valor")]
        public string Valor { get; set; }
    }
}
