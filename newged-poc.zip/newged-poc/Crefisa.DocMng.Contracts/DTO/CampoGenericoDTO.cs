﻿using System.Xml.Serialization;

namespace Crefisa.DocMng.Contracts.DTO
{
    //[XmlRoot("CampoDocGenerico")]
    public class CampoDocGenericoDTO
    {
        /// <summary>
        /// Nome do campo em referência ao formfield do doc template
        /// </summary>
        [XmlElement(ElementName = "NomeCampo")]
        public string NomeCampo { get; set; }

        /// <summary>
        /// Valor do campo em referência ao formfield do doc template
        /// </summary>
        [XmlElement(ElementName = "ValorCampo")]
        public string ValorCampo { get; set; }

        /// <summary>
        /// Tipo do campo em referência ao formfield do doc template
        /// </summary>
        [XmlElement(ElementName = "TipoCampo")]
        public string TipoCampo { get; set; }

    }
}
