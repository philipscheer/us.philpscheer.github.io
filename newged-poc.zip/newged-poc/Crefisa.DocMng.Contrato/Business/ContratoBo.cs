﻿using Crefisa.DocMng.Contracts;
using Crefisa.DocMng.Contracts.DTO;
using Crefisa.Infraestrutura.Log;
using Spire.Doc;
using Spire.Doc.Documents;
using Spire.Doc.Fields;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using SpireDoc = Spire.Doc;

namespace Crefisa.DocMng.Contrato.Business
{
    class ContratoBo
    {
        #region Atributes

        #endregion

        #region Public Constructors

        #region ContratoBo()
        /// <summary>
        /// Construtor padrão da classe ContratoBo.
        /// </summary>
        public ContratoBo()
        {

        }
        #endregion

        #endregion

        #region Public Methods

        #region GenerateDocumentPdf(ParamGenerateDocPdf param)
        /// <summary>
        /// Geração do Documento de acordo com o tipo do Documento
        /// </summary>
        /// <param name="param"></param>
        public static DocMngDTO GenerateDocumentPdf(ParamGenerateDocPdf param)
        {
            try
            {
                DocContratoDTO docContratoDTO;
                string caminhoArquivoPDF;
                LoggerManager.Instance.Info("[DocMng.GenerateDocumentPdf] - Descerializando campo [Data]");
                docContratoDTO = Crefisa.Infraestrutura.Serializers.SerializerContext.Deserialize<DocContratoDTO>(param.Data, param.SerializerTypes);
                LoggerManager.Instance.Info("[DocMng.GenerateDocumentPdf] - Descerializando campo [Data] - OK");
                LoggerManager.Instance.Info("[DocMng.GenerateDocumentPdf] - Método [trataCaminhoArquivoPDF] de configuração do diretório onde será salvo arquivo em PDF ...");
                caminhoArquivoPDF = tratarCaminhoArquivoPDF(docContratoDTO.CaminhoArquivoPdf);
                docContratoDTO.CaminhoArquivoTemplate = System.Configuration.ConfigurationManager.AppSettings["CaminhoArquivoTemplate"];
                LoggerManager.Instance.Info("[DocMng.GenerateDocumentPdf] - Método [trataCaminhoArquivoPDF] de configuração do diretório onde será salvo arquivo em PDF ... - OK");
                LoggerManager.Instance.Info("[DocMng.GenerateDocumentPdf] - Iniciando geração do contrato número " + docContratoDTO.NumeroContrato);
                Spire.Doc.Document document = new Spire.Doc.Document(System.IO.Path.Combine(docContratoDTO.CaminhoArquivoTemplate, docContratoDTO.NomeArquivo));
                AdicionaValoresPDF(document, docContratoDTO.CamposFormulario);
                PreencherTabelas(document, docContratoDTO.TabelaParcelas, docContratoDTO.TabelaConfissaoDividas);
                RemoveChaves(document);

                var prefixo = "img.doc.";
                var cpf = docContratoDTO.CamposFormulario.Where(x => x.NomeCampo == "nomeArquivoCpf").Select(x => x.ValorCampo).FirstOrDefault().ToString();
                var tipoDoc = docContratoDTO.CamposFormulario.Where(x => x.NomeCampo == "nomeArquivoTipoDoc").Select(x => x.ValorCampo).FirstOrDefault().ToString();
                var pontoAtendimento = docContratoDTO.CamposFormulario.Where(x => x.NomeCampo == "nomeArquivoPontoAtend").Select(x => x.ValorCampo).FirstOrDefault().ToString();
                var data = docContratoDTO.CamposFormulario.Where(x => x.NomeCampo == "nomeArquivoData").Select(x => x.ValorCampo).FirstOrDefault().ToString();
                var extensao = ".pdf";
                var nomeArquivo = string.Concat(prefixo, cpf, ".", tipoDoc, ".", pontoAtendimento, ".", data, extensao);

                document.SaveToFile(System.IO.Path.Combine(caminhoArquivoPDF, System.IO.Path.ChangeExtension(docContratoDTO.NomeArquivo, nomeArquivo)), Spire.Doc.FileFormat.PDF);

                LoggerManager.Instance.Info("[DocMng.GenerateDocumentPdf] - Contrato número " + docContratoDTO.NumeroContrato + " gerado com sucesso.");
                return (new DocMngDTO
                {
                    CaminhoArquivoPdf = docContratoDTO.CaminhoArquivoPdf,
                    CaminhoArquivoTemplate = docContratoDTO.CaminhoArquivoTemplate,
                    CodigoExterno = docContratoDTO.CodigoExterno,
                    NomeArquivo = docContratoDTO.NomeArquivo
                });
            }

            catch (Exception ex)
            {
                LoggerManager.Instance.Error(ex, "[DocMng.GenerateDocumentPdf] - Erro ao gerar Contrato em PDF", ex);
                throw ex;
            }
        }
        #endregion

        #endregion

        #region Private Methods

        /// <summary>
        /// Trata Caminho do Arquivo PDF
        /// </summary>
        /// <param name="caminhoArquivoPdf"></param>
        /// <returns></returns>
        private static string tratarCaminhoArquivoPDF(string caminhoArquivoPdf)
        {
            try
            {
                string ano;
                string mes;
                string dia;
                string hora;
                string novoCaminhoPdf;

                if (caminhoArquivoPdf == null)
                {
                    novoCaminhoPdf = System.Configuration.ConfigurationManager.AppSettings["CaminhoArquivoTemplate"];
                }
                else { novoCaminhoPdf = caminhoArquivoPdf; }

                //Verificar se pasta já existe, caso não, cria uma nova
                // Considerar seguinte path: 
                // Path: Ano\Mes\Dia\
                ano = DateTime.Now.Year.ToString();
                mes = DateTime.Now.Month.ToString().PadLeft(2, '0');
                dia = DateTime.Now.Day.ToString().PadLeft(2, '0');
                hora = DateTime.Now.Hour.ToString().PadLeft(2, '0') + DateTime.Now.Minute.ToString().PadLeft(2, '0');

                //ano
                if (!Directory.Exists(novoCaminhoPdf + ano))
                    Directory.CreateDirectory(novoCaminhoPdf + ano);

                //mes
                if (!Directory.Exists(novoCaminhoPdf + ano + "\\" + mes))
                    Directory.CreateDirectory(novoCaminhoPdf + ano + "\\" + mes);

                //dia
                if (!Directory.Exists(novoCaminhoPdf + ano + "\\" + mes + "\\" + dia))
                    Directory.CreateDirectory(novoCaminhoPdf + ano + "\\" + mes + "\\" + dia);

                novoCaminhoPdf = novoCaminhoPdf + ano + "\\" + mes + "\\" + dia + '\\';

                return novoCaminhoPdf;
            }
            catch (Exception)
            {

                throw;
            }
        }

        /// <summary>
        /// Adiciona valores nos campos mapeados ao PDF gerado
        /// </summary>
        /// <param name="document"></param>
        /// <param name="item"></param>
        /// <returns></returns>
        ///
        private static bool AdicionaValoresPDF(SpireDoc.Document document, IEnumerable<CampoDocGenericoDTO> items)
        {
            try
            {
                //Adiciona valores aos atributos do arquivo que será gerado em PDF
                foreach (var item in items)
                {
                    foreach (FormField field in document.Sections[0].Body.FormFields)
                        if (field.Type == FieldType.FieldFormTextInput)
                            if (field.Name == item.NomeCampo)
                                field.Text = item.ValorCampo;

                    if (item.TipoCampo == "barcodefield")
                        AdicionaCodBarras(item.ValorCampo, document, item.NomeCampo);
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static void RemoveChaves(SpireDoc.Document document)
        {
            Regex regex = new Regex(@"\#cp\w+\b");
            document.Replace(regex, "");
        }

        /// <summary>
        /// Adiciona o código de barras no documento
        /// </summary>
        /// <param name="document"></param>
        /// <param name="item"></param>
        /// <returns></returns>
        ///
        private static void AdicionaCodBarras(String codigo, SpireDoc.Document document, String nomeImagem)
        {
            foreach (Section section in document.Sections)
            {
                foreach (Paragraph paragraph in section.Paragraphs)
                {
                    //Loop through the child elements of paragraph
                    foreach (DocumentObject docObj in paragraph.ChildObjects)
                    {
                        if (docObj.DocumentObjectType == DocumentObjectType.Picture)
                        {
                            DocPicture picture = docObj as DocPicture;
                            if (picture.Title == nomeImagem)
                            {
                                BarcodeLib.Barcode bCode = new BarcodeLib.Barcode();
                                bCode.LabelFont = new Font("Myriad Pro", 18, FontStyle.Bold);
                                bCode.IncludeLabel = true;
                                //Replace the image
                                picture.LoadImage(bCode.Encode(BarcodeLib.TYPE.CODE128, codigo));
                                picture.Width = 130;
                                picture.Height = 32;
                                return;
                            }
                        }
                    }
                }
            }
        }

        private static void PreencherTabelas(SpireDoc.Document document, IEnumerable<ParcelaContratoDTO> parcelas, IEnumerable<ConfissaoDividaDTO> dividas)
        {
            foreach (Section section in document.Sections)
            {
                foreach (Table table in section.Tables)
                {
                    if (table.Title == "TabelaParcelas")
                    {
                        AdicionaLinhasTabelaParcelas(table, parcelas);
                        AdicionaValoresTabelaParcelas(table, parcelas);
                    }
                    else if (table.Title == "TabelaConfissaoDivida")
                    {
                        AdicionaValoresTabelaConfissao(table, dividas);
                    }
                }
            }
        }

        private static void AdicionaValoresTabelaParcelas(Table table, IEnumerable<ParcelaContratoDTO> parcelas)
        {
            var colunaParcela = 0;
            var colunaValor = 1;
            var colunaVencimento = 2;
            var linha = 0;
            foreach (ParcelaContratoDTO parcela in parcelas)
            {
                linha++;
                TableCell cell1 = table.Rows[linha].Cells[colunaParcela];
                Paragraph p1 = cell1.Paragraphs[0];
                p1.Text = parcela.Parcela;
                TableCell cell2 = table.Rows[linha].Cells[colunaValor];
                Paragraph p2 = cell2.Paragraphs[0];
                p2.Text = parcela.Valor;
                TableCell cell3 = table.Rows[linha].Cells[colunaVencimento];
                Paragraph p3 = cell3.Paragraphs[0];
                p3.Text = parcela.Data;
                if ((table.Rows.Count - 1) == linha)
                {
                    colunaParcela = 3;
                    colunaValor = 4;
                    colunaVencimento = 5;
                    linha = 0;
                }
            }
        }


        /// <summary>
        /// Insere novas linhas na tabela de parcelas caso necessário
        /// </summary>
        /// <param name="caminhoArquivoPdf"></param>
        /// <returns></returns>
        private static void AdicionaLinhasTabelaParcelas(Table table, IEnumerable<ParcelaContratoDTO> parcelas)
        {
            var numeroParcelas = parcelas.Count();
            double numeroLinhasTabela = table.Rows.Count - 1;
            if (numeroParcelas > numeroLinhasTabela * 2)
            {
                for (int i = 1; i <= (Math.Ceiling(((numeroParcelas - (numeroLinhasTabela * 2)) / 2))); i++)
                {
                    TableRow ultimaLinha = table.Rows[table.Rows.Count - 1];
                    table.Rows.Insert(table.Rows.Count - 1, ultimaLinha.Clone());
                }
            }
        }


        private static void AdicionaValoresTabelaConfissao(Table tabelaGeral, IEnumerable<ConfissaoDividaDTO> dividas)
        {
            var linha = 0;
            var colunaGeral = 0;
            if (tabelaGeral[1, 0].Tables.Count > 0)
            {
                Table tabela = (Table)tabelaGeral[1, 0].Tables[0];
                AdicionaTituloTabelaConfissao(tabela);
                foreach (ConfissaoDividaDTO divida in dividas)
                {
                    linha++;
                    TableCell cell1 = tabela.Rows[linha].Cells[0];
                    Paragraph p1 = cell1.Paragraphs[0];
                    p1.Text = divida.Contrato;
                    TableCell cell2 = tabela.Rows[linha].Cells[1];
                    Paragraph p2 = cell2.Paragraphs[0];
                    p2.Text = divida.QtdParcelas;
                    TableCell cell3 = tabela.Rows[linha].Cells[2];
                    Paragraph p3 = cell3.Paragraphs[0];
                    p3.Text = divida.Valor;
                    if (linha == tabela.Rows.Count - 1)
                    {
                        colunaGeral++;
                        linha = 0;
                        if (colunaGeral <= 4)
                        {
                            tabela = (Table)tabelaGeral[1, colunaGeral].Tables[0];
                            AdicionaTituloTabelaConfissao(tabela);
                        }
                        else
                        {
                            return;
                        }

                    }
                }
            }
        }

        private static void AdicionaTituloTabelaConfissao(Table tabela)
        {
            TableCell cell1 = tabela.Rows[0].Cells[0];
            Paragraph p1 = cell1.Paragraphs[0];
            p1.Text = "Contrato";
            TableCell cell2 = tabela.Rows[0].Cells[1];
            Paragraph p2 = cell2.Paragraphs[0];
            p2.Text = "Qtd Parcelas";
            TableCell cell3 = tabela.Rows[0].Cells[2];
            Paragraph p3 = cell3.Paragraphs[0];
            p3.Text = "Valor(R$)";
        }

        #endregion

    }
}
