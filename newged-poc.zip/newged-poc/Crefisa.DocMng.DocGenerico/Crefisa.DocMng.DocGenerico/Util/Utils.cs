﻿using Crefisa.DocMng.Contracts.DTO;
using Crefisa.DocMng.Contracts.Enumerator;
using Crefisa.Infraestrutura.Log;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crefisa.DocMng.DocGenerico.Util
{
    public static class Utils
    {

        #region TratarCaminhoArquivoPDF(DocGenericoDTO data)
        /// <summary>
        /// Trata Caminho do Arquivo PDF
        /// </summary>
        /// <param name="caminhoArquivoPdf"></param>
        /// <returns></returns>
        public static string TratarCaminhoArquivoPDF(DocGenericoDTO data)
        {
            try
            {
                var novoCaminhoPdf = "";

                if (string.IsNullOrEmpty(data.CaminhoArquivoPdf))
                {
                    novoCaminhoPdf = System.Configuration.ConfigurationManager.AppSettings["CaminhoArquivoTemplate"];
                }
                else
                {
                    novoCaminhoPdf = data.CaminhoArquivoPdf;
                }
            
                

                //CPF
                if (!Directory.Exists(novoCaminhoPdf))
                    Directory.CreateDirectory(novoCaminhoPdf);

                return novoCaminhoPdf;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region TratarCaminhoTemplate(DocMngDTO data)
        /// <summary>
        /// Trata Caminho do Arquivo PDF
        /// </summary>
        /// <param name="caminhoArquivoPdf"></param>
        /// <returns></returns>
        public static string TratarCaminhoTemplate(DocGenericoDTO data)
        {
            try
            {
                var novoCaminhoPdf = "";

                if (string.IsNullOrEmpty(data.CaminhoArquivoTemplate))
                    novoCaminhoPdf = System.Configuration.ConfigurationManager.AppSettings["CaminhoArquivoTemplate"];
                else
                    novoCaminhoPdf = data.CaminhoArquivoTemplate;

                return novoCaminhoPdf;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion        

    }
}
